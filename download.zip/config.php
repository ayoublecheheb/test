<?php
/**
 * L'EXTERNE ATS - Configuration File
 * Compatible with InfinityFree & Standard Lamp Environments
 */

// Enable session security configurations
if (session_status() === PHP_SESSION_NONE) {
    // Prevent session hijacking by utilizing secure flags safely
    @ini_set('session.cookie_httponly', 1);
    @ini_set('session.use_only_cookies', 1);
    if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
        @ini_set('session.cookie_secure', 1);
    }
    @session_start();
}

// Application Configuration
define('APP_NAME', "L'EXTERNE Recruitment Portal");
define('UPLOAD_DIR', __DIR__ . '/uploads/');
define('MAX_FILE_SIZE', 8 * 1024 * 1024); // 8MB limit for resumes/portfolios
define('ALLOWED_EXTENSIONS', ['pdf', 'docx', 'jpg', 'png', 'zip']);

// Database Parameters (InfinityFree credentials must be entered here by the user)
define('DB_HOST', 'sql107.infinityfree.com');
define('DB_PORT', '3306');
define('DB_NAME', 'if0_42436345_db_lexterne2');
define('DB_USER', 'if0_42436345');
define('DB_PASS', 'UcFupHYwbo');

// Attempt secure PDO Database Connection
$pdo = null;
try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";port=" . DB_PORT . ";charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (PDOException $e) {
    // If database connection fails, don't crash with standard PHP error.
    // Present a premium troubleshooting setup screen!
    $db_connection_error = $e->getMessage();
}

/**
 * Check and create upload directory if not exists
 */
if (!file_exists(UPLOAD_DIR)) {
    @mkdir(UPLOAD_DIR, 0755, true);
    // Add empty index.php to prevent directory indexing
    @file_put_contents(UPLOAD_DIR . 'index.html', 'Access denied.');
}
