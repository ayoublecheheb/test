# L'EXTERNE — Premium Applicant Tracking System (ATS)

A production-ready Applicant Tracking System and Public Recruitment Portal designed for **L'EXTERNE** (Algerian medical learning platform). Built utilizing clean PHP, AJAX, and relational MySQL, optimized for deployment on lightweight shared environments like **InfinityFree hosting**.

---

## 🚀 InfinityFree Host Setup Instructions

Getting your portal live on InfinityFree is direct and takes less than 5 minutes. No Node, NPM, Docker or complex configurations required.

### Stage 1: File Upload via FTP
1. Log in to your InfinityFree client area and obtain your **FTP Credentials** (Host, Username, Password).
2. Connect to your host using an FTP client like **FileZilla** or the online file manager.
3. Locate the `htdocs/` folder (the public web root).
4. Upload all files from this directory directly into the `htdocs/` folder.

### Stage 2: Database Provisioning (phpMyAdmin)
1. Go to your InfinityFree control panel and click on **MySQL Databases**.
2. Create a new database named `lexterne_ats` (or any custom name your host prefixes).
3. Once created, click on **phpMyAdmin** next to the newly created database.
4. Click the **Import** tab at the top.
5. Choose the `database.sql` file provided in this folder and click **Go** at the bottom to build the relational tables.

### Stage 3: Setup configuration (`config.php`)
1. Open the file `config.php` in your folder.
2. Fill in your MySQL credentials (obtained from your InfinityFree MySQL panel):
   ```php
   define('DB_HOST', 'sqlxxx.epizy.com'); // Your MySQL Server hostname
   define('DB_USER', 'epiz_xxxxxx');      // Your FTP/MySQL username
   define('DB_PASS', 'your_password');    // Your host password
   define('DB_NAME', 'epiz_xxxx_lexterne');// Your exact MySQL database name
   ```
3. Save the file.

---

## 🔧 Automated Diagnostics Check
We have included a premium automated diagnostics tool to verify permissions and connections.
- Visit: `http://your-domain.com/fix.php`
- It will instantly check:
  - PHP version compatibility (PHP 8.0+ recommended)
  - Write permissions on the `uploads/` directory
  - Active PDO database connection status
  - Missing database tables (with a one-click auto-install button)

---

## 🔑 Default Administrator Credentials
For safety, we have seeded a default reviewer account. Once logged in, please edit this from the databases panel.
- **Login URL:** `http://your-domain.com/login.php`
- **Email:** `admin@lexterne.com`
- **Password:** `admin123`

---

## 🛠️ Security Engineering Standards
- **SQL Injection Prevention:** Fully guarded using PDO with disabled prepared-statements emulation (`ATTR_EMULATE_PREPARES => false`).
- **CSRF Blockers:** Cryptographically secure token verification on all AJAX entries (`api.php` and `login.php`).
- **XSS Protections:** Complete html encoding sanitization on all output flows.
- **Excel-friendly UTF-8:** Native BOM headers injected into exports for complete Microsoft Excel and Google Sheets compliance.
