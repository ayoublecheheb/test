<?php
/**
 * L'EXTERNE ATS - Admin Entrance Wrapper
 */

require_once __DIR__ . '/functions.php';

// Force authentication
require_login();

// Redirect to modular dashboard page
header('Location: admin/dashboard.php');
exit;
