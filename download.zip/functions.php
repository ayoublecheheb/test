<?php
/**
 * L'EXTERNE ATS - Core Functions Library
 * Secure, clean, and compatible with PHP 8.0+
 */

require_once __DIR__ . '/config.php';

/**
 * XSS Protection - Sanitize raw input values
 */
function sanitize($data) {
    if (is_array($data)) {
        return array_map('sanitize', $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

/**
 * Generate a Cryptographically Secure CSRF Token
 */
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Verify CSRF Token to block cross-site request forgery
 */
function verify_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Check if admin or reviewer is logged in
 */
function is_logged_in() {
    return isset($_SESSION['user_id']) && isset($_SESSION['user_email']);
}

/**
 * Force redirection if user is not authenticated
 */
function require_login() {
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

/**
 * Log System Actions into the database
 */
function add_activity_log($action, $details, $user_id = null) {
    global $pdo;
    if (!$pdo) return false;

    try {
        if ($user_id === null && is_logged_in()) {
            $user_id = $_SESSION['user_id'];
        }
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

        $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, details, ip_address) VALUES (?, ?, ?, ?)");
        return $stmt->execute([$user_id, $action, $details, $ip]);
    } catch (PDOException $e) {
        return false;
    }
}

/**
 * Fetch dynamic system configuration from database settings table
 */
function get_setting($key, $default = '') {
    global $pdo;
    if (!$pdo) return $default;

    try {
        $stmt = $pdo->prepare("SELECT key_value FROM settings WHERE key_name = ? LIMIT 1");
        $stmt->execute([$key]);
        $row = $stmt->fetch();
        return $row ? $row['key_value'] : $default;
    } catch (PDOException $e) {
        return $default;
    }
}

/**
 * Update system settings key-value pair
 */
function set_setting($key, $value) {
    global $pdo;
    if (!$pdo) return false;

    try {
        $stmt = $pdo->prepare("INSERT INTO settings (key_name, key_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE key_value = ?, updated_at = CURRENT_TIMESTAMP");
        return $stmt->execute([$key, $value, $value]);
    } catch (PDOException $e) {
        return false;
    }
}

/**
 * Fetch FAQs from the dedicated `faqs` table, ordered for display.
 * Pass $only_visible = true for the public-facing FAQ section.
 */
function get_faqs($only_visible = false) {
    global $pdo;
    if (!$pdo) return [];

    try {
        $sql = "SELECT * FROM faqs" . ($only_visible ? " WHERE is_visible = 1" : "") . " ORDER BY sort_order ASC, id ASC";
        return $pdo->query($sql)->fetchAll();
    } catch (PDOException $e) {
        return [];
    }
}

/**
 * Increment system statistics count
 */
function increment_statistic($key) {
    global $pdo;
    if (!$pdo) return false;

    try {
        $stmt = $pdo->prepare("INSERT INTO statistics (key_name, key_value) VALUES (?, 1) ON DUPLICATE KEY UPDATE key_value = key_value + 1");
        return $stmt->execute([$key]);
    } catch (PDOException $e) {
        return false;
    }
}

/**
 * Return style color class for applicant status indicators
 */
function get_status_badge_class($status) {
    switch (strtolower($status)) {
        case 'accepted':
            return 'bg-emerald-50 text-emerald-700 border-emerald-200/50';
        case 'interview':
            return 'bg-blue-50 text-blue-700 border-blue-200/50';
        case 'rejected':
            return 'bg-rose-50 text-rose-700 border-rose-200/50';
        case 'archived':
            return 'bg-slate-100 text-slate-600 border-slate-300/50';
        case 'pending':
        default:
            return 'bg-amber-50 text-amber-700 border-amber-200/50';
    }
}

/**
 * Core List - Predefined Algerian Medical Universities
 */
function get_universities_list() {
    return [
        "Algiers — University of Health Sciences (Ziania)",
        "Blida — Saad Dahlab",
        "Oran — Ahmed Ben Bella",
        "Constantine — Salah Boubnider",
        "Annaba — Badji Mokhtar",
        "Batna — Batna 2",
        "Béjaïa — Abderrahmane Mira",
        "Sétif — Ferhat Abbas",
        "Sidi Bel Abbès — Djillali Liabès",
        "Tlemcen — Abou Bekr Belkaïd",
        "Tizi Ouzou — Mouloud Mammeri",
        "Mostaganem — Abdelhamid Ibn Badis",
        "Ouargla — Kasdi Merbah",
        "Béchar — Tahri Mohamed",
        "Djelfa — Ziane Achour",
        "Laghouat — Amar Telidji",
        "Tiaret — Ibn Khaldoun",
        "Adrar — Ahmed Draïa",
        "Other"
    ];
}

/**
 * Predefined Medical Modules list by study year
 */
function get_predefined_modules() {
    return [
        "1st year" => [
            "🦴 Anatomy",
            "🔬 Histology",
            "🐣 Embryology",
            "🧫 Cytology",
            "⚗️ Biochemistry",
            "🧲 Biophysics",
            "📊 Biostatistics",
            "🧪 Chemistry",
            "📖 SSH",
            "➕ Other (Custom Module)"
        ],
        "2nd year" => [
            "🛡️ Immunology",
            "🧬 Génétique",
            "➕ Other (Custom Module)"
        ],
        "3rd year" => [
            "🩸 Digestive System Unit",
            "🦠 Microbiology",
            "➕ Other (Custom Module)"
        ],
        "4th year" => [
            "❤️ Cardiology",
            "🫁 Pulmonology",
            "🤒 Infectious Diseases",
            "🍽️ Gastroenterology",
            "🩸 Hematology",
            "🧠 Neurology",
            "➕ Other (Custom Module)"
        ],
        "5th year" => [
            "🤰 Gynecology",
            "🦿 Orthopedics",
            "👶 Pediatrics",
            "🫘 Nephrology",
            "🍬 Endocrinology",
            "💭 Psychiatry",
            "🦵 Rheumatology",
            "➕ Other (Custom Module)"
        ],
        "6th year / Internship / Residency" => [
            "🚑 Emergency UMC",
            "👁️ Ophthalmology",
            "🧴 Dermatology",
            "📈 Epidemiology",
            "👷 Occupational Medicine",
            "⚖️ Forensic Medicine",
            "👂 ENT",
            "➕ Other (Custom Module)"
        ]
    ];
}

/**
 * Academic Years list
 */
function get_academic_years() {
    return [
        "1st year",
        "2nd year",
        "3rd year",
        "4th year",
        "5th year",
        "6th year",
        "Intern",
        "Resident",
        "General Practitioner / Specialist",
        "Other"
    ];
}

/**
 * Creative Designer Softwares
 */
function get_tools_list() {
    return [
        "Adobe Photoshop",
        "Adobe Illustrator",
        "Canva",
        "Figma",
        "Adobe InDesign",
        "Affinity Designer",
        "Blender",
        "After Effects",
        "Premiere Pro"
    ];
}

/**
 * Communities list
 */
function get_communities_list() {
    return [
        "Marketing & Communication",
        "Design & Creation",
        "Technology",
        "Human Resources",
        "Events & Partnerships",
        "Operations",
        "Editorial Support"
    ];
}

/**
 * Book Designer specialties (Editorial track)
 */
function get_design_specialties_list() {
    return [
        "UI/UX",
        "Graphic Design",
        "Branding",
        "Social Media",
        "Illustration",
        "Book Layout",
        "Motion Graphics",
        "Print Design"
    ];
}

/**
 * IT / Development contribution areas (Community -> Technology division)
 */
function get_it_focus_list() {
    return [
        "Frontend Development",
        "Backend Development",
        "Full-Stack Development",
        "Mobile Development",
        "Flutter",
        "Android",
        "iOS",
        "Database Engineering",
        "API Development",
        "Cloud Infrastructure",
        "DevOps",
        "Cybersecurity",
        "AI Integration",
        "Automation",
        "Quality Assurance (QA)",
        "UI Implementation"
    ];
}

/**
 * Marketing areas of expertise (Community -> Marketing & Communication division)
 */
function get_marketing_expertise_list() {
    return [
        "Social Media Management",
        "Content Creation",
        "Paid Advertising",
        "SEO",
        "Branding",
        "Copywriting",
        "Email Marketing",
        "Analytics",
        "Community Growth",
        "Event Marketing"
    ];
}

/**
 * Common platforms managed by Marketing applicants
 */
function get_marketing_platforms_list() {
    return [
        "Instagram",
        "TikTok",
        "Facebook",
        "Twitter / X",
        "LinkedIn",
        "YouTube",
        "Snapchat",
        "Telegram",
        "Reddit",
        "Threads",
        "Other"
    ];
}

/**
 * Community sub-roles / how an applicant would like to contribute (any Community division)
 */
function get_community_contribution_list() {
    return [
        "Student Ambassador",
        "Campus Representative",
        "Discord Moderator",
        "Telegram Moderator",
        "Community Support",
        "Student Success",
        "Mentorship",
        "Organizing Events",
        "Workshops",
        "Recruiting Students",
        "Partnerships",
        "Content Moderation"
    ];
}

/**
 * Platforms an applicant may have previously managed as a community role
 */
function get_community_platforms_list() {
    return [
        "Discord",
        "Telegram",
        "Facebook Groups",
        "Instagram",
        "LinkedIn",
        "WhatsApp",
        "Slack",
        "Reddit",
        "Other"
    ];
}
