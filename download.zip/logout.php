<?php
/**
 * L'EXTERNE ATS - Secure Logout Handler
 */

require_once __DIR__ . '/config.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Log action before destroying
if (isset($_SESSION['user_id'])) {
    require_once __DIR__ . '/functions.php';
    add_activity_log('Logout Success', "User {$_SESSION['user_name']} logged out.");
}

// Unset all session variables
$_SESSION = [];

// Destroy session cookie if it exists
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destroy session
session_destroy();

header('Location: login.php');
exit;
