-- L'EXTERNE ATS - Database Schema
-- Production Ready for InfinityFree MySQL
-- UTF-8 Unicode support

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- --------------------------------------------------------
-- Table structure for `users`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` VARCHAR(50) DEFAULT 'reviewer', -- 'admin', 'reviewer'
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for `applications`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `applications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `full_name` VARCHAR(150) NOT NULL,
  `email` VARCHAR(150) NOT NULL,
  `whatsapp` VARCHAR(50) NOT NULL,
  `telegram` VARCHAR(100) NOT NULL,
  `faculty` VARCHAR(150) NOT NULL,
  `academic_year` VARCHAR(100) NOT NULL,
  `recruitment_path` VARCHAR(50) NOT NULL, -- 'Editorial', 'Community', 'Both'
  `availability` VARCHAR(100) DEFAULT NULL,
  `motivation` TEXT DEFAULT NULL,
  `project` VARCHAR(255) DEFAULT NULL,
  `long_term_commitment` VARCHAR(50) DEFAULT NULL,
  `previous_experience` VARCHAR(10) DEFAULT 'No', -- 'Yes', 'No'
  `previous_experience_details` TEXT DEFAULT NULL,
  `ideas` TEXT DEFAULT NULL,
  `status` VARCHAR(50) DEFAULT 'Pending', -- 'Pending', 'Interview', 'Accepted', 'Rejected', 'Archived'
  `reviewer_id` INT DEFAULT NULL,
  `notes` TEXT DEFAULT NULL,
  `internal_tags` VARCHAR(255) DEFAULT NULL, -- comma separated tags
  `is_favorite` TINYINT(1) DEFAULT 0,
  `interview_date` DATETIME DEFAULT NULL,
  `submitted_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`reviewer_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for `application_roles`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `application_roles` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `application_id` INT NOT NULL,
  `role_name` VARCHAR(100) NOT NULL,
  FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for `application_modules`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `application_modules` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `application_id` INT NOT NULL,
  `study_year` VARCHAR(50) NOT NULL, -- '1st year', '2nd year', etc.
  `module_name` VARCHAR(100) NOT NULL,
  `is_custom` TINYINT(1) DEFAULT 0, -- 1 for other/custom module
  FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for `application_tools`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `application_tools` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `application_id` INT NOT NULL,
  `tool_name` VARCHAR(100) NOT NULL,
  `proficiency_level` VARCHAR(50) NOT NULL, -- 'Beginner', 'Intermediate', 'Advanced', 'Expert'
  FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for `application_portfolios`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `application_portfolios` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `application_id` INT NOT NULL,
  `portfolio_url` VARCHAR(255) NOT NULL,
  FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for `application_communities`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `application_communities` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `application_id` INT NOT NULL,
  `community_name` VARCHAR(150) NOT NULL,
  FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for `activity_logs`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `activity_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT DEFAULT NULL,
  `action` VARCHAR(100) NOT NULL,
  `details` TEXT NOT NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for `settings`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `settings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `key_name` VARCHAR(100) NOT NULL UNIQUE,
  `key_value` TEXT NOT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for `statistics`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `statistics` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `key_name` VARCHAR(100) NOT NULL UNIQUE,
  `key_value` INT NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Initial Data Seeds
-- --------------------------------------------------------

-- Default Admin Account: admin@lexterne.com / admin123
-- Password is encrypted using PHP's password_hash() with bcrypt ($2y$10$...)
-- Real hash of 'admin123': $2y$10$C82o87eWjJ/D68BvL8R5oOOncTfX0C8VjOf6D6oRzRHe3/Rk1YI1W
INSERT INTO `users` (`id`, `name`, `email`, `password_hash`, `role`) VALUES
(1, 'L\'EXTERNE Admin', 'admin@lexterne.com', '$2y$10$C82o87eWjJ/D68BvL8R5oOOncTfX0C8VjOf6D6oRzRHe3/Rk1YI1W', 'admin')
ON DUPLICATE KEY UPDATE `id`=`id`;

-- Recruitment System Settings
INSERT INTO `settings` (`key_name`, `key_value`) VALUES
('recruitment_status', 'open'), -- 'open' or 'closed'
('site_title', 'L\'EXTERNE Recruitment 2026'),
('site_description', 'Join our premium medical creation team and help shape the future of medical education in Algeria.'),
('hero_title', 'Shape the Future of Medical Education'),
('hero_subtitle', 'Join the largest medical content creation initiative in Algeria. Contribute as a writer, designer, reviewer or community driver and help thousands of students.'),
('stats_books', '45+ Books Published'),
('stats_users', '15k+ Med Students'),
('stats_contributors', '120+ Team Members'),
('faq_json', '[{\"question\":\"What is L\\\'EXTERNE?\",\"answer\":\"L\\\'EXTERNE is the leading medical education resource platform in Algeria, crafting high-quality books, MCQs, and interactive study tools for medical students across all years.\"},{\"question\":\"Are there multiple recruitment stages?\",\"answer\":\"Yes, our process consists of an online application review, followed by an interactive assignment, and a short online interview.\"},{\"question\":\"Can I join both the Editorial and Community tracks?\",\"answer\":\"Absolutely. Step 3 of the application allows you to select Both tracks if you wish to apply for both writing and operational roles.\"}]'),
('testimonials_json', '[{\"name\":\"Dr. Sarah Merah\",\"role\":\"Pediatrics Book Lead\",\"text\":\"Being part of L\\\'EXTERNE allowed me to transform dry lectures into engaging, clinical-first books that now assist thousands of peers. It is incredibly rewarding.\"},{\"name\":\"Amine Benkouider\",\"role\":\"Lead Graphic Designer\",\"text\":\"L\\\'EXTERNE gave me the creative freedom to design medical graphics, work on high-end book covers, and collaborate with brilliant minds across Algerian faculties.\"}]'),
('timeline_json', '[{\"step\":\"1\",\"title\":\"Online Application\",\"desc\":\"Fill out this multi-step form detailing your experience, academic year, and interests. (7-10 mins)\"},{\"step\":\"2\",\"title\":\"Interactive Evaluation\",\"desc\":\"A practical assignment tailored to your chosen role (e.g., writing a sample MCQ or designing a page layout).\"},{\"step\":\"3\",\"title\":\"Virtual Interview\",\"desc\":\"A brief friendly meeting with committee heads to align goals and finalize your entry.\"}]')
ON DUPLICATE KEY UPDATE `key_name`=`key_name`;

-- Setup Initial System Counters
INSERT INTO `statistics` (`key_name`, `key_value`) VALUES
('views_total', 1480),
('applications_submitted', 0),
('applications_accepted', 0),
('applications_interview', 0)
ON DUPLICATE KEY UPDATE `key_name`=`key_name`;

-- --------------------------------------------------------
-- MIGRATION: Smart Role Selection follow-up fields
-- Additive only — safe to run once against an existing production DB.
-- Run this block manually if you're applying it to a live database
-- that was created before this migration was added.
-- --------------------------------------------------------

-- New columns on `applications` (single-value answers)
ALTER TABLE `applications`
  ADD COLUMN `revenue_sharing_response` VARCHAR(50) DEFAULT NULL AFTER `ideas`, -- 'Yes', 'No', 'I\'d like more information'
  ADD COLUMN `it_github_url` VARCHAR(255) DEFAULT NULL AFTER `revenue_sharing_response`,
  ADD COLUMN `it_portfolio_url` VARCHAR(255) DEFAULT NULL AFTER `it_github_url`,
  ADD COLUMN `it_languages` TEXT DEFAULT NULL AFTER `it_portfolio_url`, -- comma-separated free-tag list
  ADD COLUMN `it_frameworks` TEXT DEFAULT NULL AFTER `it_languages`, -- comma-separated free-tag list
  ADD COLUMN `it_years_experience` VARCHAR(50) DEFAULT NULL AFTER `it_frameworks`,
  ADD COLUMN `it_significant_project` TEXT DEFAULT NULL AFTER `it_years_experience`,
  ADD COLUMN `marketing_budget_experience` VARCHAR(10) DEFAULT NULL AFTER `it_significant_project`, -- 'Yes', 'No'
  ADD COLUMN `marketing_budget_details` TEXT DEFAULT NULL AFTER `marketing_budget_experience`,
  ADD COLUMN `marketing_campaign` TEXT DEFAULT NULL AFTER `marketing_budget_details`,
  ADD COLUMN `community_managed_before` VARCHAR(10) DEFAULT NULL AFTER `marketing_campaign`, -- 'Yes', 'No'
  ADD COLUMN `community_member_count` INT DEFAULT NULL AFTER `community_managed_before`,
  ADD COLUMN `community_hours_per_week` VARCHAR(50) DEFAULT NULL AFTER `community_member_count`,
  ADD COLUMN `community_why_join` TEXT DEFAULT NULL AFTER `community_hours_per_week`;

-- --------------------------------------------------------
-- Table structure for `application_it_focus`
-- (Multi-select: how the applicant would like to contribute in IT/Development)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `application_it_focus` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `application_id` INT NOT NULL,
  `focus_name` VARCHAR(100) NOT NULL,
  FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for `application_marketing_expertise`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `application_marketing_expertise` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `application_id` INT NOT NULL,
  `expertise_name` VARCHAR(100) NOT NULL,
  FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for `application_marketing_platforms`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `application_marketing_platforms` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `application_id` INT NOT NULL,
  `platform_name` VARCHAR(100) NOT NULL,
  FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for `application_community_contributions`
-- (Multi-select: Student Ambassador, Discord Moderator, etc.)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `application_community_contributions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `application_id` INT NOT NULL,
  `contribution_name` VARCHAR(100) NOT NULL,
  FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for `application_community_platforms`
-- (Multi-select: Discord, Telegram, Facebook Groups, etc.)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `application_community_platforms` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `application_id` INT NOT NULL,
  `platform_name` VARCHAR(100) NOT NULL,
  FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table structure for `application_design_specialties`
-- (Multi-select for Book Designer: UI/UX, Branding, etc.)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `application_design_specialties` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `application_id` INT NOT NULL,
  `specialty_name` VARCHAR(100) NOT NULL,
  FOREIGN KEY (`application_id`) REFERENCES `applications`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- MIGRATION 2: Recruitment Improvements follow-up fields
-- Additive only — safe to run once against an existing production DB.
-- Run this block manually if you're applying it to a live database
-- that already has the Smart Role Selection migration above.
-- --------------------------------------------------------

ALTER TABLE `applications`
  ADD COLUMN `it_why_join` TEXT DEFAULT NULL AFTER `it_significant_project`, -- Why they'd like to contribute to the Technology team
  ADD COLUMN `marketing_budget_size` VARCHAR(50) DEFAULT NULL AFTER `marketing_budget_details`, -- Advertising budget size (shown only if marketing_budget_experience = 'Yes')
  ADD COLUMN `marketing_work_links` TEXT DEFAULT NULL AFTER `marketing_campaign`, -- comma-separated list of links to previous marketing work
  ADD COLUMN `marketing_why_join` TEXT DEFAULT NULL AFTER `marketing_work_links`, -- Why they'd like to join the Marketing team
  ADD COLUMN `community_unique_value` TEXT DEFAULT NULL AFTER `community_why_join`, -- What unique value they can bring to the community
  ADD COLUMN `community_problem_solving` TEXT DEFAULT NULL AFTER `community_unique_value`; -- A situation where they helped solve a problem / supported a team

-- --------------------------------------------------------
-- MIGRATION 3: Dynamic FAQ management
-- Additive only — safe to run once against an existing production DB.
-- Replaces the static faq_json setting with a dedicated, manageable table
-- (supports add/edit/delete/reorder/show-hide from the Admin CMS).
-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `faqs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `question` VARCHAR(500) NOT NULL,
  `answer` TEXT NOT NULL,
  `sort_order` INT NOT NULL DEFAULT 0,
  `is_visible` TINYINT(1) NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed with the FAQs previously stored in the faq_json setting, so no content is lost.
INSERT INTO `faqs` (`id`, `question`, `answer`, `sort_order`, `is_visible`) VALUES
(1, 'What is L\'EXTERNE?', 'L\'EXTERNE is the leading medical education resource platform in Algeria, crafting high-quality books, MCQs, and interactive study tools for medical students across all years.', 1, 1),
(2, 'Are there multiple recruitment stages?', 'Yes, our process consists of an online application review, followed by an interactive assignment, and a short online interview.', 2, 1),
(3, 'Can I join both the Editorial and Community tracks?', 'Absolutely. Step 3 of the application allows you to select Both tracks if you wish to apply for both writing and operational roles.', 3, 1)
ON DUPLICATE KEY UPDATE `id`=`id`;

-- --------------------------------------------------------
-- MIGRATION 4: Community track — previous work / examples
-- Additive only — safe to run once against an existing production DB.
-- Covers the Portfolio/Previous-work evaluation gap for Community
-- divisions that had no dedicated question (HR, Events & Partnerships,
-- Operations, Editorial Support), without duplicating the
-- Marketing/Design-specific portfolio fields that already exist.
-- --------------------------------------------------------

ALTER TABLE `applications`
  ADD COLUMN `community_portfolio_links` TEXT DEFAULT NULL AFTER `community_problem_solving`;

SET FOREIGN_KEY_CHECKS = 1;
