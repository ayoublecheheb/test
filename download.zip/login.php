<?php
/**
 * L'EXTERNE ATS - Secure Admin Login
 * CSRF verified, password-hashed authentication.
 */

require_once __DIR__ . '/functions.php';

// Redirect if already authenticated
if (is_logged_in()) {
    header('Location: admin.php');
    exit;
}

$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // CSRF Check
    $csrf = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($csrf)) {
        $error_message = 'Invalid security session. Please reload.';
    } else {
        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            $error_message = 'Please enter both your email and password.';
        } else {
            // Find user in DB
            try {
                $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
                $stmt->execute([$email]);
                $user = $stmt->fetch();

                if ($user && password_verify($password, $user['password_hash'])) {
                    // Regenerate session ID to prevent session fixation safely
                    @session_regenerate_id(true);
                    
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_name'] = $user['name'];
                    $_SESSION['user_email'] = $user['email'];
                    $_SESSION['user_role'] = $user['role'];

                    // Log activity
                    add_activity_log('Login Success', "User {$user['name']} logged in successfully.", $user['id']);

                    header('Location: admin.php');
                    exit;
                } else {
                    $error_message = 'Invalid email address or security password. If you need to reset the admin password, please visit <a href="fix.php" class="underline text-sky-600 font-bold hover:text-sky-700">fix.php</a> to recreate or reset your administrator credentials.';
                    add_activity_log('Login Failure', "Attempted login with email: " . sanitize($email));
                }
            } catch (PDOException $e) {
                $error_message = 'Database diagnostic issue: ' . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en" class="h-full bg-slate-50">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>L'EXTERNE - Admin Login</title>
    <link rel="icon" type="image/png" href="assets/images/logo.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
    </style>
</head>
<body class="flex min-h-full flex-col justify-center py-12 sm:px-6 lg:px-8 bg-gradient-to-tr from-sky-50 via-white to-indigo-50/20">
    <div class="sm:mx-auto sm:w-full sm:max-w-md">
        <div class="flex justify-center mb-3">
            <img src="assets/images/logo.png" alt="L'EXTERNE Logo" class="h-16 w-16 object-contain drop-shadow-sm">
        </div>
        <div class="flex justify-center text-sky-600 font-extrabold text-3xl tracking-tight">
            L'EXTERNE
        </div>
        <h2 class="mt-4 text-center text-xl font-bold tracking-tight text-slate-900">Sign in to Review Board</h2>
        <p class="mt-1.5 text-center text-xs text-slate-500">Applicant Tracking and Evaluation Portal</p>
    </div>

    <div class="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div class="bg-white px-8 py-8 shadow-sm border border-slate-200/80 rounded-2xl mx-4 sm:mx-0">
            
            <?php if (!empty($error_message)): ?>
                <div class="mb-4 p-3 bg-rose-50 border border-rose-100 rounded-xl text-xs font-semibold text-rose-700 leading-normal">
                    <?php echo htmlspecialchars($error_message); ?>
                </div>
            <?php endif; ?>

            <form class="space-y-6" method="POST" action="login.php">
                <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">

                <div>
                    <label for="email" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Administrative Email</label>
                    <input id="email" name="email" type="email" autocomplete="email" required placeholder="admin@lexterne.com" class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-sky-500 focus:outline-none transition-colors">
                </div>

                <div>
                    <div class="flex items-center justify-between mb-2">
                        <label for="password" class="block text-xs font-bold text-slate-700 uppercase tracking-wider">Access Password</label>
                        <span class="text-[10px] text-slate-400">Default: admin123</span>
                    </div>
                    <input id="password" name="password" type="password" autocomplete="current-password" required placeholder="••••••••" class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-sky-500 focus:outline-none transition-colors">
                </div>

                <div>
                    <button type="submit" class="w-full flex justify-center py-2.5 px-4 border border-transparent rounded-xl shadow-sm text-sm font-semibold text-white bg-sky-600 hover:bg-sky-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-500 transition-colors duration-150">
                        Sign In
                    </button>
                </div>
            </form>

            <div class="mt-6 border-t border-slate-100 pt-4 flex justify-between items-center text-[10px] text-slate-400">
                <a href="index.php" class="hover:text-sky-600 transition-colors">Public Website</a>
                <a href="fix.php" class="hover:text-sky-600 transition-colors font-semibold text-sky-700">Setup Diagnostic</a>
            </div>
        </div>
    </div>
</body>
</html>
