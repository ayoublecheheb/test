<?php
/**
 * L'EXTERNE ATS - API Gateway
 * Handles form submissions and Admin actions via JSON.
 * Secure, prepared statements, CSRF checked, transactional.
 */

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/functions.php';

$response = [
    'status' => 'error',
    'message' => 'Invalid action or request method.'
];

// Verify request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode($response);
    exit;
}

// Parse JSON payload if content-type is application/json or $_POST is empty
if (empty($_POST)) {
    $raw_input = file_get_contents('php://input');
    if (!empty($raw_input)) {
        $json_data = json_decode($raw_input, true);
        if (is_array($json_data)) {
            $_POST = $json_data;
        }
    }
}

$action = trim($_POST['action'] ?? '');

// --------------------------------------------------------
// ACTION: SUBMIT_APPLICATION (Public application submission)
// --------------------------------------------------------
if ($action === 'submit_application') {
    // CSRF Check
    $csrf = $_POST['csrf_token'] ?? '';
    if (!verify_csrf_token($csrf)) {
        echo json_encode(['status' => 'error', 'message' => 'Security token expired. Please refresh the page and try again.']);
        exit;
    }

    // Verify recruitment is open
    if (get_setting('recruitment_status', 'open') !== 'open') {
        echo json_encode(['status' => 'error', 'message' => 'We appreciate your interest, but the L\'EXTERNE recruitment campaign is currently closed.']);
        exit;
    }

    // Capture identity fields
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $whatsapp = trim($_POST['whatsapp'] ?? '');
    $telegram = trim($_POST['telegram'] ?? '');
    $faculty = trim($_POST['faculty'] ?? '');
    $academic_year = trim($_POST['academic_year'] ?? '');
    $recruitment_path = trim($_POST['recruitment_path'] ?? '');
    $availability = trim($_POST['availability'] ?? '');
    $motivation = trim($_POST['motivation'] ?? '');
    $project = trim($_POST['project'] ?? '');
    $long_term_commitment = trim($_POST['long_term_commitment'] ?? '');
    $previous_experience = trim($_POST['previous_experience'] ?? 'No');
    $prev_exp_details = trim($_POST['previous_experience_details'] ?? '');
    $ideas = trim($_POST['ideas'] ?? '');

    // Smart Role Selection follow-up fields (additive)
    $revenue_sharing_response = trim($_POST['revenue_sharing_response'] ?? '');
    $it_github_url = trim($_POST['it_github_url'] ?? '');
    $it_portfolio_url = trim($_POST['it_portfolio_url'] ?? '');
    $it_languages = trim($_POST['it_languages'] ?? '');
    $it_frameworks = trim($_POST['it_frameworks'] ?? '');
    $it_years_experience = trim($_POST['it_years_experience'] ?? '');
    $it_significant_project = trim($_POST['it_significant_project'] ?? '');
    $it_why_join = trim($_POST['it_why_join'] ?? '');
    $marketing_budget_experience = trim($_POST['marketing_budget_experience'] ?? 'No');
    $marketing_budget_details = trim($_POST['marketing_budget_details'] ?? '');
    $marketing_budget_size = trim($_POST['marketing_budget_size'] ?? '');
    $marketing_campaign = trim($_POST['marketing_campaign'] ?? '');
    $marketing_work_links = trim($_POST['marketing_work_links'] ?? '');
    $marketing_why_join = trim($_POST['marketing_why_join'] ?? '');
    $community_managed_before = trim($_POST['community_managed_before'] ?? 'No');
    $community_member_count = trim($_POST['community_member_count'] ?? '');
    $community_member_count = ($community_member_count !== '') ? intval($community_member_count) : null;
    $community_hours_per_week = trim($_POST['community_hours_per_week'] ?? '');
    $community_why_join = trim($_POST['community_why_join'] ?? '');
    $community_unique_value = trim($_POST['community_unique_value'] ?? '');
    $community_problem_solving = trim($_POST['community_problem_solving'] ?? '');
    $community_portfolio_links = trim($_POST['community_portfolio_links'] ?? '');

    // Validate essential inputs
    if (empty($full_name) || empty($email) || empty($whatsapp) || empty($telegram) || empty($faculty) || empty($academic_year) || empty($recruitment_path)) {
        echo json_encode(['status' => 'error', 'message' => 'Please fill in all required personal and academic information.']);
        exit;
    }

    if (!str_starts_with($telegram, '@')) {
        echo json_encode(['status' => 'error', 'message' => 'Telegram username must start with @']);
        exit;
    }

    // Begin Database Transaction to ensure structural integrity across 7 child tables
    try {
        $pdo->beginTransaction();

        // 1. Insert into applications
        $stmt = $pdo->prepare("INSERT INTO applications 
            (full_name, email, whatsapp, telegram, faculty, academic_year, recruitment_path, availability, motivation, project, long_term_commitment, previous_experience, previous_experience_details, ideas,
             revenue_sharing_response, it_github_url, it_portfolio_url, it_languages, it_frameworks, it_years_experience, it_significant_project, it_why_join,
             marketing_budget_experience, marketing_budget_details, marketing_budget_size, marketing_campaign, marketing_work_links, marketing_why_join,
             community_managed_before, community_member_count, community_hours_per_week, community_why_join, community_unique_value, community_problem_solving, community_portfolio_links, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')");
        
        $stmt->execute([
            $full_name, $email, $whatsapp, $telegram, $faculty, $academic_year, $recruitment_path,
            $availability, $motivation, $project, $long_term_commitment, $previous_experience, $prev_exp_details, $ideas,
            $revenue_sharing_response, $it_github_url, $it_portfolio_url, $it_languages, $it_frameworks, $it_years_experience, $it_significant_project, $it_why_join,
            $marketing_budget_experience, $marketing_budget_details, $marketing_budget_size, $marketing_campaign, $marketing_work_links, $marketing_why_join,
            $community_managed_before, $community_member_count, $community_hours_per_week, $community_why_join, $community_unique_value, $community_problem_solving, $community_portfolio_links
        ]);
        
        $application_id = $pdo->lastInsertId();

        // 2. Insert roles (if Editorial path chosen)
        if (($recruitment_path === 'Editorial' || $recruitment_path === 'Both') && isset($_POST['roles']) && is_array($_POST['roles'])) {
            $stmt_role = $pdo->prepare("INSERT INTO application_roles (application_id, role_name) VALUES (?, ?)");
            foreach ($_POST['roles'] as $r) {
                $stmt_role->execute([$application_id, trim($r)]);
            }
        }

        // 2b. Insert Book Designer design specialties
        if (isset($_POST['design_specialties']) && is_array($_POST['design_specialties'])) {
            $stmt_spec = $pdo->prepare("INSERT INTO application_design_specialties (application_id, specialty_name) VALUES (?, ?)");
            foreach ($_POST['design_specialties'] as $spec) {
                if (!empty(trim($spec))) {
                    $stmt_spec->execute([$application_id, trim($spec)]);
                }
            }
        }

        // 3. Insert study levels & modules
        // Standard modules
        if (isset($_POST['modules']) && is_array($_POST['modules'])) {
            $stmt_mod = $pdo->prepare("INSERT INTO application_modules (application_id, study_year, module_name, is_custom) VALUES (?, ?, ?, 0)");
            foreach ($_POST['modules'] as $year => $mods) {
                if (is_array($mods)) {
                    foreach ($mods as $m) {
                        $stmt_mod->execute([$application_id, $year, trim($m)]);
                    }
                }
            }
        }
        
        // Custom modules ("Other" text input list)
        $custom_modules_json = $_POST['custom_modules'] ?? '{}';
        $custom_modules = json_decode($custom_modules_json, true);
        if (is_array($custom_modules)) {
            $stmt_custom_mod = $pdo->prepare("INSERT INTO application_modules (application_id, study_year, module_name, is_custom) VALUES (?, ?, ?, 1)");
            foreach ($custom_modules as $year => $mods) {
                if (is_array($mods)) {
                    foreach ($mods as $m) {
                        if (!empty(trim($m))) {
                            $stmt_custom_mod->execute([$application_id, $year, trim($m)]);
                        }
                    }
                }
            }
        }

        // 4. Insert design software tools
        if (isset($_POST['tools']) && is_array($_POST['tools'])) {
            $stmt_tool = $pdo->prepare("INSERT INTO application_tools (application_id, tool_name, proficiency_level) VALUES (?, ?, ?)");
            foreach ($_POST['tools'] as $tool => $prof) {
                $stmt_tool->execute([$application_id, $tool, trim($prof)]);
            }
        }

        // Custom software designer tools
        $custom_tools_json = $_POST['custom_designer_tools'] ?? '[]';
        $custom_tools = json_decode($custom_tools_json, true);
        if (is_array($custom_tools)) {
            $stmt_custom_tool = $pdo->prepare("INSERT INTO application_tools (application_id, tool_name, proficiency_level) VALUES (?, ?, 'Expert')");
            foreach ($custom_tools as $t) {
                if (!empty(trim($t))) {
                    $stmt_custom_tool->execute([$application_id, trim($t)]);
                }
            }
        }

        // 5. Portfolios & links
        $portfolios_json = $_POST['portfolio_urls'] ?? '[]';
        $portfolios = json_decode($portfolios_json, true);
        if (is_array($portfolios)) {
            $stmt_port = $pdo->prepare("INSERT INTO application_portfolios (application_id, portfolio_url) VALUES (?, ?)");
            foreach ($portfolios as $url) {
                if (!empty(trim($url))) {
                    $stmt_port->execute([$application_id, trim($url)]);
                }
            }
        }

        // Supplementary portfolio for community
        $comm_portfolio = trim($_POST['comm_portfolio'] ?? '');
        if (!empty($comm_portfolio)) {
            $stmt_port = $pdo->prepare("INSERT INTO application_portfolios (application_id, portfolio_url) VALUES (?, ?)");
            $stmt_port->execute([$application_id, $comm_portfolio]);
        }

        // 6. Insert communities (if Community or Both tracks)
        if (($recruitment_path === 'Community' || $recruitment_path === 'Both') && isset($_POST['communities']) && is_array($_POST['communities'])) {
            $stmt_comm = $pdo->prepare("INSERT INTO application_communities (application_id, community_name) VALUES (?, ?)");
            foreach ($_POST['communities'] as $comm) {
                $stmt_comm->execute([$application_id, trim($comm)]);
            }

            // Community tool chain (figma, photoshop, canva)
            $comm_tools_json = $_POST['community_tools'] ?? '[]';
            $comm_tools = json_decode($comm_tools_json, true);
            if (is_array($comm_tools)) {
                $stmt_comm_tool = $pdo->prepare("INSERT INTO application_tools (application_id, tool_name, proficiency_level) VALUES (?, ?, 'Intermediate')");
                foreach ($comm_tools as $ct) {
                    $stmt_comm_tool->execute([$application_id, trim($ct)]);
                }
            }

            // 6a. IT / Development contribution focus (Technology division)
            if (isset($_POST['it_focus']) && is_array($_POST['it_focus'])) {
                $stmt_it = $pdo->prepare("INSERT INTO application_it_focus (application_id, focus_name) VALUES (?, ?)");
                foreach ($_POST['it_focus'] as $f) {
                    if (!empty(trim($f))) {
                        $stmt_it->execute([$application_id, trim($f)]);
                    }
                }
            }

            // 6b. Marketing areas of expertise & platforms (Marketing & Communication division)
            if (isset($_POST['marketing_expertise']) && is_array($_POST['marketing_expertise'])) {
                $stmt_mkt = $pdo->prepare("INSERT INTO application_marketing_expertise (application_id, expertise_name) VALUES (?, ?)");
                foreach ($_POST['marketing_expertise'] as $exp) {
                    if (!empty(trim($exp))) {
                        $stmt_mkt->execute([$application_id, trim($exp)]);
                    }
                }
            }
            if (isset($_POST['marketing_platforms']) && is_array($_POST['marketing_platforms'])) {
                $stmt_mktp = $pdo->prepare("INSERT INTO application_marketing_platforms (application_id, platform_name) VALUES (?, ?)");
                foreach ($_POST['marketing_platforms'] as $plat) {
                    if (!empty(trim($plat))) {
                        $stmt_mktp->execute([$application_id, trim($plat)]);
                    }
                }
            }

            // 6c. General community sub-roles & platforms (shown for any Community division)
            if (isset($_POST['community_contributions']) && is_array($_POST['community_contributions'])) {
                $stmt_cc = $pdo->prepare("INSERT INTO application_community_contributions (application_id, contribution_name) VALUES (?, ?)");
                foreach ($_POST['community_contributions'] as $c) {
                    if (!empty(trim($c))) {
                        $stmt_cc->execute([$application_id, trim($c)]);
                    }
                }
            }
            if (isset($_POST['community_platforms']) && is_array($_POST['community_platforms'])) {
                $stmt_cp = $pdo->prepare("INSERT INTO application_community_platforms (application_id, platform_name) VALUES (?, ?)");
                foreach ($_POST['community_platforms'] as $p) {
                    if (!empty(trim($p))) {
                        $stmt_cp->execute([$application_id, trim($p)]);
                    }
                }
            }
        }

        // Commit all changes
        $pdo->commit();

        // Update system statistics
        increment_statistic('applications_submitted');

        // Log system activity
        add_activity_log('Application Submitted', "New application submitted by: " . sanitize($full_name) . " ({$email})");

        echo json_encode([
            'status' => 'success',
            'message' => 'Application submitted successfully.',
            'tracking_code' => 'EXT-' . str_pad($application_id, 4, '0', STR_PAD_LEFT)
        ]);
        exit;

    } catch (Exception $e) {
        $pdo->rollBack();
        echo json_encode(['status' => 'error', 'message' => 'Database failure: ' . $e->getMessage()]);
        exit;
    }
}


// --------------------------------------------------------
// ADMINISTRATIVE ACTIONS (ALL REQUIRE AUTHENTICATED BOARD CONTEXT)
// --------------------------------------------------------
if (!is_logged_in()) {
    echo json_encode(['status' => 'error', 'message' => 'Access Denied. Authenticated session required.']);
    exit;
}

// Ensure administrative user session context
$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'];

// ACTION: UPDATE_STATUS (Accept, Reject, Interview, Archive)
if ($action === 'update_status') {
    $id = intval($_POST['id'] ?? 0);
    $status = trim($_POST['status'] ?? '');

    if ($id <= 0 || empty($status)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid applicant identifier or target status.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("UPDATE applications SET status = ?, reviewer_id = ? WHERE id = ?");
        $stmt->execute([$status, $user_id, $id]);

        // Increment stats if accepted
        if ($status === 'Accepted') {
            increment_statistic('applications_accepted');
        } elseif ($status === 'Interview') {
            increment_statistic('applications_interview');
        }

        add_activity_log('Status Updated', "Changed applicant ID {$id} status to {$status}.", $user_id);
        
        echo json_encode(['status' => 'success', 'message' => "Applicant status changed to {$status} successfully."]);
        exit;
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => 'Database mutation error: ' . $e->getMessage()]);
        exit;
    }
}

// ACTION: UPDATE_NOTES (Recruiter comments)
if ($action === 'update_notes') {
    $id = intval($_POST['id'] ?? 0);
    $notes = trim($_POST['notes'] ?? '');

    try {
        $stmt = $pdo->prepare("UPDATE applications SET notes = ? WHERE id = ?");
        $stmt->execute([$notes, $id]);

        add_activity_log('Notes Added', "Modified reviewer notes for applicant ID {$id}.", $user_id);

        echo json_encode(['status' => 'success', 'message' => 'Recruiter evaluation notes updated.']);
        exit;
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => 'Database mutation error: ' . $e->getMessage()]);
        exit;
    }
}

// ACTION: UPDATE_TAGS (Review tags e.g. "Excellent MCQ", "Talented Designer")
if ($action === 'update_tags') {
    $id = intval($_POST['id'] ?? 0);
    $tags = trim($_POST['tags'] ?? '');

    try {
        $stmt = $pdo->prepare("UPDATE applications SET internal_tags = ? WHERE id = ?");
        $stmt->execute([$tags, $id]);

        add_activity_log('Tags Updated', "Updated evaluation tags for applicant ID {$id}.", $user_id);

        echo json_encode(['status' => 'success', 'message' => 'Applicant internal review tags saved.']);
        exit;
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => 'Database mutation error: ' . $e->getMessage()]);
        exit;
    }
}

// ACTION: TOGGLE_FAVORITE (Set favorite 0/1)
if ($action === 'toggle_favorite') {
    $id = intval($_POST['id'] ?? 0);
    
    try {
        // Toggle current state
        $stmt = $pdo->prepare("UPDATE applications SET is_favorite = NOT is_favorite WHERE id = ?");
        $stmt->execute([$id]);

        echo json_encode(['status' => 'success', 'message' => 'Favorite toggle successful.']);
        exit;
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => 'Database mutation error: ' . $e->getMessage()]);
        exit;
    }
}

// ACTION: SCHEDULE_INTERVIEW (Schedule interview date/time)
if ($action === 'schedule_interview') {
    $id = intval($_POST['id'] ?? 0);
    $datetime = trim($_POST['interview_date'] ?? '');

    if ($id <= 0 || empty($datetime)) {
        echo json_encode(['status' => 'error', 'message' => 'Missing applicant ID or scheduled interview slot.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("UPDATE applications SET interview_date = ?, status = 'Interview', reviewer_id = ? WHERE id = ?");
        $stmt->execute([$datetime, $user_id, $id]);

        increment_statistic('applications_interview');
        add_activity_log('Interview Scheduled', "Scheduled interview slot for applicant ID {$id} at {$datetime}.", $user_id);

        echo json_encode(['status' => 'success', 'message' => 'Interview date scheduled and status changed to Interview.']);
        exit;
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => 'Database mutation error: ' . $e->getMessage()]);
        exit;
    }
}

// ACTION: DELETE_APPLICANT
if ($action === 'delete_applicant') {
    $id = intval($_POST['id'] ?? 0);

    if ($id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid candidate selected for deletion.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM applications WHERE id = ?");
        $stmt->execute([$id]);

        add_activity_log('Applicant Deleted', "Completely removed candidate record ID {$id} from system.", $user_id);

        echo json_encode(['status' => 'success', 'message' => 'Candidate record successfully deleted.']);
        exit;
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => 'Database removal error: ' . $e->getMessage()]);
        exit;
    }
}

// ACTION: UPDATE_SETTINGS (CMS Configurations & Toggles)
if ($action === 'update_settings') {
    $status = trim($_POST['recruitment_status'] ?? 'open');
    $title = trim($_POST['site_title'] ?? "L'EXTERNE Recruitment");
    $desc = trim($_POST['site_description'] ?? '');
    $hero_t = trim($_POST['hero_title'] ?? '');
    $hero_sub = trim($_POST['hero_subtitle'] ?? '');
    $faq_json = trim($_POST['faq_json'] ?? '');
    $testimonials_json = trim($_POST['testimonials_json'] ?? '');

    try {
        set_setting('recruitment_status', $status);
        set_setting('site_title', $title);
        set_setting('site_description', $desc);
        set_setting('hero_title', $hero_t);
        set_setting('hero_subtitle', $hero_sub);
        
        if (!empty($faq_json)) {
            set_setting('faq_json', $faq_json);
        }
        if (!empty($testimonials_json)) {
            set_setting('testimonials_json', $testimonials_json);
        }

        add_activity_log('Settings Updated', "Updated global CMS settings & campaign status to {$status}.", $user_id);

        echo json_encode(['status' => 'success', 'message' => 'Campaign settings and landing content saved.']);
        exit;
    } catch (Exception $e) {
        echo json_encode(['status' => 'error', 'message' => 'Database settings mutation error: ' . $e->getMessage()]);
        exit;
    }
}

echo json_encode($response);
exit;
