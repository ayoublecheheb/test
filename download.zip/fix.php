<?php
/**
 * L'EXTERNE ATS - Database Setup and Diagnostic Utility
 * Helps users configure their database and auto-seeding on InfinityFree hosts.
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/config.php';

$title = "System Setup & Diagnostic Tool";
?>
<!DOCTYPE html>
<html lang="en" class="h-full bg-slate-50">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>L'EXTERNE Setup Diagnostic</title>
    <link rel="icon" type="image/png" href="assets/images/logo.png">
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="flex min-h-full flex-col justify-center py-12 sm:px-6 lg:px-8">
    <div class="sm:mx-auto sm:w-full sm:max-w-md">
        <div class="flex justify-center mb-3">
            <img src="assets/images/logo.png" alt="L'EXTERNE Logo" class="h-16 w-16 object-contain drop-shadow-sm">
        </div>
        <div class="flex justify-center text-sky-600 font-bold text-3xl tracking-tight">
            L'EXTERNE
        </div>
        <h2 class="mt-4 text-center text-2xl font-bold tracking-tight text-slate-900">Database Setup Helper</h2>
        <p class="mt-2 text-center text-sm text-slate-600">
            Automated database setup and configuration tester.
        </p>
    </div>

    <div class="mt-8 sm:mx-auto sm:w-full sm:max-w-xl">
        <div class="bg-white px-8 py-8 shadow-sm border border-slate-200/80 rounded-2xl">
            <h3 class="text-base font-semibold leading-6 text-slate-900 border-b border-slate-100 pb-4 mb-4">Diagnostics Check</h3>

            <div class="space-y-4">
                <!-- Check PHP version -->
                <div class="flex items-center justify-between py-2 border-b border-slate-50">
                    <span class="text-sm font-medium text-slate-600">PHP Environment</span>
                    <span class="inline-flex items-center rounded-md bg-emerald-50 px-2 py-1 text-xs font-medium text-emerald-700 ring-1 ring-inset ring-emerald-600/10">
                        v<?php echo PHP_VERSION; ?> (OK)
                    </span>
                </div>

                <!-- Check uploads directory -->
                <div class="flex items-center justify-between py-2 border-b border-slate-50">
                    <span class="text-sm font-medium text-slate-600">Uploads Folder Perms</span>
                    <?php if (is_writable(UPLOAD_DIR)): ?>
                        <span class="inline-flex items-center rounded-md bg-emerald-50 px-2 py-1 text-xs font-medium text-emerald-700 ring-1 ring-inset ring-emerald-600/10">Writable</span>
                    <?php else: ?>
                        <span class="inline-flex items-center rounded-md bg-amber-50 px-2 py-1 text-xs font-medium text-amber-700 ring-1 ring-inset ring-amber-600/10">Not Writable (Check permissions to 0755)</span>
                    <?php endif; ?>
                </div>

                <!-- Database Check -->
                <div class="py-2 border-b border-slate-50">
                    <div class="flex items-center justify-between">
                        <span class="text-sm font-medium text-slate-600 font-semibold text-slate-800">Database Status</span>
                        <?php if (isset($db_connection_error)): ?>
                            <span class="inline-flex items-center rounded-md bg-rose-50 px-2 py-1 text-xs font-medium text-rose-700 ring-1 ring-inset ring-rose-600/10">Failed</span>
                        <?php else: ?>
                            <span class="inline-flex items-center rounded-md bg-emerald-50 px-2 py-1 text-xs font-medium text-emerald-700 ring-1 ring-inset ring-emerald-600/10">Connected</span>
                        <?php endif; ?>
                    </div>

                    <?php if (isset($db_connection_error)): ?>
                        <div class="mt-3 bg-rose-50/50 rounded-xl p-4 border border-rose-100 text-sm text-rose-800">
                            <p class="font-bold">PDO Connection Failure details:</p>
                            <p class="mt-1 font-mono text-xs break-all"><?php echo htmlspecialchars($db_connection_error); ?></p>
                            <p class="mt-3 text-xs text-slate-500 leading-normal">
                                To fix this, open <code class="bg-slate-100 px-1 py-0.5 rounded text-rose-600 font-mono">config.php</code> and fill in your DB parameters (host, user, password, database). Make sure the database exists in your hosting admin panel.
                            </p>
                        </div>
                    <?php else: ?>
                        <div class="mt-3 bg-emerald-50/30 rounded-xl p-4 border border-emerald-100/50 text-sm text-emerald-800">
                            <p class="font-medium text-emerald-900">Successfully connected to database: <code class="font-mono text-xs text-sky-800 font-bold"><?php echo DB_NAME; ?></code></p>
                            
                            <?php
                            // Check if table users exists, otherwise offer to auto-create from database.sql
                            $tables_exist = false;
                            try {
                                $test_query = $pdo->query("SHOW TABLES LIKE 'users'");
                                if ($test_query->rowCount() > 0) {
                                    $tables_exist = true;
                                }
                            } catch (Exception $e) {}

                            if ($tables_exist):
                            ?>
                                <p class="mt-2 text-xs text-slate-600 leading-relaxed">
                                    Tables are present in the database. You are good to go!
                                </p>
                                <form method="POST" class="mt-4 border-t border-slate-100 pt-4">
                                    <input type="hidden" name="action" value="reset_admin">
                                    <h4 class="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Create / Reset Admin Account</h4>
                                    <p class="text-[11px] text-slate-500 mb-3 leading-normal">
                                        If you are having trouble logging in, use this form to recreate or reset the administrator credentials directly in your MySQL database.
                                    </p>
                                    <div class="grid grid-cols-2 gap-3 mb-3">
                                        <div>
                                            <label class="block text-[10px] font-bold text-slate-500 uppercase">Admin Email</label>
                                            <input type="email" name="admin_email" value="admin@lexterne.com" required class="w-full text-xs rounded-xl border border-slate-200 p-2.5 focus:outline-none focus:border-sky-500">
                                        </div>
                                        <div>
                                            <label class="block text-[10px] font-bold text-slate-500 uppercase">New Password</label>
                                            <input type="text" name="admin_password" value="admin123" required class="w-full text-xs rounded-xl border border-slate-200 p-2.5 focus:outline-none focus:border-sky-500">
                                        </div>
                                    </div>
                                    <button type="submit" class="w-full flex justify-center py-2 px-4 border border-transparent rounded-xl shadow-sm text-xs font-bold text-white bg-amber-600 hover:bg-amber-500 focus:outline-none transition-colors duration-150">
                                        Apply Reset / Recreate Admin
                                    </button>
                                </form>
                            <?php else: ?>
                                <p class="mt-2 text-xs text-amber-700 leading-relaxed font-bold">
                                    ⚠️ No tables found. Database needs setup!
                                </p>
                                <form method="POST" class="mt-3">
                                    <input type="hidden" name="action" value="install">
                                    <button type="submit" class="w-full flex justify-center py-2 px-4 border border-transparent rounded-xl shadow-sm text-sm font-semibold text-white bg-sky-600 hover:bg-sky-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-sky-500 transition-colors duration-150">
                                        Import Database Schema (`database.sql`)
                                    </button>
                                </form>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Process Install Post request -->
                <?php
                if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'reset_admin' && !isset($db_connection_error)) {
                    $email = trim($_POST['admin_email'] ?? '');
                    $pass = $_POST['admin_password'] ?? '';
                    if (empty($email) || empty($pass)) {
                        echo '<div class="mt-4 p-4 bg-rose-50 text-rose-800 rounded-xl text-sm border border-rose-100">Please provide both email and password.</div>';
                    } else {
                        try {
                            $hash = password_hash($pass, PASSWORD_BCRYPT);
                            // Ensure table users exists
                            $pdo->exec("CREATE TABLE IF NOT EXISTS `users` (
                              `id` INT AUTO_INCREMENT PRIMARY KEY,
                              `name` VARCHAR(100) NOT NULL,
                              `email` VARCHAR(150) NOT NULL UNIQUE,
                              `password_hash` VARCHAR(255) NOT NULL,
                              `role` VARCHAR(50) DEFAULT 'reviewer',
                              `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

                            // Recreate or reset user with ID = 1
                            $stmt = $pdo->prepare("INSERT INTO users (id, name, email, password_hash, role) VALUES (1, 'L\'EXTERNE Admin', ?, ?, 'admin') ON DUPLICATE KEY UPDATE email = ?, password_hash = ?");
                            $stmt->execute([$email, $hash, $email, $hash]);

                            echo '<div class="mt-4 p-4 bg-emerald-50 text-emerald-800 rounded-xl text-sm border border-emerald-100">';
                            echo '<p class="font-bold">Admin Credentials successfully set!</p>';
                            echo '<p class="text-xs mt-1">Email: <code class="font-mono bg-sky-50 px-1 py-0.5 rounded text-sky-950 font-bold">'.htmlspecialchars($email).'</code></p>';
                            echo '<p class="text-xs">Password: <code class="font-mono bg-sky-50 px-1 py-0.5 rounded text-sky-950 font-bold">'.htmlspecialchars($pass).'</code></p>';
                            echo '<p class="text-xs mt-2 text-slate-500 leading-normal">You can now use these details to log in to the administrator dashboard.</p>';
                            echo '</div>';
                        } catch (Exception $e) {
                            echo '<div class="mt-4 p-4 bg-rose-50 text-rose-800 rounded-xl text-sm border border-rose-100">Error setting admin credentials: ' . htmlspecialchars($e->getMessage()) . '</div>';
                        }
                    }
                }

                if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'install' && !isset($db_connection_error)) {
                    $sql_file = __DIR__ . '/database.sql';
                    if (!file_exists($sql_file)) {
                        echo '<div class="mt-4 p-4 bg-rose-50 text-rose-800 rounded-xl text-sm font-semibold border border-rose-100">database.sql not found at workspace root.</div>';
                    } else {
                        try {
                            $sql_content = file_get_contents($sql_file);
                            
                            // Split queries by semicolon (approximate split)
                            // Remove comments
                            $sql_clean = preg_replace('/--.*\n/', '', $sql_content);
                            $sql_queries = explode(';', $sql_clean);
                            
                            $success_count = 0;
                            $error_count = 0;
                            
                            foreach ($sql_queries as $query) {
                                $query = trim($query);
                                if (!empty($query)) {
                                    try {
                                        $pdo->exec($query);
                                        $success_count++;
                                    } catch (PDOException $qe) {
                                        $error_count++;
                                    }
                                }
                            }
                            
                            echo '<div class="mt-4 p-4 bg-emerald-50 text-emerald-800 rounded-xl text-sm border border-emerald-100">';
                            echo '<p class="font-bold">Database Seeding Successful!</p>';
                            echo '<p class="text-xs mt-1">Successfully ran ' . $success_count . ' SQL statement blocks. Failed ' . $error_count . ' statements.</p>';
                            echo '<p class="text-xs mt-2 font-bold text-sky-800">Default Credentials Created:</p>';
                            echo '<ul class="list-disc list-inside text-xs mt-1 text-slate-700"><li>Email: <code class="font-mono bg-sky-50 px-1 py-0.5 rounded text-sky-950 font-semibold">admin@lexterne.com</code></li><li>Password: <code class="font-mono bg-sky-50 px-1 py-0.5 rounded text-sky-950 font-semibold">admin123</code></li></ul>';
                            echo '<p class="text-xs mt-3 text-slate-500 leading-normal">For security, please log in and change this password, and then delete `fix.php` from your FTP directory.</p>';
                            echo '</div>';
                        } catch (Exception $e) {
                            echo '<div class="mt-4 p-4 bg-rose-50 text-rose-800 rounded-xl text-sm border border-rose-100">Installation Error: ' . htmlspecialchars($e->getMessage()) . '</div>';
                        }
                    }
                }
                ?>
            </div>
            
            <div class="mt-6 flex justify-between text-xs text-slate-400">
                <a href="index.php" class="text-sky-600 hover:underline">Go to Website</a>
                <a href="login.php" class="text-sky-600 hover:underline">Go to Admin Dashboard</a>
            </div>
        </div>
    </div>
</body>
</html>
