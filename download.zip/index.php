<?php
/**
 * L'EXTERNE - Recruitment Portal Public Entry
 * Production-ready HTML/PHP landing page and multi-step application form.
 * Premium Glassmorphism UI inspired by Stripe/Apple.
 */

require_once __DIR__ . '/functions.php';

// Increment daily view stats
increment_statistic('views_total');

$recruitment_status = get_setting('recruitment_status', 'open');
$site_title = get_setting('site_title', "L'EXTERNE Recruitment");
$site_desc = get_setting('site_description', "Join Algeria's leading medical creation initiative.");
$hero_title = get_setting('hero_title', "Shape the Future of Medical Education");
$hero_subtitle = get_setting('hero_subtitle', "Join the largest medical content creation initiative in Algeria. Contribute as a writer, designer, reviewer or community driver and help thousands of students.");

// Parse CMS components
$faq = get_faqs(true); // only_visible = true — hidden FAQs are excluded from the public site
?>

<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#01002A">
    <title><?php echo htmlspecialchars($site_title); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($site_desc); ?>">

    <link rel="icon" type="image/png" href="assets/images/logo.png">
    <link rel="apple-touch-icon" href="assets/images/logo.png">

    <!-- Fonts: Fraunces (editorial display, "we make books"), Hanken Grotesk (clinical body), IBM Plex Mono (instrument) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,500;9..144,600;9..144,700&family=Hanken+Grotesk:wght@400;500;600;700;800&family=IBM+Plex+Mono:wght@400;500;600&display=swap" rel="stylesheet">

    <!-- Tailwind Play CDN (no build step) with the sky/indigo scales remapped onto the L'EXTERNE cyan brand -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Hanken Grotesk"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
                        serif: ['"Fraunces"', 'ui-serif', 'Georgia', 'serif'],
                        mono: ['"IBM Plex Mono"', 'ui-monospace', 'monospace'],
                    },
                    colors: {
                        /* verbatim form uses sky-* / indigo-* utilities — remap them onto the brand teal/cyan */
                        sky: {
                            50:'#EAFCFD',100:'#C9F6F7',200:'#97ECEE',300:'#5CDDE1',
                            400:'#28C9D0',500:'#12A7B3',600:'#0B8A96',700:'#0A6E79',
                            800:'#0C5761',900:'#0D474F',
                        },
                        indigo: {
                            50:'#EAFCFD',100:'#C9F6F7',200:'#97ECEE',300:'#5CDDE1',
                            400:'#28C9D0',500:'#12A7B3',600:'#0B8A96',700:'#0A6E79',
                            800:'#0C5761',900:'#0D474F',
                        },
                        brand: {
                            navy:'#01002A', ink:'#05063A', cyan:'#01E1E0',
                        }
                    }
                }
            }
        }
    </script>

    <style>
        :root{
            --ink:#01002A;          /* brand navy base */
            --ink-2:#070A3A;        /* lifted navy for panels */
            --ink-3:#0C1150;        /* hairlines on navy */
            --cyan:#01E1E0;         /* signature accent */
            --cyan-2:#5AF0EF;       /* lighter cyan */
            --cyan-deep:#0B8A96;    /* accessible cyan-family text on light */
            --paper:#F5F8FA;        /* light section base */
            --paper-2:#FFFFFF;
            --text:#0B1526;         /* body text on light */
            --text-soft:#53617A;    /* secondary text on light */
            --text-invert:#EAFDFE;  /* text on navy */
            --muted-invert:rgba(224,251,252,.62);
            --line:rgba(6,16,44,.09);
            --line-2:rgba(6,16,44,.14);
            --radius:18px;
            --radius-lg:26px;
            --shadow-sm:0 1px 2px rgba(6,16,44,.04), 0 4px 14px rgba(6,16,44,.05);
            --shadow-md:0 10px 30px -8px rgba(6,16,44,.14), 0 4px 12px rgba(6,16,44,.06);
            --shadow-cyan:0 18px 50px -14px rgba(1,225,224,.55);
            --font-display:'Fraunces',serif;
            --font-sans:'Hanken Grotesk',sans-serif;
            --font-mono:'IBM Plex Mono',monospace;
            --ease:cubic-bezier(.16,1,.3,1);
        }

        *{box-sizing:border-box}
        html{-webkit-text-size-adjust:100%}
        body{
            font-family:var(--font-sans);
            color:var(--text);
            background:var(--paper);
            -webkit-font-smoothing:antialiased;
            text-rendering:optimizeLegibility;
            letter-spacing:-.006em;
        }
        ::selection{background:rgba(1,225,224,.28);color:var(--ink)}
        .serif{font-family:var(--font-display)}
        .mono{font-family:var(--font-mono)}

        /* ---------- Custom scrollbar ---------- */
        html{scrollbar-color:#B9C6D2 transparent}
        ::-webkit-scrollbar{width:11px;height:11px}
        ::-webkit-scrollbar-thumb{background:#C2CEDA;border-radius:20px;border:3px solid var(--paper)}
        ::-webkit-scrollbar-thumb:hover{background:#9FB0BF}

        /* ---------- Top scroll-progress bar ---------- */
        #scrollProgress{position:fixed;top:0;left:0;height:3px;width:0;z-index:70;
            background:linear-gradient(90deg,var(--cyan),var(--cyan-2));
            box-shadow:0 0 12px rgba(1,225,224,.6);transition:width .1s linear}

        /* ---------- Section rhythm & headings ---------- */
        .section{padding:clamp(4.5rem,9vw,7.5rem) 0}
        .wrap{max-width:1180px;margin:0 auto;padding:0 clamp(1.15rem,4vw,2rem)}
        .wrap-narrow{max-width:820px;margin:0 auto;padding:0 clamp(1.15rem,4vw,2rem)}
        .eyebrow{font-family:var(--font-mono);font-size:.72rem;font-weight:600;letter-spacing:.18em;
            text-transform:uppercase;color:var(--cyan-deep);display:inline-flex;align-items:center;gap:.55rem}
        .eyebrow::before{content:"";width:22px;height:1.5px;background:var(--cyan-deep);opacity:.6}
        .h-display{font-family:var(--font-display);font-weight:600;line-height:1.04;
            letter-spacing:-.02em;color:var(--ink);font-size:clamp(2rem,4.4vw,3.1rem)}
        .h-section{font-family:var(--font-display);font-weight:600;line-height:1.06;
            letter-spacing:-.02em;color:var(--ink);font-size:clamp(1.75rem,3.6vw,2.6rem)}
        .lead{color:var(--text-soft);font-size:clamp(1rem,1.4vw,1.15rem);line-height:1.7;font-weight:400}

        /* ---------- Buttons ---------- */
        .btn{position:relative;display:inline-flex;align-items:center;justify-content:center;gap:.5rem;
            font-family:var(--font-sans);font-weight:700;font-size:.95rem;letter-spacing:-.01em;
            padding:.95rem 1.5rem;border-radius:14px;cursor:pointer;border:1px solid transparent;
            transition:transform .35s var(--ease),box-shadow .35s var(--ease),background .3s,color .2s;
            overflow:hidden;text-decoration:none;will-change:transform}
        .btn-primary{background:linear-gradient(120deg,var(--cyan),var(--cyan-2));color:#00201F;
            box-shadow:0 12px 34px -12px rgba(1,225,224,.75),inset 0 1px 0 rgba(255,255,255,.45)}
        .btn-primary:hover{transform:translateY(-2px);box-shadow:0 20px 46px -12px rgba(1,225,224,.9),inset 0 1px 0 rgba(255,255,255,.5)}
        .btn-primary::after{content:"";position:absolute;inset:0;background:linear-gradient(120deg,transparent 30%,rgba(255,255,255,.55) 50%,transparent 70%);
            transform:translateX(-120%);transition:transform .8s var(--ease)}
        .btn-primary:hover::after{transform:translateX(120%)}
        .btn-ghost{background:rgba(255,255,255,.04);color:var(--text-invert);border-color:rgba(224,251,252,.28)}
        .btn-ghost:hover{background:rgba(255,255,255,.1);transform:translateY(-2px);border-color:rgba(1,225,224,.6)}
        .btn-light{background:#fff;color:var(--ink);border-color:var(--line-2);box-shadow:var(--shadow-sm)}
        .btn-light:hover{transform:translateY(-2px);box-shadow:var(--shadow-md);border-color:var(--cyan-deep)}
        .ripple{position:absolute;border-radius:50%;transform:scale(0);background:rgba(255,255,255,.5);
            animation:ripple .6s var(--ease);pointer-events:none}
        @keyframes ripple{to{transform:scale(2.6);opacity:0}}

        /* ---------- Nav ---------- */
        header.nav{position:sticky;top:0;z-index:60;transition:background .4s,box-shadow .4s,border-color .4s;
            border-bottom:1px solid transparent}
        header.nav.scrolled{background:rgba(255,255,255,.82);backdrop-filter:blur(16px) saturate(1.2);
            -webkit-backdrop-filter:blur(16px) saturate(1.2);border-bottom-color:var(--line);box-shadow:0 1px 0 rgba(6,16,44,.03)}
        .nav-inner{max-width:1180px;margin:0 auto;padding:0 clamp(1.15rem,4vw,2rem);height:70px;
            display:flex;align-items:center;justify-content:space-between;gap:1rem}
        .brand{display:flex;align-items:center;gap:.72rem;text-decoration:none}
        .brand-tile{height:42px;width:42px;border-radius:12px;object-fit:cover;
            box-shadow:0 6px 18px -6px rgba(1,0,42,.45),0 0 0 1px rgba(6,16,44,.06);
            transition:transform .4s var(--ease),box-shadow .4s var(--ease)}
        .brand:hover .brand-tile{transform:translateY(-1px) rotate(-2deg);box-shadow:0 10px 26px -8px rgba(1,225,224,.6),0 0 0 1px rgba(1,225,224,.35)}
        .brand-word{font-family:var(--font-display);font-weight:600;font-size:1.28rem;letter-spacing:-.02em;color:var(--ink)}
        .nav-links{display:flex;align-items:center;gap:2rem}
        .nav-links a{font-size:.92rem;font-weight:500;color:var(--text-soft);text-decoration:none;transition:color .2s;position:relative}
        .nav-links a:hover{color:var(--ink)}
        .nav-links a::after{content:"";position:absolute;left:0;bottom:-6px;height:2px;width:0;background:var(--cyan);transition:width .3s var(--ease)}
        .nav-links a:hover::after{width:100%}
        .status-pill{display:inline-flex;align-items:center;gap:.45rem;font-family:var(--font-mono);
            font-size:.7rem;font-weight:600;letter-spacing:.02em;padding:.32rem .7rem;border-radius:100px;border:1px solid}
        .status-open{background:rgba(1,225,224,.1);color:#067A78;border-color:rgba(1,225,224,.4)}
        .status-closed{background:rgba(244,63,94,.08);color:#B4243D;border-color:rgba(244,63,94,.3)}
        .status-dot{width:6px;height:6px;border-radius:50%}
        .status-open .status-dot{background:#06B6B4;box-shadow:0 0 0 0 rgba(1,225,224,.6);animation:pulse 2.2s infinite}
        .status-closed .status-dot{background:#E11D48}
        @keyframes pulse{0%{box-shadow:0 0 0 0 rgba(1,225,224,.55)}70%{box-shadow:0 0 0 7px rgba(1,225,224,0)}100%{box-shadow:0 0 0 0 rgba(1,225,224,0)}}
        .nav-toggle{display:none;background:none;border:1px solid var(--line-2);border-radius:11px;width:42px;height:42px;
            align-items:center;justify-content:center;cursor:pointer;color:var(--ink)}
        .mobile-menu{display:none;flex-direction:column;gap:.25rem;padding:.6rem clamp(1.15rem,4vw,2rem) 1.1rem}
        .mobile-menu a{padding:.7rem .2rem;font-weight:600;color:var(--ink);text-decoration:none;border-bottom:1px solid var(--line)}
        .mobile-menu.show{display:flex}

        /* ---------- Hero (navy, ECG signature) ---------- */
        .hero{position:relative;overflow:hidden;background:
            radial-gradient(1200px 620px at 78% -8%,rgba(1,225,224,.16),transparent 60%),
            radial-gradient(900px 520px at 8% 12%,rgba(43,120,255,.12),transparent 58%),
            linear-gradient(180deg,#01002A 0%,#04062F 58%,#070A38 100%);
            color:var(--text-invert)}
        .hero::before{content:"";position:absolute;inset:0;opacity:.5;pointer-events:none;
            background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='56' height='97' viewBox='0 0 56 97'%3E%3Cpath fill='none' stroke='%23163a66' stroke-width='1' stroke-opacity='.5' d='M28 0l28 16v33L28 65 0 49V16z'/%3E%3C/svg%3E");
            background-size:56px 97px;-webkit-mask-image:radial-gradient(circle at 50% 30%,#000,transparent 78%);
            mask-image:radial-gradient(circle at 50% 30%,#000,transparent 78%)}
        .hero-grain{position:absolute;inset:0;pointer-events:none;opacity:.5;mix-blend-mode:overlay;
            background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='140' height='140'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='.5'/%3E%3C/svg%3E")}
        .blob{position:absolute;border-radius:50%;filter:blur(70px);opacity:.5;pointer-events:none;animation:float 14s ease-in-out infinite}
        .blob-a{width:340px;height:340px;background:rgba(1,225,224,.35);top:-90px;right:8%}
        .blob-b{width:280px;height:280px;background:rgba(52,110,255,.3);bottom:-60px;left:-40px;animation-delay:-6s}
        @keyframes float{0%,100%{transform:translateY(0) translateX(0)}50%{transform:translateY(-26px) translateX(14px)}}
        .hero-inner{position:relative;z-index:2;max-width:1000px;margin:0 auto;
            padding:clamp(4rem,9vw,6.5rem) clamp(1.15rem,4vw,2rem) clamp(4.5rem,8vw,6rem);text-align:center}
        .hero-logo-wrap{position:relative;width:96px;height:96px;margin:0 auto 1.6rem;display:grid;place-items:center}
        .hero-logo-wrap::after{content:"";position:absolute;inset:-30% ;border-radius:50%;
            background:radial-gradient(circle,rgba(1,225,224,.4),transparent 68%);filter:blur(6px)}
        .hero-logo{position:relative;z-index:1;width:96px;height:96px;object-fit:contain;border-radius:22px;
            mix-blend-mode:screen;filter:drop-shadow(0 6px 26px rgba(1,225,224,.55))}
        .hero-eyebrow{display:inline-flex;align-items:center;gap:.6rem;font-family:var(--font-mono);
            font-size:.72rem;font-weight:500;letter-spacing:.2em;text-transform:uppercase;color:var(--cyan-2);
            padding:.4rem .9rem;border:1px solid rgba(1,225,224,.28);border-radius:100px;background:rgba(1,225,224,.06);margin-bottom:1.6rem}
        .hero h1{font-family:var(--font-display);font-weight:600;color:#F4FEFF;
            font-size:clamp(2.35rem,6vw,4.35rem);line-height:1.02;letter-spacing:-.028em;max-width:16ch;margin:0 auto}
        .hero h1 .accent{background:linear-gradient(120deg,var(--cyan),var(--cyan-2));
            -webkit-background-clip:text;background-clip:text;color:transparent;font-style:italic}
        .hero-sub{margin:1.5rem auto 0;max-width:60ch;color:var(--muted-invert);
            font-size:clamp(1.02rem,1.6vw,1.22rem);line-height:1.7}
        .hero-cta{margin-top:2.4rem;display:flex;flex-wrap:wrap;gap:.9rem;justify-content:center}
        .hero-trust{margin-top:3rem;display:flex;flex-wrap:wrap;gap:.6rem 1.7rem;justify-content:center;
            font-size:.82rem;color:var(--muted-invert)}
        .hero-trust span{display:inline-flex;align-items:center;gap:.5rem}
        .hero-trust svg{width:16px;height:16px;color:var(--cyan)}
        /* ECG vital line signature */
        .ecg{position:absolute;left:0;right:0;bottom:0;z-index:1;height:120px;width:100%;opacity:.9;pointer-events:none}
        .ecg path{fill:none;stroke:url(#ecgGrad);stroke-width:2;stroke-linecap:round;stroke-linejoin:round;
            stroke-dasharray:1400;stroke-dashoffset:1400;animation:ecgDraw 4s var(--ease) .4s forwards}
        @keyframes ecgDraw{to{stroke-dashoffset:0}}
        .ecg-dot{fill:var(--cyan);filter:drop-shadow(0 0 8px var(--cyan))}
        .scroll-cue{position:absolute;left:50%;bottom:18px;transform:translateX(-50%);z-index:3;
            display:flex;flex-direction:column;align-items:center;gap:.4rem;color:var(--muted-invert);font-size:.66rem;
            font-family:var(--font-mono);letter-spacing:.18em;text-transform:uppercase}
        .scroll-cue .mouse{width:20px;height:32px;border:1.5px solid rgba(224,251,252,.4);border-radius:12px;position:relative}
        .scroll-cue .mouse::after{content:"";position:absolute;top:6px;left:50%;transform:translateX(-50%);
            width:3px;height:6px;border-radius:3px;background:var(--cyan);animation:scrolldot 1.8s infinite}
        @keyframes scrolldot{0%{opacity:0;top:6px}40%{opacity:1}80%{opacity:0;top:16px}100%{opacity:0}}

        /* ---------- Stats band ---------- */
        .stats{background:#fff;border-top:1px solid var(--line);border-bottom:1px solid var(--line)}
        .stats-grid{display:grid;grid-template-columns:repeat(3,1fr)}
        .stat{padding:clamp(2rem,4vw,3rem) 1.5rem;text-align:center;border-left:1px solid var(--line)}
        .stat:first-child{border-left:none}
        .stat .num{font-family:var(--font-display);font-weight:600;color:var(--ink);
            font-size:clamp(2.1rem,4.5vw,3rem);line-height:1;letter-spacing:-.02em}
        .stat .num .suf{color:var(--cyan-deep)}
        .stat .lbl{margin-top:.7rem;font-size:.82rem;font-weight:500;color:var(--text-soft);letter-spacing:.01em}

        /* ---------- Cards ---------- */
        .card{background:var(--paper-2);border:1px solid var(--line);border-radius:var(--radius-lg);
            padding:clamp(1.5rem,2.4vw,2.1rem);box-shadow:var(--shadow-sm);
            transition:transform .45s var(--ease),box-shadow .45s var(--ease),border-color .45s var(--ease);position:relative;overflow:hidden}
        .card:hover{transform:translateY(-5px);box-shadow:var(--shadow-md);border-color:rgba(1,225,224,.45)}
        .card-ico{width:46px;height:46px;border-radius:13px;display:grid;place-items:center;margin-bottom:1.15rem;
            background:linear-gradient(140deg,rgba(1,225,224,.16),rgba(1,225,224,.04));color:var(--cyan-deep);
            border:1px solid rgba(1,225,224,.25)}
        .card-ico svg{width:23px;height:23px}
        .card h3{font-family:var(--font-display);font-weight:600;font-size:1.2rem;color:var(--ink);letter-spacing:-.01em}
        .card p{margin-top:.6rem;color:var(--text-soft);font-size:.94rem;line-height:1.65}
        .grid-3{display:grid;grid-template-columns:repeat(3,1fr);gap:1.15rem}
        .grid-2{display:grid;grid-template-columns:repeat(2,1fr);gap:1.15rem}

        /* ---------- Values chips ---------- */
        .value-row{display:flex;flex-wrap:wrap;gap:.7rem;margin-top:1.6rem}
        .value-chip{display:inline-flex;align-items:center;gap:.55rem;padding:.6rem 1rem;border-radius:100px;
            background:#fff;border:1px solid var(--line);font-size:.88rem;font-weight:600;color:var(--ink);box-shadow:var(--shadow-sm)}
        .value-chip svg{width:16px;height:16px;color:var(--cyan-deep)}

        /* ---------- Roles / tracks ---------- */
        .track{border-radius:var(--radius-lg);padding:clamp(1.6rem,2.6vw,2.2rem);position:relative;overflow:hidden}
        .track-editorial{background:linear-gradient(160deg,#fff,#F1FAFB);border:1px solid rgba(1,225,224,.3)}
        .track-community{background:linear-gradient(160deg,#02032E,#0A0E48);color:var(--text-invert);border:1px solid var(--ink-3)}
        .track h3{font-family:var(--font-display);font-weight:600;font-size:1.45rem;letter-spacing:-.01em}
        .track .k{font-family:var(--font-mono);font-size:.68rem;letter-spacing:.16em;text-transform:uppercase;font-weight:600}
        .track-editorial .k{color:var(--cyan-deep)}
        .track-community .k{color:var(--cyan-2)}
        .role-line{display:flex;gap:.7rem;align-items:flex-start;padding:.62rem 0;border-top:1px solid var(--line)}
        .track-community .role-line{border-top-color:rgba(255,255,255,.09)}
        .role-line:first-of-type{border-top:none}
        .role-line b{font-weight:700;font-size:.95rem}
        .role-line small{display:block;font-size:.8rem;color:var(--text-soft);margin-top:.1rem}
        .track-community .role-line small{color:var(--muted-invert)}
        .role-tick{flex:0 0 auto;width:20px;height:20px;border-radius:6px;display:grid;place-items:center;margin-top:1px;
            background:rgba(1,225,224,.14);color:var(--cyan-deep)}
        .track-community .role-tick{background:rgba(1,225,224,.16);color:var(--cyan-2)}
        .role-tick svg{width:12px;height:12px}
        .tag{display:inline-flex;align-items:center;gap:.4rem;font-family:var(--font-mono);font-size:.64rem;font-weight:600;
            letter-spacing:.08em;text-transform:uppercase;padding:.28rem .6rem;border-radius:7px}
        .tag-volunteer{background:rgba(52,110,255,.14);color:#5A8BFF}
        .tag-revshare{background:rgba(1,225,224,.16);color:var(--cyan-2)}
        .tag-paid{background:rgba(52,211,153,.16);color:#34D399}

        /* ---------- Collaboration / revenue-share info card ---------- */
        .collab{border-radius:var(--radius-lg);padding:clamp(1.8rem,3vw,2.6rem);
            background:radial-gradient(700px 340px at 100% 0,rgba(1,225,224,.14),transparent 60%),linear-gradient(160deg,#02032E,#0A0E48);
            color:var(--text-invert);border:1px solid var(--ink-3);position:relative;overflow:hidden}
        .collab .badge{display:inline-flex;align-items:center;gap:.5rem;font-family:var(--font-mono);font-size:.68rem;
            letter-spacing:.16em;text-transform:uppercase;color:var(--cyan-2);padding:.35rem .8rem;border-radius:100px;
            border:1px solid rgba(1,225,224,.3);background:rgba(1,225,224,.06)}

        /* ---------- Timeline ---------- */
        .timeline{position:relative;margin-top:2.5rem;padding-left:0}
        .tl-track{position:relative;display:grid;gap:1rem}
        .tl-step{position:relative;display:grid;grid-template-columns:auto 1fr;gap:1.15rem;align-items:start}
        .tl-node{position:relative;flex:0 0 auto;width:46px;height:46px;border-radius:14px;display:grid;place-items:center;
            font-family:var(--font-mono);font-weight:600;font-size:.9rem;color:var(--ink);
            background:#fff;border:1px solid var(--line);box-shadow:var(--shadow-sm);z-index:2}
        .tl-step.done .tl-node,.tl-step:hover .tl-node{background:linear-gradient(140deg,var(--cyan),var(--cyan-2));color:#00201F;border-color:transparent;box-shadow:var(--shadow-cyan)}
        .tl-line{position:absolute;left:22px;top:46px;bottom:-1rem;width:2px;background:linear-gradient(var(--cyan-deep),var(--line));opacity:.45}
        .tl-step:last-child .tl-line{display:none}
        .tl-body{background:#fff;border:1px solid var(--line);border-radius:var(--radius);padding:1.15rem 1.35rem;box-shadow:var(--shadow-sm);
            transition:transform .4s var(--ease),box-shadow .4s var(--ease),border-color .4s}
        .tl-step:hover .tl-body{transform:translateX(4px);border-color:rgba(1,225,224,.4);box-shadow:var(--shadow-md)}
        .tl-body h4{font-family:var(--font-display);font-weight:600;font-size:1.1rem;color:var(--ink)}
        .tl-body p{margin-top:.35rem;font-size:.9rem;color:var(--text-soft);line-height:1.6}
        .tl-when{font-family:var(--font-mono);font-size:.68rem;letter-spacing:.1em;text-transform:uppercase;color:var(--cyan-deep);font-weight:600}

        /* ---------- Apply section + form card ---------- */
        .apply-sec{background:linear-gradient(180deg,var(--paper) 0,#EEF4F7 100%);position:relative}
        .apply-card{background:#fff;border:1px solid var(--line);border-radius:28px;overflow:hidden;box-shadow:var(--shadow-md)}
        .apply-head{padding:1.4rem clamp(1.4rem,3vw,2.2rem);border-bottom:1px solid var(--line);
            background:linear-gradient(120deg,#FBFDFE,#F1FAFB);display:flex;flex-wrap:wrap;gap:1rem;align-items:center;justify-content:space-between}
        .apply-head h2{font-family:var(--font-display);font-weight:600;font-size:1.3rem;color:var(--ink)}
        .apply-head .sub{font-family:var(--font-mono);font-size:.72rem;color:var(--text-soft);letter-spacing:.02em;margin-top:.15rem}
        .apply-progress{display:flex;align-items:center;gap:.85rem}
        .apply-progress .bar{width:130px;height:7px;border-radius:100px;background:#E4EDF1;overflow:hidden}
        #progressBar{height:100%;background:linear-gradient(90deg,var(--cyan-deep),var(--cyan));border-radius:100px;
            box-shadow:0 0 12px rgba(1,225,224,.5);transition:width .45s var(--ease)}
        #stepCounter{font-family:var(--font-mono);font-size:.72rem;font-weight:600;color:var(--text-soft);white-space:nowrap}

        /* ===== Premium retheme of the (verbatim) multi-step form ===== */
        #recruitmentForm{padding:clamp(1.5rem,3vw,2.4rem)!important}
        #recruitmentForm h3{font-family:var(--font-display)!important;font-weight:600!important;letter-spacing:-.01em;color:var(--ink)!important;font-size:1.3rem!important}
        #recruitmentForm h4{color:var(--ink)!important}
        #recruitmentForm label.block,#recruitmentForm label[for]{color:var(--text)!important}
        /* inputs */
        #recruitmentForm input[type="text"],#recruitmentForm input[type="email"],
        #recruitmentForm input[type="tel"],#recruitmentForm input[type="url"],
        #recruitmentForm select,#recruitmentForm textarea{
            width:100%;background:#fff!important;border:1.5px solid var(--line-2)!important;border-radius:13px!important;
            padding:.8rem 1rem!important;font-family:var(--font-sans)!important;font-size:.95rem!important;color:var(--text)!important;
            min-height:46px;transition:border-color .2s,box-shadow .25s,background .2s;box-shadow:none!important;outline:none!important}
        #recruitmentForm textarea{line-height:1.6;min-height:auto}
        #recruitmentForm select{appearance:none;-webkit-appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='14' height='14' fill='none' stroke='%230B8A96' stroke-width='2.2' viewBox='0 0 24 24'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E")!important;
            background-repeat:no-repeat!important;background-position:right 1rem center!important;padding-right:2.6rem!important}
        #recruitmentForm input:focus,#recruitmentForm select:focus,#recruitmentForm textarea:focus{
            border-color:var(--cyan-deep)!important;box-shadow:0 0 0 4px rgba(1,225,224,.16)!important;background:#FCFFFF!important}
        #recruitmentForm input::placeholder,#recruitmentForm textarea::placeholder{color:#9AA7B8;opacity:1}
        /* selection cards */
        #recruitmentForm label.cursor-pointer,#recruitmentForm label.select-none{
            transition:border-color .25s,background .25s,box-shadow .3s,transform .25s;border-radius:15px!important}
        #recruitmentForm label:has(input:checked),#recruitmentForm label.is-selected{
            border-color:var(--cyan-deep)!important;
            background:linear-gradient(150deg,rgba(1,225,224,.12),rgba(1,225,224,.04))!important;
            box-shadow:0 0 0 3px rgba(1,225,224,.18),0 10px 26px -14px rgba(1,225,224,.6)!important}
        #recruitmentForm .selection-radio-circle{border-color:#C3CEDA!important;transition:.2s}
        #recruitmentForm label:has(input:checked) .selection-radio-circle,#recruitmentForm label.is-selected .selection-radio-circle{
            border-color:var(--cyan-deep)!important;background:var(--cyan-deep)!important;color:#fff!important}
        #recruitmentForm label:has(input:checked) .selection-checkmark,#recruitmentForm label.is-selected .selection-checkmark{
            display:inline-flex!important;opacity:1!important}
        #recruitmentForm input[type="checkbox"],#recruitmentForm input[type="radio"]{accent-color:var(--cyan-deep)}
        /* form buttons */
        #recruitmentForm button[onclick*="nextStep"],#recruitmentForm #submitBtn{
            background:linear-gradient(120deg,var(--cyan-deep),var(--cyan))!important;color:#00201F!important;font-weight:700!important;
            border:none!important;border-radius:13px!important;padding:.8rem 1.5rem!important;box-shadow:0 12px 30px -14px rgba(1,225,224,.8)!important;
            transition:transform .35s var(--ease),box-shadow .35s var(--ease)!important;position:relative;overflow:hidden}
        #recruitmentForm button[onclick*="nextStep"]:hover,#recruitmentForm #submitBtn:hover{transform:translateY(-2px)!important;box-shadow:0 18px 40px -14px rgba(1,225,224,.95)!important}
        #recruitmentForm button[onclick*="prevStep"]{border:1.5px solid var(--line-2)!important;border-radius:13px!important;color:var(--text)!important;background:#fff!important;font-weight:600!important;transition:.25s}
        #recruitmentForm button[onclick*="prevStep"]:hover{border-color:var(--cyan-deep)!important;background:#F7FEFE!important}
        #recruitmentForm .form-step{display:none}
        #recruitmentForm .form-step.active{display:block;animation:stepIn .5s var(--ease)}
        @keyframes stepIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
        /* pill add-buttons (custom modules / tools / portfolio) */
        #recruitmentForm button[onclick*="add"]{border-radius:11px!important}

        /* Review summary injected into final step */
        #reviewSummary{margin-bottom:1.6rem;border:1px solid var(--line);border-radius:18px;overflow:hidden;background:#FBFDFE}
        #reviewSummary .rev-top{padding:.9rem 1.1rem;background:linear-gradient(120deg,#F1FAFB,#EAF7F8);border-bottom:1px solid var(--line);
            display:flex;align-items:center;gap:.6rem;font-family:var(--font-display);font-weight:600;color:var(--ink);font-size:1.02rem}
        .rev-block{padding:.85rem 1.1rem;border-top:1px solid var(--line);display:flex;justify-content:space-between;gap:1rem;align-items:flex-start}
        .rev-block:first-of-type{border-top:none}
        .rev-k{font-family:var(--font-mono);font-size:.66rem;letter-spacing:.1em;text-transform:uppercase;color:var(--text-soft);font-weight:600;flex:0 0 34%}
        .rev-v{font-size:.9rem;color:var(--text);flex:1;line-height:1.55}
        .rev-v .chip{display:inline-block;background:rgba(1,225,224,.12);color:#0A6E79;border:1px solid rgba(1,225,224,.3);
            border-radius:100px;padding:.15rem .6rem;font-size:.76rem;font-weight:600;margin:0 .3rem .3rem 0}
        .rev-edit{background:none;border:none;color:var(--cyan-deep);font-weight:700;font-size:.78rem;cursor:pointer;white-space:nowrap;font-family:var(--font-sans)}
        .rev-edit:hover{text-decoration:underline}
        .rev-empty{color:#9AA7B8;font-style:italic}

        /* Premium success panel */
        #successPanel{display:none}
        #successPanel.show{display:block;animation:stepIn .6s var(--ease)}
        .success-card{background:radial-gradient(700px 320px at 50% -10%,rgba(1,225,224,.16),transparent 60%),linear-gradient(160deg,#02032E,#0A0E48);
            color:var(--text-invert);border:1px solid var(--ink-3);border-radius:28px;padding:clamp(2rem,5vw,3.4rem);text-align:center;box-shadow:var(--shadow-md)}
        .success-check{width:88px;height:88px;margin:0 auto 1.4rem;border-radius:50%;display:grid;place-items:center;
            background:radial-gradient(circle,rgba(1,225,224,.25),transparent 70%)}
        .success-check svg{width:88px;height:88px}
        .success-check circle{fill:none;stroke:var(--cyan);stroke-width:4;stroke-dasharray:264;stroke-dashoffset:264;animation:dash 1s var(--ease) .1s forwards}
        .success-check path{fill:none;stroke:var(--cyan);stroke-width:5;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:60;stroke-dashoffset:60;animation:dash .5s var(--ease) .7s forwards}
        @keyframes dash{to{stroke-dashoffset:0}}
        .success-card h2{font-family:var(--font-display);font-weight:600;font-size:clamp(1.7rem,4vw,2.4rem);color:#F4FEFF}
        .success-card .code{display:inline-flex;align-items:center;gap:.5rem;font-family:var(--font-mono);font-weight:600;
            background:rgba(1,225,224,.1);border:1px solid rgba(1,225,224,.35);color:var(--cyan-2);padding:.55rem 1rem;border-radius:12px;margin-top:1.1rem;letter-spacing:.05em}
        .success-next{margin-top:1.8rem;display:grid;gap:.7rem;text-align:left;max-width:440px;margin-left:auto;margin-right:auto}
        .success-next .sn{display:flex;gap:.75rem;align-items:flex-start;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:.85rem 1rem}
        .success-next .sn b{font-size:.9rem;color:#EAFDFE}
        .success-next .sn small{display:block;color:var(--muted-invert);font-size:.8rem;margin-top:.15rem}
        .success-next .sn .n{flex:0 0 auto;width:26px;height:26px;border-radius:8px;display:grid;place-items:center;
            font-family:var(--font-mono);font-weight:600;font-size:.78rem;background:rgba(1,225,224,.16);color:var(--cyan-2)}

        /* ---------- FAQ ---------- */
        .faq-item{border:1px solid var(--line);border-radius:16px;background:#fff;margin-bottom:.75rem;overflow:hidden;transition:border-color .3s,box-shadow .3s}
        .faq-item:hover{border-color:rgba(1,225,224,.4)}
        .faq-q{width:100%;text-align:left;padding:1.15rem 1.35rem;background:none;border:none;cursor:pointer;
            display:flex;align-items:center;justify-content:space-between;gap:1rem;font-family:var(--font-sans);
            font-weight:600;font-size:1rem;color:var(--ink)}
        .faq-ico{flex:0 0 auto;width:26px;height:26px;border-radius:8px;display:grid;place-items:center;
            background:rgba(1,225,224,.12);color:var(--cyan-deep);font-weight:700;font-size:1.1rem;transition:transform .3s,background .3s}
        .faq-a{padding:0 1.35rem;color:var(--text-soft);font-size:.94rem;line-height:1.7;
            max-height:0;overflow:hidden;transition:max-height .4s var(--ease),padding .3s}
        .faq-a.open{max-height:600px;padding:0 1.35rem 1.3rem}
        .faq-q[aria-expanded="true"] .faq-ico{transform:rotate(45deg);background:rgba(1,225,224,.22)}

        /* ---------- Conditional question reveal/collapse ---------- */
        /* Any follow-up field/section carries .cond-wrap; JS still just toggles
           the existing "hidden" class, this makes that toggle animate smoothly
           instead of snapping, and collapses to zero space when hidden. */
        #recruitmentForm .cond-wrap{display:block!important;overflow:hidden;max-height:0;opacity:0;
            transition:max-height .4s var(--ease),opacity .3s ease}
        #recruitmentForm .cond-wrap:not(.hidden){max-height:2000px;opacity:1}

        /* ---------- Footer ---------- */
        .foot{position:relative;overflow:hidden;background:linear-gradient(180deg,#02032E,#01002A);color:var(--muted-invert)}
        .foot::before{content:"";position:absolute;inset:0;opacity:.4;pointer-events:none;
            background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='56' height='97' viewBox='0 0 56 97'%3E%3Cpath fill='none' stroke='%23132e52' stroke-width='1' d='M28 0l28 16v33L28 65 0 49V16z'/%3E%3C/svg%3E");background-size:56px 97px;
            -webkit-mask-image:linear-gradient(180deg,#000,transparent 70%);mask-image:linear-gradient(180deg,#000,transparent 70%)}
        .foot-inner{position:relative;z-index:2;max-width:1180px;margin:0 auto;padding:clamp(3rem,6vw,4.5rem) clamp(1.15rem,4vw,2rem) 2rem}
        .foot-logo{height:44px;width:44px;border-radius:12px;object-fit:contain;mix-blend-mode:screen;filter:drop-shadow(0 0 18px rgba(1,225,224,.5))}
        .foot h4{font-family:var(--font-display);font-weight:600;color:#EAFDFE;font-size:1.35rem}
        .foot-ecg{width:100%;height:38px;opacity:.55;margin:1.4rem 0}
        .foot-ecg path{fill:none;stroke:var(--cyan);stroke-width:1.5;opacity:.6}
        .foot a{color:var(--muted-invert);text-decoration:none;transition:color .2s}
        .foot a:hover{color:var(--cyan-2)}
        .foot-bottom{border-top:1px solid rgba(255,255,255,.08);margin-top:2.2rem;padding-top:1.4rem;
            display:flex;flex-wrap:wrap;gap:.6rem 1.2rem;justify-content:space-between;font-size:.8rem}
        .foot-social{display:flex;gap:.6rem;margin-top:1.2rem}
        .social-ico{display:inline-flex;align-items:center;justify-content:center;width:38px;height:38px;
            border-radius:11px;border:1px solid rgba(224,251,252,.18);color:var(--muted-invert);
            background:rgba(255,255,255,.03);transition:transform .35s var(--ease),color .25s,border-color .25s,background .25s}
        .social-ico:hover{transform:translateY(-3px);color:var(--cyan-2);border-color:rgba(1,225,224,.45);background:rgba(1,225,224,.08)}
        .social-ico svg{width:18px;height:18px}

        /* ---------- Back to top ---------- */
        #backTop{position:fixed;right:22px;bottom:22px;z-index:55;width:48px;height:48px;border-radius:14px;border:none;cursor:pointer;
            display:grid;place-items:center;background:linear-gradient(140deg,var(--cyan-deep),var(--cyan));color:#00201F;
            box-shadow:var(--shadow-cyan);opacity:0;transform:translateY(14px) scale(.9);pointer-events:none;transition:.4s var(--ease)}
        #backTop.show{opacity:1;transform:none;pointer-events:auto}
        #backTop:hover{transform:translateY(-3px)}

        /* ---------- Reveal on scroll ---------- */
        .reveal{opacity:0;transform:translateY(22px);transition:opacity .7s var(--ease),transform .7s var(--ease)}
        .reveal.in{opacity:1;transform:none}
        .reveal.d1{transition-delay:.08s}.reveal.d2{transition-delay:.16s}.reveal.d3{transition-delay:.24s}

        /* ---------- Responsive ---------- */
        @media(max-width:860px){
            .nav-links{display:none}
            .nav-toggle{display:flex}
            .grid-3{grid-template-columns:1fr}
            .grid-2{grid-template-columns:1fr}
            .stats-grid{grid-template-columns:1fr}
            .stat{border-left:none;border-top:1px solid var(--line)}
            .stat:first-child{border-top:none}
            .rev-block{flex-direction:column;gap:.35rem}
            .rev-k{flex-basis:auto}
        }
        @media(prefers-reduced-motion:reduce){
            *{animation-duration:.001ms!important;animation-iteration-count:1!important;transition-duration:.001ms!important;scroll-behavior:auto!important}
            .reveal{opacity:1;transform:none}
            .ecg path{stroke-dashoffset:0}
        }

        /* ---------- Recruitment form: phone-specific fixes ---------- */
        @media(max-width:640px){
            /* Role/selection cards and every checkbox-chip grid inside the
               form default to 2 columns even on narrow phones (Tailwind's
               grid-cols-2 applies below its own sm: breakpoint too), which
               crowds labels and forces awkward text wrapping. Force a single
               column below this breakpoint; sm:grid-cols-X still takes over
               normally at/above 640px. */
            #recruitmentForm .grid-cols-2{grid-template-columns:1fr}
            /* Radio/checkbox rows that sit side-by-side (Yes/No toggles,
               reorder-style rows) can get cramped next to their labels. */
            #recruitmentForm .flex.items-center.gap-6{flex-wrap:wrap;row-gap:.5rem}
            /* Step nav buttons: keep them full-width and stacked so long
               labels never truncate or force horizontal scrolling. */
            #recruitmentForm .mt-8.flex.justify-between{flex-direction:column-reverse;gap:.75rem}
            #recruitmentForm .mt-8.flex.justify-between button{width:100%;text-align:center}
            /* iOS Safari auto-zooms the whole page when a focused input's
               font-size is under 16px, which then leaves the keyboard
               covering the field until the user manually pinches back out.
               Bump every form control to 16px on phones only; desktop sizing
               (text-xs/text-sm) is untouched. */
            #recruitmentForm input, #recruitmentForm select, #recruitmentForm textarea{font-size:16px}
        }
    </style>
</head>

<body>
<div id="scrollProgress"></div>

<!-- ========================= NAV ========================= -->
<header class="nav" id="siteNav">
    <div class="nav-inner">
        <a href="index.php" class="brand" aria-label="L'EXTERNE home">
            <img src="assets/images/logo.png" alt="L'EXTERNE logo" class="brand-tile" width="42" height="42">
            <span class="brand-word">L'EXTERNE</span>
            <?php $__open = ($recruitment_status === 'open'); ?>
            <span class="status-pill <?php echo $__open ? 'status-open':'status-closed'; ?>">
                <span class="status-dot"></span><?php echo $__open ? 'Recruiting' : 'Closed'; ?>
            </span>
        </a>
        <nav class="nav-links" aria-label="Primary">
            <a href="#about">Mission</a>
            <a href="#roles">Roles</a>
            <a href="#process">Process</a>
            <a href="#faq">FAQ</a>
            <?php if ($__open): ?><a href="#apply" class="btn btn-primary" style="padding:.6rem 1.15rem;font-size:.9rem">Apply now</a><?php endif; ?>
        </nav>
        <button class="nav-toggle" id="navToggle" aria-label="Open menu" aria-expanded="false">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M4 7h16M4 12h16M4 17h16"/></svg>
        </button>
    </div>
    <div class="mobile-menu" id="mobileMenu">
        <a href="#about">Mission</a>
        <a href="#roles">Roles</a>
        <a href="#process">Process</a>
        <a href="#faq">FAQ</a>
        <?php if ($__open): ?><a href="#apply">Apply now</a><?php endif; ?>
    </div>
</header>

<main>
<!-- ========================= HERO ========================= -->
<section class="hero">
    <div class="hero-grain"></div>
    <span class="blob blob-a"></span>
    <span class="blob blob-b"></span>
    <div class="hero-inner">
        <div class="hero-logo-wrap">
            <img src="assets/images/logo.png" alt="" aria-hidden="true" class="hero-logo" width="96" height="96">
        </div>
        <span class="hero-eyebrow">Recruitment Campaign · 2026</span>
        <h1><?php echo htmlspecialchars($hero_title); ?></h1>
        <p class="hero-sub"><?php echo htmlspecialchars($hero_subtitle); ?></p>

        <?php if ($__open): ?>
        <div class="hero-cta">
            <a href="#apply" class="btn btn-primary">Start your application
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
            </a>
            <a href="#process" class="btn btn-ghost">See how it works</a>
        </div>
        <div class="hero-trust">
            <span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2l2.4 4.9 5.4.8-3.9 3.8.9 5.4L12 15.4 7.1 17.9l.9-5.4L4.1 8.7l5.4-.8z"/></svg> Elite medical creators</span>
            <span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6L9 17l-5-5"/></svg> 7–10 minute application</span>
            <span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg> Autosave enabled</span>
        </div>
        <?php else: ?>
        <div style="margin-top:2.4rem;max-width:520px;margin-left:auto;margin-right:auto;background:rgba(244,63,94,.08);border:1px solid rgba(244,63,94,.3);border-radius:20px;padding:1.6rem 1.8rem">
            <div style="display:flex;align-items:center;justify-content:center;gap:.6rem;color:#FF8FA3;font-family:var(--font-display);font-weight:600;font-size:1.15rem;margin-bottom:.5rem">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4.5" y="10.5" width="15" height="10" rx="2"/><path d="M8 10.5V7a4 4 0 018 0v3.5"/></svg>
                Recruitment is currently closed
            </div>
            <p style="color:var(--muted-invert);font-size:.92rem;line-height:1.6">Thank you for your interest. Our committee is reviewing the current cohort. Follow our Telegram channel to be first to know when the next campaign opens.</p>
        </div>
        <?php endif; ?>
    </div>

    <!-- ECG vital-line signature -->
    <svg class="ecg" viewBox="0 0 1200 120" preserveAspectRatio="none" aria-hidden="true">
        <defs>
            <linearGradient id="ecgGrad" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0" stop-color="#01E1E0" stop-opacity="0"/>
                <stop offset=".18" stop-color="#01E1E0" stop-opacity=".9"/>
                <stop offset=".85" stop-color="#5AF0EF" stop-opacity=".9"/>
                <stop offset="1" stop-color="#5AF0EF" stop-opacity="0"/>
            </linearGradient>
        </defs>
        <path d="M0 80 H360 l24 0 l14 -46 l18 78 l16 -60 l14 34 l12 -6 H620 l40 0 l16 -30 l16 48 l14 -18 H1200"/>
    </svg>
    <div class="scroll-cue"><span class="mouse"></span>Scroll</div>
</section>

<!-- ========================= STATS ========================= -->
<section class="stats">
    <div class="wrap" style="padding-top:0;padding-bottom:0">
        <div class="stats-grid">
            <?php
            $__stats = [
                [get_setting('stats_books', '23+ Books Published'), 'Premium medical volumes'],
                [get_setting('stats_users', '5k+ Med Students'), 'Daily active Algerian readers'],
                [get_setting('stats_contributors', '45+ Team Members'), 'Collaborating creators'],
            ];
            foreach ($__stats as $s):
                // split leading number (for count-up) from the rest of the label text
                preg_match('/^\s*([\d\.]+)\s*(.*)$/u', $s[0], $m);
                $num = $m[1] ?? '';
                $suf = trim($m[2] ?? $s[0]);
            ?>
            <div class="stat reveal">
                <div class="num">
                    <?php if ($num !== ''): ?><span class="count" data-target="<?php echo htmlspecialchars($num); ?>">0</span><span class="suf"><?php echo htmlspecialchars(preg_replace('/^([+kK]+).*/', '$1', $suf) ? substr($suf,0,strspn($suf,'+kK')) : ''); ?></span><?php else: ?><?php echo htmlspecialchars($s[0]); ?><?php endif; ?>
                </div>
                <div class="lbl"><?php echo htmlspecialchars($num !== '' ? ltrim(preg_replace('/^[+kK]+/', '', $suf)) : $s[1]); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- ========================= MISSION / WHY JOIN ========================= -->
<section id="about" class="section">
    <div class="wrap">
        <div style="max-width:640px" class="reveal">
            <span class="eyebrow">Our mission</span>
            <h2 class="h-section" style="margin-top:1rem">We craft the study material Algerian medical students actually deserve.</h2>
            <p class="lead" style="margin-top:1.1rem">L'EXTERNE builds clinical-first books, MCQ banks, and interactive tools for every year of the Algerian medical curriculum. Joining means shaping resources that thousands of your peers open before every exam.</p>
        </div>
        <div class="grid-3" style="margin-top:2.6rem">
            <div class="card reveal d1">
                <div class="card-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M4 5a2 2 0 012-2h8l6 6v10a2 2 0 01-2 2H6a2 2 0 01-2-2z"/><path d="M14 3v6h6"/><path d="M8 13h8M8 17h5"/></svg></div>
                <h3>Academic integrity</h3>
                <p>Every book and MCQ is cross-checked against Algerian faculty courses and international guidelines — accuracy is non-negotiable.</p>
            </div>
            <div class="card reveal d2">
                <div class="card-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 19l7-7a4 4 0 00-5.7-5.7l-7 7a2.5 2.5 0 003.5 3.5L17 10"/></svg></div>
                <h3>Design excellence</h3>
                <p>Crystal-clear anatomical infographics, custom vectors and Linear-grade layouts. We treat medical books as products, not PDFs.</p>
            </div>
            <div class="card reveal d3">
                <div class="card-ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 2l3 7h7l-5.5 4.5L18 21l-6-4-6 4 1.5-7.5L2 9h7z"/></svg></div>
                <h3>Tech &amp; community</h3>
                <p>A modern workspace where developers, community leads and designers collaborate with the best tools available.</p>
            </div>
        </div>

        <div class="value-row reveal" style="margin-top:2.4rem">
            <span class="value-chip"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6L9 17l-5-5"/></svg> Clinical accuracy</span>
            <span class="value-chip"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6L9 17l-5-5"/></svg> Student-first</span>
            <span class="value-chip"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6L9 17l-5-5"/></svg> Craft over shortcuts</span>
            <span class="value-chip"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6L9 17l-5-5"/></svg> Long-term thinking</span>
            <span class="value-chip"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 6L9 17l-5-5"/></svg> Ownership</span>
        </div>
    </div>
</section>

<!-- ========================= ROLES / TRACKS ========================= -->
<section id="roles" class="section" style="background:linear-gradient(180deg,#fff,var(--paper))">
    <div class="wrap">
        <div style="max-width:640px" class="reveal">
            <span class="eyebrow">What we look for</span>
            <h2 class="h-section" style="margin-top:1rem">Two tracks. One standard of excellence.</h2>
            <p class="lead" style="margin-top:1.1rem">Pick the track that fits your strengths — or apply to both. Here's exactly what each role involves before you commit.</p>
        </div>

        <div class="grid-2" style="margin-top:2.6rem;align-items:start">
            <div class="track track-editorial reveal d1">
                <span class="k">Track 01</span>
                <h3 style="margin:.4rem 0 .2rem">✍️ Editorial</h3>
                <p style="color:var(--text-soft);font-size:.92rem;line-height:1.6;margin-bottom:1rem">Authors, reviewers and designers who build the books and MCQ banks.</p>
                <div class="role-line"><span class="role-tick"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M20 6L9 17l-5-5"/></svg></span><span><b>Book Writer</b><small>Author clinical study texts for your modules.</small></span></div>
                <div class="role-line"><span class="role-tick"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M20 6L9 17l-5-5"/></svg></span><span><b>MCQ Writer</b><small>Draft faculty-grade practice questions with answers.</small></span></div>
                <div class="role-line"><span class="role-tick"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M20 6L9 17l-5-5"/></svg></span><span><b>Book Updater</b><small>Correct, verify and refresh existing volumes.</small></span></div>
                <div class="role-line"><span class="role-tick"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M20 6L9 17l-5-5"/></svg></span><span><b>Book Designer</b><small>Infographics, covers and full book layouts.</small></span></div>
                <div style="margin-top:1.1rem;display:flex;flex-wrap:wrap;gap:.4rem">
                    <span class="tag tag-revshare">Revenue-share</span>
                    <span class="tag" style="background:rgba(6,16,44,.06);color:var(--text-soft)">≈ 5–20 hrs / week</span>
                </div>
            </div>

            <div class="track track-community reveal d2">
                <span class="k">Track 02</span>
                <h3 style="margin:.4rem 0 .2rem;color:#EAFDFE">👥 Community</h3>
                <p style="color:var(--muted-invert);font-size:.92rem;line-height:1.6;margin-bottom:1rem">Operations, tech, marketing and events — the people who grow L'EXTERNE.</p>
                <div class="role-line"><span class="role-tick"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M20 6L9 17l-5-5"/></svg></span><span><b>Marketing &amp; Communication</b><small>Content, social growth and campaigns.</small></span></div>
                <div class="role-line"><span class="role-tick"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M20 6L9 17l-5-5"/></svg></span><span><b>Technology</b><small>Frontend, backend, mobile and automation.</small></span></div>
                <div class="role-line"><span class="role-tick"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><path d="M20 6L9 17l-5-5"/></svg></span><span><b>Events &amp; Partnerships · HR · Operations</b><small>Run the engine behind the community.</small></span></div>
                <div style="margin-top:1.1rem;display:flex;flex-wrap:wrap;gap:.4rem">
                    <span class="tag tag-volunteer">Volunteer-based</span>
                    <span class="tag" style="background:rgba(255,255,255,.08);color:var(--muted-invert)">Flexible hours</span>
                </div>
                <p style="margin-top:1rem;font-size:.8rem;color:var(--muted-invert);border-top:1px solid rgba(255,255,255,.09);padding-top:.9rem">
                    Community positions are volunteer roles for members who want to help grow and support the medical-student community.
                </p>
            </div>
        </div>
    </div>
</section>

<!-- ========================= COLLABORATION / REVENUE-SHARE ========================= -->
<section class="section" style="padding-top:0">
    <div class="wrap">
        <div class="collab reveal">
            <span class="badge">Collaboration model</span>
            <div class="grid-2" style="margin-top:1.4rem;align-items:center;gap:2rem">
                <div>
                    <h3 class="serif" style="font-size:clamp(1.5rem,3vw,2rem);color:#F4FEFF;line-height:1.15;font-weight:600">Grow alongside the platform you help build.</h3>
                    <p style="margin-top:.9rem;color:var(--muted-invert);font-size:.98rem;line-height:1.7">L'EXTERNE collaborates with many contributors through a percentage-based revenue-sharing model that varies by project and role — so the people who create the value share in it. Community roles are volunteer-based, and select technical or editorial engagements may be paid where relevant.</p>
                </div>
                <div style="display:grid;gap:.7rem">
                    <div style="display:flex;gap:.75rem;align-items:flex-start;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:1rem 1.1rem">
                        <span class="tag tag-revshare" style="margin-top:.1rem">Revenue-share</span>
                        <span style="font-size:.88rem;color:var(--muted-invert)">Editorial & design work on published volumes.</span>
                    </div>
                    <div style="display:flex;gap:.75rem;align-items:flex-start;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:1rem 1.1rem">
                        <span class="tag tag-volunteer" style="margin-top:.1rem">Volunteer</span>
                        <span style="font-size:.88rem;color:var(--muted-invert)">Community, moderation and student-success roles.</span>
                    </div>
                    <div style="display:flex;gap:.75rem;align-items:flex-start;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:1rem 1.1rem">
                        <span class="tag tag-paid" style="margin-top:.1rem">Paid</span>
                        <span style="font-size:.88rem;color:var(--muted-invert)">Selected specialist engagements, where applicable.</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ========================= PROCESS / TIMELINE ========================= -->
<section id="process" class="section" style="background:linear-gradient(180deg,var(--paper),#fff)">
    <div class="wrap">
        <div style="max-width:640px" class="reveal">
            <span class="eyebrow">The journey</span>
            <h2 class="h-section" style="margin-top:1rem">What happens after you apply.</h2>
            <p class="lead" style="margin-top:1.1rem">A clear, structured path — no black boxes. Here's exactly where your application goes.</p>
        </div>
        <div class="timeline reveal" style="max-width:760px">
            <div class="tl-track">
                <?php
                $__steps = [
                    ['Now','Submit application','Complete the guided form below. It autosaves, so you can finish whenever suits you.'],
                    ['1–5 days','Application review','Our committee reviews your profile, modules and motivation.'],
                    ['If shortlisted','Interactive assignment','A short role-based task — e.g. structure a mini module guide or a set of MCQs.'],
                    ['~15 min','Onboarding conversation','A friendly chat with a team lead to align on duties and expectations.'],
                    ['Final','Decision & onboarding','You get a clear answer, and if it\'s a yes, we welcome you into the workspace.'],
                ];
                foreach ($__steps as $i => $st):
                ?>
                <div class="tl-step<?php echo $i===0?' done':''; ?>">
                    <div style="position:relative">
                        <div class="tl-node"><?php echo str_pad($i+1,2,'0',STR_PAD_LEFT); ?></div>
                        <span class="tl-line"></span>
                    </div>
                    <div class="tl-body">
                        <span class="tl-when"><?php echo htmlspecialchars($st[0]); ?></span>
                        <h4 style="margin-top:.2rem"><?php echo htmlspecialchars($st[1]); ?></h4>
                        <p><?php echo htmlspecialchars($st[2]); ?></p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</section>

<?php if ($__open): ?>
<!-- ========================= APPLY ========================= -->
<section id="apply" class="section apply-sec">
    <div class="wrap-narrow">
        <div style="text-align:center;max-width:560px;margin:0 auto 2.2rem" class="reveal">
            <span class="eyebrow" style="justify-content:center">Application</span>
            <h2 class="h-section" style="margin-top:1rem">Join the next cohort</h2>
            <p class="lead" style="margin-top:.9rem">Seven quick steps. Everything autosaves. You'll review before anything is submitted.</p>
        </div>

        <div class="apply-card reveal" id="applyCard">
            <div class="apply-head">
                <div>
                    <h2>Application form</h2>
                    <div class="sub">L'EXTERNE Recruitment Committee</div>
                </div>
                <div class="apply-progress">
                    <div class="bar"><div id="progressBar" style="width:14.28%"></div></div>
                    <span id="stepCounter">Step 1 of 7</span>
                </div>
            </div>

                    <form id="recruitmentForm" action="api.php" method="POST" class="px-8 py-8 space-y-8" onsubmit="submitForm(event)">
                        
                        <!-- CSRF + Action Token -->
                        <input type="hidden" name="action" value="submit_application">
                        <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">

                        <!-- STEP 1: WELCOME & STAGES -->
                        <div class="form-step active" data-step="1">
                            <div class="text-center py-6">
                                <div class="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-sky-50 text-sky-600 text-xl font-bold">
                                    🏥
                                </div>
                                <h3 class="mt-4 text-2xl font-bold tracking-tight text-slate-900">Welcome to L'EXTERNE</h3>
                                <p class="mt-2 text-sm text-slate-600 max-w-md mx-auto">
                                    Algeria's premiere clinical-first medical creators portal. We appreciate your interest. Let's build together!
                                </p>
                            </div>

                            <div class="mt-8 border border-slate-100 rounded-2xl bg-slate-50/40 p-6 space-y-4">
                                <h4 class="text-sm font-bold text-slate-800">Recruitment Campaign Overview</h4>
                                <ul class="space-y-3 text-xs text-slate-600">
                                    <li class="flex items-center gap-2">
                                        <span class="text-sky-600 font-bold">⏱️</span> Estimated completion time: <strong>7–10 minutes</strong>
                                    </li>
                                    <li class="flex items-center gap-2">
                                        <span class="text-sky-600 font-bold">🗺️</span> 2 Career Paths: <strong>Editorial</strong> (Writers/Designers) and <strong>Community</strong> (Tech/HR/Operations)
                                    </li>
                                    <li class="flex items-center gap-2">
                                        <span class="text-sky-600 font-bold">⚡</span> Standard autosave enabled. Resume whenever you wish!
                                    </li>
                                </ul>
                            </div>

                            <div class="mt-8 flex justify-end">
                                <button type="button" onclick="nextStep()" class="px-5 py-2.5 bg-sky-600 hover:bg-sky-500 text-white text-sm font-semibold rounded-xl shadow-sm transition-colors">
                                    Begin Application
                                </button>
                            </div>
                        </div>

                        <!-- STEP 2: PERSONAL IDENTITY & UNIVERSITIES -->
                        <div class="form-step" data-step="2">
                            <div class="space-y-6">
                                <h3 class="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3">Personal & Faculty Identity</h3>

                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                                    <!-- Full Name -->
                                    <div>
                                        <label for="full_name" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Full Name *</label>
                                        <input type="text" id="full_name" name="full_name" required placeholder="Dr. Sofia Ben" class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-sky-500 focus:outline-none transition-colors">
                                    </div>

                                    <!-- Email -->
                                    <div>
                                        <label for="email" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Email Address *</label>
                                        <input type="email" id="email" name="email" required placeholder="sofia@email.com" class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-sky-500 focus:outline-none transition-colors">
                                    </div>

                                    <!-- WhatsApp -->
                                    <div>
                                        <label for="whatsapp" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">WhatsApp Contact *</label>
                                        <input type="tel" id="whatsapp" name="whatsapp" required placeholder="+213 555 123 456" class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-sky-500 focus:outline-none transition-colors">
                                    </div>

                                    <!-- Telegram Username -->
                                    <div>
                                        <label for="telegram" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Telegram Username *</label>
                                        <input type="text" id="telegram" name="telegram" required placeholder="@sofia_extern" onblur="validateTelegram(this)" class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-sky-500 focus:outline-none transition-colors">
                                        <p id="telegramError" class="hidden text-xs text-rose-500 font-semibold mt-1">Telegram username must begin with @</p>
                                    </div>

                                    <!-- Faculty -->
                                    <div>
                                        <label for="faculty" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Medical Faculty *</label>
                                        <select id="faculty" name="faculty" required class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-sky-500 focus:outline-none bg-white transition-colors" onchange="toggleOtherWrapper(this, 'faculty_other_wrapper')">
                                            <option value="">Choose Faculty</option>
                                            <?php foreach (get_universities_list() as $uni): ?>
                                                <option value="<?php echo htmlspecialchars($uni); ?>"><?php echo htmlspecialchars($uni); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div id="faculty_other_wrapper" class="hidden cond-wrap mt-2">
                                            <input type="text" id="faculty_other" placeholder="Please specify your faculty" class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-sky-500 focus:outline-none">
                                        </div>
                                    </div>

                                    <!-- Academic Year -->
                                    <div>
                                        <label for="academic_year" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Academic Year *</label>
                                        <select id="academic_year" name="academic_year" required class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-sky-500 focus:outline-none bg-white transition-colors" onchange="toggleOtherWrapper(this, 'academic_year_other_wrapper')">
                                            <option value="">Choose Year</option>
                                            <?php foreach (get_academic_years() as $year): ?>
                                                <option value="<?php echo htmlspecialchars($year); ?>"><?php echo htmlspecialchars($year); ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div id="academic_year_other_wrapper" class="hidden cond-wrap mt-2">
                                            <input type="text" id="academic_year_other" placeholder="Please specify your academic year" class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-sky-500 focus:outline-none">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="mt-8 flex justify-between">
                                <button type="button" onclick="prevStep()" class="px-5 py-2.5 border border-slate-200 text-slate-700 text-sm font-semibold rounded-xl hover:bg-slate-50 transition-colors">Previous</button>
                                <button type="button" onclick="nextStep()" class="px-5 py-2.5 bg-sky-600 hover:bg-sky-500 text-white text-sm font-semibold rounded-xl shadow-sm transition-colors">Next Stage</button>
                            </div>
                        </div>

                        <!-- STEP 3: RECRUITMENT PATHS -->
                        <div class="form-step" data-step="3">
                            <div class="space-y-6">
                                <h3 class="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3">Choose Recruitment Path</h3>
                                <p class="text-xs text-slate-500 font-medium">Select the path matching your profile. You can apply to both.</p>

                                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                                    <!-- Editorial Card -->
                                    <label class="relative flex flex-col p-6 rounded-2xl border border-slate-200 cursor-pointer hover:border-sky-300 transition-all select-none">
                                        <input type="radio" name="recruitment_path" value="Editorial" class="sr-only peer" required onchange="handlePathChange(this)">
                                        <div class="flex items-center justify-between mb-4">
                                            <div class="peer-checked:text-sky-600 h-5 w-5 rounded-full border border-slate-300 flex items-center justify-center peer-checked:border-sky-600 selection-radio-circle">
                                                <div class="h-2.5 w-2.5 rounded-full bg-sky-600 hidden peer-checked:block"></div>
                                            </div>
                                            <span class="selection-checkmark hidden text-sky-600 text-xs font-extrabold bg-sky-100 px-2 py-0.5 rounded-full">✓ Selected</span>
                                        </div>
                                        <span class="text-base font-bold text-slate-900">✍️ Editorial</span>
                                        <span class="mt-2 text-xs text-slate-500 leading-normal">
                                            Apply as Book Writer, MCQ Writer, updater or medical graphic illustrator.
                                        </span>
                                    </label>

                                    <!-- Community Card -->
                                    <label class="relative flex flex-col p-6 rounded-2xl border border-slate-200 cursor-pointer hover:border-sky-300 transition-all select-none">
                                        <input type="radio" name="recruitment_path" value="Community" class="sr-only peer" required onchange="handlePathChange(this)">
                                        <div class="flex items-center justify-between mb-4">
                                            <div class="peer-checked:text-sky-600 h-5 w-5 rounded-full border border-slate-300 flex items-center justify-center peer-checked:border-sky-600 selection-radio-circle">
                                                <div class="h-2.5 w-2.5 rounded-full bg-sky-600 hidden peer-checked:block"></div>
                                            </div>
                                            <span class="selection-checkmark hidden text-sky-600 text-xs font-extrabold bg-sky-100 px-2 py-0.5 rounded-full">✓ Selected</span>
                                        </div>
                                        <span class="text-base font-bold text-slate-900">👥 Community</span>
                                        <span class="mt-2 text-xs text-slate-500 leading-normal">
                                            Join Operations, IT development, events, HR or social branding drives.
                                        </span>
                                    </label>

                                    <!-- Both Card -->
                                    <label class="relative flex flex-col p-6 rounded-2xl border border-slate-200 cursor-pointer hover:border-sky-300 transition-all select-none">
                                        <input type="radio" name="recruitment_path" value="Both" class="sr-only peer" required onchange="handlePathChange(this)">
                                        <div class="flex items-center justify-between mb-4">
                                            <div class="peer-checked:text-sky-600 h-5 w-5 rounded-full border border-slate-300 flex items-center justify-center peer-checked:border-sky-600 selection-radio-circle">
                                                <div class="h-2.5 w-2.5 rounded-full bg-sky-600 hidden peer-checked:block"></div>
                                            </div>
                                            <span class="selection-checkmark hidden text-sky-600 text-xs font-extrabold bg-sky-100 px-2 py-0.5 rounded-full">✓ Selected</span>
                                        </div>
                                        <span class="text-base font-bold text-slate-900">🔮 Both Tracks</span>
                                        <span class="mt-2 text-xs text-slate-500 leading-normal">
                                            You are interested in both writing and operational departments.
                                        </span>
                                    </label>
                                </div>
                            </div>

                            <div class="mt-8 flex justify-between">
                                <button type="button" onclick="prevStep()" class="px-5 py-2.5 border border-slate-200 text-slate-700 text-sm font-semibold rounded-xl hover:bg-slate-50 transition-colors">Previous</button>
                                <button type="button" onclick="nextStep()" class="px-5 py-2.5 bg-sky-600 hover:bg-sky-500 text-white text-sm font-semibold rounded-xl shadow-sm transition-colors">Next Stage</button>
                            </div>
                        </div>

                        <!-- STEP 4: EDITORIAL TEAM SPECIFICS (DYNAMIC DISPLAY) -->
                        <div class="form-step" data-step="4" id="editorial_step">
                            <div class="space-y-8">
                                <h3 class="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3">Editorial Profile Details</h3>

                                <!-- Roles -->
                                <div>
                                    <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-3">Roles of Interest *</label>
                                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
                                        <label class="relative flex flex-col p-4 border border-slate-200 rounded-xl cursor-pointer select-none transition-all">
                                            <input type="checkbox" name="roles[]" value="Book Writer" class="sr-only peer" onchange="toggleWriterFields()">
                                            <div class="flex items-center justify-between mb-1">
                                                <span class="text-sm font-bold block">✍️ Book Writer</span>
                                                <span class="selection-checkmark hidden text-sky-600 font-extrabold text-xs">✓</span>
                                            </div>
                                            <span class="text-[10px] text-slate-400">Author clinical study texts</span>
                                        </label>
                                        <label class="relative flex flex-col p-4 border border-slate-200 rounded-xl cursor-pointer select-none transition-all">
                                            <input type="checkbox" name="roles[]" value="MCQ Writer" class="sr-only peer" onchange="toggleWriterFields()">
                                            <div class="flex items-center justify-between mb-1">
                                                <span class="text-sm font-bold block">📝 MCQ Writer</span>
                                                <span class="selection-checkmark hidden text-sky-600 font-extrabold text-xs">✓</span>
                                            </div>
                                            <span class="text-[10px] text-slate-400">Draft faculty practice MCQs</span>
                                        </label>
                                        <label class="relative flex flex-col p-4 border border-slate-200 rounded-xl cursor-pointer select-none transition-all">
                                            <input type="checkbox" name="roles[]" value="Book Updater" class="sr-only peer" onchange="toggleWriterFields()">
                                            <div class="flex items-center justify-between mb-1">
                                                <span class="text-sm font-bold block">🔄 Book Updater</span>
                                                <span class="selection-checkmark hidden text-sky-600 font-extrabold text-xs">✓</span>
                                            </div>
                                            <span class="text-[10px] text-slate-400">Correct & verify study volumes</span>
                                        </label>
                                        <label class="relative flex flex-col p-4 border border-slate-200 rounded-xl cursor-pointer select-none transition-all">
                                            <input type="checkbox" name="roles[]" value="Book Designer" class="sr-only peer" onchange="toggleDesignerFields()">
                                            <div class="flex items-center justify-between mb-1">
                                                <span class="text-sm font-bold block">🎨 Book Designer</span>
                                                <span class="selection-checkmark hidden text-sky-600 font-extrabold text-xs">✓</span>
                                            </div>
                                            <span class="text-[10px] text-slate-400">Infographics & book layouts</span>
                                        </label>
                                    </div>
                                </div>

                                <!-- Dynamic Writer Fields (Grouped Modules per Academic Year) -->
                                <div id="writer_spec_container" class="hidden cond-wrap space-y-6">
                                    <h4 class="text-sm font-bold text-slate-800 border-l-4 border-sky-500 pl-3">Study Levels & Modules</h4>
                                    <p class="text-xs text-slate-500">Please choose the study years you feel comfortable writing/updating, and check the modules you excel in. Click "Other" to write custom ones.</p>
                                    
                                    <div class="space-y-6 bg-slate-50/40 p-5 rounded-2xl border border-slate-100">
                                        <?php 
                                        $modules_by_year = get_predefined_modules();
                                        $year_index = 0;
                                        foreach ($modules_by_year as $year => $mods): 
                                            $year_index++;
                                            $year_id_safe = "year_block_" . $year_index;
                                        ?>
                                            <div class="border-b border-slate-200/50 pb-4 last:border-b-0 last:pb-0">
                                                <div class="mb-3">
                                                    <label class="inline-flex items-center gap-2 cursor-pointer px-3 py-1.5 rounded-xl border border-slate-200 bg-white transition-all hover:border-sky-300">
                                                        <input type="checkbox" name="study_levels[]" value="<?php echo htmlspecialchars($year); ?>" class="rounded text-sky-600 focus:ring-sky-500" onchange="toggleYearModules('<?php echo $year_id_safe; ?>', this, '<?php echo htmlspecialchars($year, ENT_QUOTES); ?>')">
                                                        <span class="text-xs font-bold text-slate-800 uppercase tracking-wide"><?php echo htmlspecialchars($year); ?></span>
                                                        <span class="selection-checkmark hidden text-sky-600 font-extrabold text-xs ml-2">✓ Selected</span>
                                                    </label>
                                                </div>
                                                
                                                <!-- Modules wrapper -->
                                                <div id="<?php echo $year_id_safe; ?>" class="hidden cond-wrap grid grid-cols-2 sm:grid-cols-3 gap-3 ml-2 mt-2">
                                                    <?php foreach ($mods as $m): ?>
                                                        <?php if ($m === '➕ Other' || $m === '➕ Other (Custom Module)'): ?>
                                                            <div class="col-span-full mt-1">
                                                                <label class="inline-flex items-center gap-2 text-xs text-slate-700 font-medium cursor-pointer px-3 py-2 rounded-xl border border-dashed border-slate-300 bg-white hover:border-sky-400 transition-all">
                                                                    <input type="checkbox" value="Other" class="rounded text-sky-600" onchange="toggleCustomModuleInput('custom_input_<?php echo $year_index; ?>', this, '<?php echo htmlspecialchars($year, ENT_QUOTES); ?>', 'custom_list_<?php echo $year_index; ?>')">
                                                                    <span>➕ Custom Modules (Other)</span>
                                                                    <span class="selection-checkmark hidden text-sky-600 font-bold ml-auto text-xs">✓ Enabled</span>
                                                                </label>
                                                                <div id="custom_input_<?php echo $year_index; ?>" class="hidden cond-wrap mt-2 flex flex-col gap-2 p-3 bg-white rounded-xl border border-sky-100">
                                                                    <p class="text-[11px] text-slate-500 font-medium">Write custom module name below. It will be submitted directly with your application.</p>
                                                                    <div class="flex gap-2">
                                                                        <input type="text" placeholder="Type module name and click Add" id="txt_custom_<?php echo $year_index; ?>" class="rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:border-sky-500 focus:outline-none flex-grow">
                                                                        <button type="button" onclick="addCustomModule('<?php echo htmlspecialchars($year); ?>', 'txt_custom_<?php echo $year_index; ?>', 'custom_list_<?php echo $year_index; ?>')" class="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-bold shadow-sm transition-all">Add Module</button>
                                                                    </div>
                                                                    <div id="custom_list_<?php echo $year_index; ?>" class="flex flex-wrap gap-1.5 mt-1"></div>
                                                                </div>
                                                            </div>
                                                        <?php else: ?>
                                                            <label class="inline-flex items-center justify-between gap-2 text-xs text-slate-700 cursor-pointer p-2.5 rounded-xl border border-slate-200 bg-white transition-all hover:border-sky-300">
                                                                <div class="flex items-center gap-2">
                                                                    <input type="checkbox" name="modules[<?php echo htmlspecialchars($year); ?>][]" value="<?php echo htmlspecialchars($m); ?>" class="rounded text-sky-600 focus:ring-sky-500">
                                                                    <span class="font-medium"><?php echo htmlspecialchars($m); ?></span>
                                                                </div>
                                                                <span class="selection-checkmark hidden text-sky-600 font-extrabold text-xs">✓</span>
                                                            </label>
                                                        <?php endif; ?>
                                                    <?php endforeach; ?>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                </div>

                                <!-- Dynamic Designer Fields (Software proficiency) -->
                                <div id="designer_spec_container" class="hidden cond-wrap space-y-6">
                                    <h4 class="text-sm font-bold text-slate-800 border-l-4 border-sky-500 pl-3">Designer Specifics</h4>
                                    
                                    <div class="space-y-4 bg-slate-50/40 p-5 rounded-2xl border border-slate-100">
                                        <p class="text-xs font-bold text-slate-700 mb-3">Rate your proficiency in design softwares:</p>
                                        <?php foreach (get_tools_list() as $tool): ?>
                                            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 py-2 border-b border-slate-100 last:border-0">
                                                <span class="text-xs font-bold text-slate-600"><?php echo htmlspecialchars($tool); ?></span>
                                                <div class="flex items-center gap-4">
                                                    <label class="inline-flex items-center gap-1.5 text-xs text-slate-500">
                                                        <input type="radio" name="tools[<?php echo htmlspecialchars($tool); ?>]" value="Beginner" class="text-sky-600"> Beginner
                                                    </label>
                                                    <label class="inline-flex items-center gap-1.5 text-xs text-slate-500">
                                                        <input type="radio" name="tools[<?php echo htmlspecialchars($tool); ?>]" value="Intermediate" class="text-sky-600"> Intermediate
                                                    </label>
                                                    <label class="inline-flex items-center gap-1.5 text-xs text-slate-500">
                                                        <input type="radio" name="tools[<?php echo htmlspecialchars($tool); ?>]" value="Advanced" class="text-sky-600"> Advanced
                                                    </label>
                                                    <label class="inline-flex items-center gap-1.5 text-xs text-slate-500">
                                                        <input type="radio" name="tools[<?php echo htmlspecialchars($tool); ?>]" value="Expert" class="text-sky-600"> Expert
                                                    </label>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>

                                        <!-- Design specialties -->
                                        <div class="pt-2">
                                            <label class="block text-xs font-bold text-slate-600 mb-2">Design Specialties</label>
                                            <div class="grid grid-cols-2 sm:grid-cols-4 gap-2">
                                                <?php foreach (get_design_specialties_list() as $spec): ?>
                                                    <label class="inline-flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer p-2 rounded-lg border border-slate-200 bg-white hover:border-sky-300 transition-all">
                                                        <input type="checkbox" name="design_specialties[]" value="<?php echo htmlspecialchars($spec); ?>" class="rounded text-sky-600">
                                                        <span><?php echo htmlspecialchars($spec); ?></span>
                                                    </label>
                                                <?php endforeach; ?>
                                                <label class="inline-flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer p-2 rounded-lg border border-dashed border-slate-300 bg-white hover:border-sky-400 transition-all">
                                                    <input type="checkbox" id="design_specialties_other_cb" name="design_specialties[]" value="Other" class="rounded text-sky-600" onchange="toggleOtherWrapper(this, 'design_specialties_other_wrapper')">
                                                    <span>➕ Other</span>
                                                </label>
                                            </div>
                                            <div id="design_specialties_other_wrapper" class="hidden cond-wrap mt-2">
                                                <input type="text" placeholder="Please specify" oninput="syncOtherValue(document.getElementById('design_specialties_other_cb'), this)" class="w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:border-sky-500 focus:outline-none">
                                            </div>
                                        </div>

                                        <!-- Custom software input -->
                                        <div class="pt-2">
                                            <label class="block text-xs font-bold text-slate-600 mb-2">Other Softwares / Vector suites</label>
                                            <div class="flex gap-2">
                                                <input type="text" id="custom_designer_tool" placeholder="e.g. CorelDraw, Inkscape" class="rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:border-sky-500 focus:outline-none flex-grow">
                                                <button type="button" onclick="addCustomDesignerTool()" class="px-3 py-1.5 bg-sky-50 border border-sky-200 text-sky-700 text-xs font-bold rounded-xl hover:bg-sky-100">Add</button>
                                            </div>
                                            <div id="custom_tools_list" class="flex flex-wrap gap-1.5 mt-2"></div>
                                        </div>

                                        <!-- Portfolio URLs -->
                                        <div class="pt-2">
                                            <label class="block text-xs font-bold text-slate-600 mb-2">Behance / Dribbble / Portfolio URL</label>
                                            <div class="flex gap-2">
                                                <input type="url" id="portfolio_url_input" placeholder="https://behance.net/your-profile" class="rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:border-sky-500 focus:outline-none flex-grow">
                                                <button type="button" onclick="addPortfolioUrl()" class="px-3 py-1.5 bg-sky-50 border border-sky-200 text-sky-700 text-xs font-bold rounded-xl hover:bg-sky-100 font-bold">Add URL</button>
                                            </div>
                                            <div id="portfolios_list" class="flex flex-col gap-1 mt-2"></div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Availability & Motivation -->
                                <div class="grid grid-cols-1 gap-6">
                                    <div>
                                        <label for="availability" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Weekly Availability *</label>
                                        <select id="availability" name="availability" class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-sky-500 focus:outline-none bg-white transition-colors">
                                            <option value="">Choose availability</option>
                                            <option value="Less than 5 hours">Less than 5 hours / week</option>
                                            <option value="5-10 hours">5-10 hours / week</option>
                                            <option value="10-20 hours">10-20 hours / week</option>
                                            <option value="More than 20 hours">More than 20 hours / week</option>
                                        </select>
                                    </div>

                                    <div>
                                        <label for="motivation" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Describe your motivation to join L'EXTERNE *</label>
                                        <textarea id="motivation" name="motivation" rows="4" placeholder="Explain why you want to author medical literature or work on premium textbooks..." class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-sky-500 focus:outline-none transition-colors"></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="mt-8 flex justify-between">
                                <button type="button" onclick="prevStep()" class="px-5 py-2.5 border border-slate-200 text-slate-700 text-sm font-semibold rounded-xl hover:bg-slate-50 transition-colors">Previous</button>
                                <button type="button" onclick="nextStep()" class="px-5 py-2.5 bg-sky-600 hover:bg-sky-500 text-white text-sm font-semibold rounded-xl shadow-sm transition-colors">Next Stage</button>
                            </div>
                        </div>

                        <!-- STEP 5: COMMUNITY TRACK CHOOSE (MAX 4 CHOSEN) -->
                        <div class="form-step" data-step="5" id="community_step">
                            <div class="space-y-6">
                                <h3 class="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3">Community Options</h3>
                                <p class="text-xs text-slate-500 font-medium">Select up to FOUR communities you want to join. Checkbox cards enabled.</p>

                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4" id="community_cards_container">
                                    <?php foreach (get_communities_list() as $comm): ?>
                                        <label class="relative flex items-center justify-between p-4 rounded-xl border border-slate-200 cursor-pointer select-none transition-all duration-150 hover:border-sky-300">
                                            <div class="flex items-start gap-3">
                                                <input type="checkbox" name="communities[]" value="<?php echo htmlspecialchars($comm); ?>" class="rounded text-sky-600 mt-1 cursor-pointer" onchange="handleCommunitySelection(this)">
                                                <div>
                                                    <span class="text-sm font-bold block text-slate-800"><?php echo htmlspecialchars($comm); ?></span>
                                                    <span class="text-[10px] text-slate-400">Join the operational <?php echo strtolower($comm); ?> division.</span>
                                                </div>
                                            </div>
                                            <span class="selection-checkmark hidden text-sky-600 font-extrabold text-xs bg-sky-100 px-2 py-0.5 rounded-full">✓ Selected</span>
                                        </label>
                                    <?php endforeach; ?>
                                </div>

                                <!-- Conditional fields for Marketing / Design -->
                                <div id="community_conditional_container" class="hidden cond-wrap space-y-4 bg-slate-50/40 p-5 rounded-2xl border border-slate-100">
                                    <h4 class="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">Marketing & Creation Supplementary Details</h4>
                                    
                                    <div>
                                        <label class="block text-xs font-bold text-slate-600 mb-2">Design/Marketing Software Toolchain & Levels</label>
                                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                            <div>
                                                <input type="checkbox" id="comm_tool_figma" value="Figma" class="rounded text-sky-600"> <span class="text-xs text-slate-600">Figma</span>
                                            </div>
                                            <div>
                                                <input type="checkbox" id="comm_tool_photoshop" value="Adobe Photoshop" class="rounded text-sky-600"> <span class="text-xs text-slate-600">Photoshop</span>
                                            </div>
                                            <div>
                                                <input type="checkbox" id="comm_tool_canva" value="Canva" class="rounded text-sky-600"> <span class="text-xs text-slate-600">Canva</span>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="pt-2">
                                        <label for="comm_portfolio" class="block text-xs font-bold text-slate-600 mb-2">Social / Creative Portfolio URL</label>
                                        <input type="url" name="comm_portfolio" id="comm_portfolio" placeholder="https://behance.net/portfolio" class="w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:border-sky-500 focus:outline-none">
                                    </div>
                                </div>

                                <!-- General Community Sub-roles & History (shown whenever the applicant is on the Community path) -->
                                <div class="space-y-6 bg-slate-50/40 p-5 rounded-2xl border border-slate-100">
                                    <h4 class="text-xs font-bold text-slate-800 uppercase tracking-wider">How Would You Like to Contribute?</h4>
                                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                        <?php foreach (get_community_contribution_list() as $contrib): ?>
                                            <label class="inline-flex items-center gap-2 text-xs text-slate-600 cursor-pointer p-2.5 rounded-xl border border-slate-200 bg-white hover:border-sky-300 transition-all">
                                                <input type="checkbox" name="community_contributions[]" value="<?php echo htmlspecialchars($contrib); ?>" class="rounded text-sky-600">
                                                <span class="font-medium"><?php echo htmlspecialchars($contrib); ?></span>
                                            </label>
                                        <?php endforeach; ?>
                                        <label class="inline-flex items-center gap-2 text-xs text-slate-600 cursor-pointer p-2.5 rounded-xl border border-dashed border-slate-300 bg-white hover:border-sky-400 transition-all">
                                            <input type="checkbox" id="community_contributions_other_cb" name="community_contributions[]" value="Other" class="rounded text-sky-600" onchange="toggleOtherWrapper(this, 'community_contributions_other_wrapper')">
                                            <span class="font-medium">➕ Other</span>
                                        </label>
                                    </div>
                                    <div id="community_contributions_other_wrapper" class="hidden cond-wrap mt-2">
                                        <input type="text" placeholder="Please specify" oninput="syncOtherValue(document.getElementById('community_contributions_other_cb'), this)" class="w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:border-sky-500 focus:outline-none">
                                    </div>

                                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
                                        <div>
                                            <label class="block text-xs font-bold text-slate-600 mb-2">Have you previously managed an online community?</label>
                                            <div class="flex items-center gap-6">
                                                <label class="inline-flex items-center gap-2 text-xs text-slate-600 cursor-pointer">
                                                    <input type="radio" name="community_managed_before" value="Yes" class="text-sky-600" onchange="toggleCommunityManagedFields(true)"> Yes
                                                </label>
                                                <label class="inline-flex items-center gap-2 text-xs text-slate-600 cursor-pointer">
                                                    <input type="radio" name="community_managed_before" value="No" checked class="text-sky-600" onchange="toggleCommunityManagedFields(false)"> No
                                                </label>
                                            </div>
                                        </div>
                                        <div>
                                            <label for="community_hours_per_week" class="block text-xs font-bold text-slate-600 mb-2">Hours per week you can dedicate</label>
                                            <select id="community_hours_per_week" name="community_hours_per_week" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-sky-500 focus:outline-none bg-white">
                                                <option value="">Choose hours</option>
                                                <option value="Less than 3 hours">Less than 3 hours / week</option>
                                                <option value="3-5 hours">3-5 hours / week</option>
                                                <option value="5-10 hours">5-10 hours / week</option>
                                                <option value="More than 10 hours">More than 10 hours / week</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div id="community_member_count_wrapper" class="hidden cond-wrap">
                                        <label for="community_member_count" class="block text-xs font-bold text-slate-600 mb-2">Approximately how many members did it have?</label>
                                        <input type="number" min="0" id="community_member_count" name="community_member_count" placeholder="e.g. 500" class="w-full sm:w-1/2 rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-sky-500 focus:outline-none">
                                    </div>

                                    <div>
                                        <label class="block text-xs font-bold text-slate-600 mb-2">Which platforms have you managed?</label>
                                        <div class="grid grid-cols-2 sm:grid-cols-4 gap-2">
                                            <?php foreach (get_community_platforms_list() as $plat): ?>
                                                <?php if ($plat === 'Other'): ?>
                                                    <label class="inline-flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer p-2 rounded-lg border border-dashed border-slate-300 bg-white hover:border-sky-400 transition-all">
                                                        <input type="checkbox" id="community_platforms_other_cb" name="community_platforms[]" value="Other" class="rounded text-sky-600" onchange="toggleOtherWrapper(this, 'community_platforms_other_wrapper')">
                                                        <span>➕ Other</span>
                                                    </label>
                                                <?php else: ?>
                                                    <label class="inline-flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer p-2 rounded-lg border border-slate-200 bg-white hover:border-sky-300 transition-all">
                                                        <input type="checkbox" name="community_platforms[]" value="<?php echo htmlspecialchars($plat); ?>" class="rounded text-sky-600">
                                                        <span><?php echo htmlspecialchars($plat); ?></span>
                                                    </label>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        </div>
                                        <div id="community_platforms_other_wrapper" class="hidden cond-wrap mt-2">
                                            <input type="text" placeholder="Please specify" oninput="syncOtherValue(document.getElementById('community_platforms_other_cb'), this)" class="w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:border-sky-500 focus:outline-none">
                                        </div>
                                    </div>

                                    <div>
                                        <label class="block text-xs font-bold text-slate-600 mb-2">Links to previous work or relevant experience (optional)</label>
                                        <p class="text-[11px] text-slate-400 mb-2">A Discord you moderated, an event you organized, a spreadsheet you built — anything that shows what you can do, whichever division(s) you picked above.</p>
                                        <div class="flex gap-2">
                                            <input type="text" id="community_link_input" placeholder="https://... — click Add" class="rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:border-sky-500 focus:outline-none flex-grow">
                                            <button type="button" onclick="addTag('communityLinks', 'community_link_input', 'community_links_list')" class="px-3 py-1.5 bg-sky-50 border border-sky-200 text-sky-700 text-xs font-bold rounded-xl hover:bg-sky-100">Add</button>
                                        </div>
                                        <div id="community_links_list" class="flex flex-wrap gap-1.5 mt-2"></div>
                                    </div>

                                    <div>
                                        <label for="community_why_join" class="block text-xs font-bold text-slate-600 mb-2">Why do you want to help build the L'EXTERNE community?</label>
                                        <textarea id="community_why_join" name="community_why_join" rows="3" placeholder="Tell us what motivates you to help grow the community..." class="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-sky-500 focus:outline-none bg-white"></textarea>
                                    </div>

                                    <div>
                                        <label for="community_unique_value" class="block text-xs font-bold text-slate-600 mb-2">What unique value can you bring to the community?</label>
                                        <textarea id="community_unique_value" name="community_unique_value" rows="3" placeholder="Tell us what sets you apart..." class="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-sky-500 focus:outline-none bg-white"></textarea>
                                    </div>

                                    <div>
                                        <label for="community_problem_solving" class="block text-xs font-bold text-slate-600 mb-2">Describe a situation where you helped solve a problem or supported a team.</label>
                                        <textarea id="community_problem_solving" name="community_problem_solving" rows="3" placeholder="Tell us about a time you helped a team or solved a problem..." class="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-sky-500 focus:outline-none bg-white"></textarea>
                                    </div>

                                    <div class="flex items-start gap-3 bg-white rounded-xl border border-sky-100 p-3.5">
                                        <span class="text-sky-600 text-sm mt-0.5">ℹ️</span>
                                        <p class="text-[11px] text-slate-500 leading-normal">Community positions are volunteer-based and intended for applicants who want to help grow and support the medical student community.</p>
                                    </div>
                                </div>

                                <!-- IT / Development Dynamic Questions (Technology division) -->
                                <div id="it_dev_container" class="hidden cond-wrap space-y-4 bg-slate-50/40 p-5 rounded-2xl border border-slate-100">
                                    <h4 class="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">IT / Development Details</h4>

                                    <div>
                                        <label class="block text-xs font-bold text-slate-600 mb-2">How would you like to contribute?</label>
                                        <div class="grid grid-cols-2 sm:grid-cols-3 gap-2">
                                            <?php foreach (get_it_focus_list() as $focus): ?>
                                                <label class="inline-flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer p-2 rounded-lg border border-slate-200 bg-white hover:border-sky-300 transition-all">
                                                    <input type="checkbox" name="it_focus[]" value="<?php echo htmlspecialchars($focus); ?>" class="rounded text-sky-600">
                                                    <span><?php echo htmlspecialchars($focus); ?></span>
                                                </label>
                                            <?php endforeach; ?>
                                            <label class="inline-flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer p-2 rounded-lg border border-dashed border-slate-300 bg-white hover:border-sky-400 transition-all">
                                                <input type="checkbox" id="it_focus_other_cb" name="it_focus[]" value="Other" class="rounded text-sky-600" onchange="toggleOtherWrapper(this, 'it_focus_other_wrapper')">
                                                <span>➕ Other</span>
                                            </label>
                                        </div>
                                        <div id="it_focus_other_wrapper" class="hidden cond-wrap mt-2">
                                            <input type="text" placeholder="Please specify" oninput="syncOtherValue(document.getElementById('it_focus_other_cb'), this)" class="w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:border-sky-500 focus:outline-none">
                                        </div>
                                    </div>

                                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                                        <div>
                                            <label for="it_github_url" class="block text-xs font-bold text-slate-600 mb-2">GitHub Profile URL</label>
                                            <input type="url" id="it_github_url" name="it_github_url" placeholder="https://github.com/yourhandle" class="w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:border-sky-500 focus:outline-none">
                                        </div>
                                        <div>
                                            <label for="it_portfolio_url" class="block text-xs font-bold text-slate-600 mb-2">Portfolio Website URL</label>
                                            <input type="url" id="it_portfolio_url" name="it_portfolio_url" placeholder="https://yourportfolio.com" class="w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:border-sky-500 focus:outline-none">
                                        </div>
                                    </div>

                                    <div class="pt-2">
                                        <label class="block text-xs font-bold text-slate-600 mb-2">Primary Programming Languages</label>
                                        <div class="flex gap-2">
                                            <input type="text" id="it_language_input" placeholder="e.g. JavaScript — click Add" class="rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:border-sky-500 focus:outline-none flex-grow">
                                            <button type="button" onclick="addTag('itLanguages', 'it_language_input', 'it_languages_list')" class="px-3 py-1.5 bg-sky-50 border border-sky-200 text-sky-700 text-xs font-bold rounded-xl hover:bg-sky-100">Add</button>
                                        </div>
                                        <div id="it_languages_list" class="flex flex-wrap gap-1.5 mt-2"></div>
                                    </div>

                                    <div class="pt-2">
                                        <label class="block text-xs font-bold text-slate-600 mb-2">Frameworks &amp; Technologies</label>
                                        <div class="flex gap-2">
                                            <input type="text" id="it_framework_input" placeholder="e.g. Laravel — click Add" class="rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:border-sky-500 focus:outline-none flex-grow">
                                            <button type="button" onclick="addTag('itFrameworks', 'it_framework_input', 'it_frameworks_list')" class="px-3 py-1.5 bg-sky-50 border border-sky-200 text-sky-700 text-xs font-bold rounded-xl hover:bg-sky-100">Add</button>
                                        </div>
                                        <div id="it_frameworks_list" class="flex flex-wrap gap-1.5 mt-2"></div>
                                    </div>

                                    <div class="pt-2">
                                        <label for="it_years_experience" class="block text-xs font-bold text-slate-600 mb-2">Years of Experience</label>
                                        <select id="it_years_experience" name="it_years_experience" class="w-full sm:w-1/2 rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-sky-500 focus:outline-none bg-white">
                                            <option value="">Choose experience</option>
                                            <option value="Less than 1 year">Less than 1 year</option>
                                            <option value="1-2 years">1-2 years</option>
                                            <option value="2-4 years">2-4 years</option>
                                            <option value="4+ years">4+ years</option>
                                        </select>
                                    </div>

                                    <div class="pt-2">
                                        <label for="it_significant_project" class="block text-xs font-bold text-slate-600 mb-2">Most significant project you've worked on</label>
                                        <textarea id="it_significant_project" name="it_significant_project" rows="3" placeholder="Describe a project you're proud of, your role, and the outcome..." class="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-sky-500 focus:outline-none bg-white"></textarea>
                                    </div>

                                    <div class="pt-2">
                                        <label for="it_why_join" class="block text-xs font-bold text-slate-600 mb-2">Why would you like to contribute to the Technology team?</label>
                                        <textarea id="it_why_join" name="it_why_join" rows="3" placeholder="Tell us what draws you to the Technology division..." class="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-sky-500 focus:outline-none bg-white"></textarea>
                                    </div>
                                </div>

                                <!-- Marketing Dynamic Questions (Marketing & Communication division) -->
                                <div id="marketing_container" class="hidden cond-wrap space-y-4 bg-slate-50/40 p-5 rounded-2xl border border-slate-100">
                                    <h4 class="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">Marketing Details</h4>

                                    <div>
                                        <label class="block text-xs font-bold text-slate-600 mb-2">Areas of Expertise</label>
                                        <div class="grid grid-cols-2 sm:grid-cols-3 gap-2">
                                            <?php foreach (get_marketing_expertise_list() as $exp): ?>
                                                <label class="inline-flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer p-2 rounded-lg border border-slate-200 bg-white hover:border-sky-300 transition-all">
                                                    <input type="checkbox" name="marketing_expertise[]" value="<?php echo htmlspecialchars($exp); ?>" class="rounded text-sky-600">
                                                    <span><?php echo htmlspecialchars($exp); ?></span>
                                                </label>
                                            <?php endforeach; ?>
                                            <label class="inline-flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer p-2 rounded-lg border border-dashed border-slate-300 bg-white hover:border-sky-400 transition-all">
                                                <input type="checkbox" id="marketing_expertise_other_cb" name="marketing_expertise[]" value="Other" class="rounded text-sky-600" onchange="toggleOtherWrapper(this, 'marketing_expertise_other_wrapper')">
                                                <span>➕ Other</span>
                                            </label>
                                        </div>
                                        <div id="marketing_expertise_other_wrapper" class="hidden cond-wrap mt-2">
                                            <input type="text" placeholder="Please specify" oninput="syncOtherValue(document.getElementById('marketing_expertise_other_cb'), this)" class="w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:border-sky-500 focus:outline-none">
                                        </div>
                                    </div>

                                    <div class="pt-2">
                                        <label class="block text-xs font-bold text-slate-600 mb-2">Which platforms have you managed?</label>
                                        <div class="grid grid-cols-2 sm:grid-cols-4 gap-2">
                                            <?php foreach (get_marketing_platforms_list() as $plat): ?>
                                                <?php if ($plat === 'Other'): ?>
                                                    <label class="inline-flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer p-2 rounded-lg border border-dashed border-slate-300 bg-white hover:border-sky-400 transition-all">
                                                        <input type="checkbox" id="marketing_platforms_other_cb" name="marketing_platforms[]" value="Other" class="rounded text-sky-600" onchange="toggleOtherWrapper(this, 'marketing_platforms_other_wrapper')">
                                                        <span>➕ Other</span>
                                                    </label>
                                                <?php else: ?>
                                                    <label class="inline-flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer p-2 rounded-lg border border-slate-200 bg-white hover:border-sky-300 transition-all">
                                                        <input type="checkbox" name="marketing_platforms[]" value="<?php echo htmlspecialchars($plat); ?>" class="rounded text-sky-600">
                                                        <span><?php echo htmlspecialchars($plat); ?></span>
                                                    </label>
                                                <?php endif; ?>
                                            <?php endforeach; ?>
                                        </div>
                                        <div id="marketing_platforms_other_wrapper" class="hidden cond-wrap mt-2">
                                            <input type="text" placeholder="Please specify" oninput="syncOtherValue(document.getElementById('marketing_platforms_other_cb'), this)" class="w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:border-sky-500 focus:outline-none">
                                        </div>
                                    </div>

                                    <div class="pt-2">
                                        <label class="block text-xs font-bold text-slate-600 mb-2">Have you managed advertising budgets?</label>
                                        <div class="flex items-center gap-6">
                                            <label class="inline-flex items-center gap-2 text-xs text-slate-600 cursor-pointer">
                                                <input type="radio" name="marketing_budget_experience" value="Yes" class="text-sky-600" onchange="toggleMarketingBudgetFields(true)"> Yes
                                            </label>
                                            <label class="inline-flex items-center gap-2 text-xs text-slate-600 cursor-pointer">
                                                <input type="radio" name="marketing_budget_experience" value="No" checked class="text-sky-600" onchange="toggleMarketingBudgetFields(false)"> No
                                            </label>
                                        </div>
                                    </div>

                                    <div id="marketing_budget_details_wrapper" class="hidden cond-wrap">
                                        <label for="marketing_budget_details" class="block text-xs font-bold text-slate-600 mb-2">Briefly describe the budgets you've managed</label>
                                        <textarea id="marketing_budget_details" name="marketing_budget_details" rows="2" placeholder="e.g. Managed a monthly Meta Ads budget of ..." class="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-sky-500 focus:outline-none bg-white"></textarea>
                                        <label for="marketing_budget_size" class="block text-xs font-bold text-slate-600 mb-2 mt-3">Advertising budget size</label>
                                        <select id="marketing_budget_size" name="marketing_budget_size" class="w-full sm:w-1/2 rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-sky-500 focus:outline-none bg-white">
                                            <option value="">Choose budget size</option>
                                            <option value="Less than $500">Less than $500</option>
                                            <option value="$500 - $2,000">$500 - $2,000</option>
                                            <option value="$2,000 - $10,000">$2,000 - $10,000</option>
                                            <option value="More than $10,000">More than $10,000</option>
                                        </select>
                                    </div>

                                    <div class="pt-2">
                                        <label for="marketing_campaign" class="block text-xs font-bold text-slate-600 mb-2">One campaign you're proud of</label>
                                        <textarea id="marketing_campaign" name="marketing_campaign" rows="3" placeholder="Tell us about a campaign you led or contributed to..." class="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-sky-500 focus:outline-none bg-white"></textarea>
                                    </div>

                                    <div class="pt-2">
                                        <label class="block text-xs font-bold text-slate-600 mb-2">Links to previous work</label>
                                        <div class="flex gap-2">
                                            <input type="text" id="marketing_link_input" placeholder="https://... — click Add" class="rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:border-sky-500 focus:outline-none flex-grow">
                                            <button type="button" onclick="addTag('marketingLinks', 'marketing_link_input', 'marketing_links_list')" class="px-3 py-1.5 bg-sky-50 border border-sky-200 text-sky-700 text-xs font-bold rounded-xl hover:bg-sky-100">Add</button>
                                        </div>
                                        <div id="marketing_links_list" class="flex flex-wrap gap-1.5 mt-2"></div>
                                    </div>

                                    <div class="pt-2">
                                        <label for="marketing_why_join" class="block text-xs font-bold text-slate-600 mb-2">Why would you like to join the Marketing team?</label>
                                        <textarea id="marketing_why_join" name="marketing_why_join" rows="3" placeholder="Tell us what draws you to the Marketing division..." class="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:border-sky-500 focus:outline-none bg-white"></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="mt-8 flex justify-between">
                                <button type="button" onclick="prevStep()" class="px-5 py-2.5 border border-slate-200 text-slate-700 text-sm font-semibold rounded-xl hover:bg-slate-50 transition-colors">Previous</button>
                                <button type="button" onclick="nextStep()" class="px-5 py-2.5 bg-sky-600 hover:bg-sky-500 text-white text-sm font-semibold rounded-xl shadow-sm transition-colors">Next Stage</button>
                            </div>
                        </div>

                        <!-- STEP 6: EXPERIENCES, PROJECT COMMITMENT & L'EXTERNE IDEAS -->
                        <div class="form-step" data-step="6">
                            <div class="space-y-6">
                                <h3 class="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3">Project & Experiences</h3>

                                <!-- Project interest -->
                                <div>
                                    <label for="project" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Which L'EXTERNE project are you most excited to contribute to? *</label>
                                    <input type="text" id="project" name="project" placeholder="e.g. Pediatrics study companion, MCQ mobile app review" class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-sky-500 focus:outline-none">
                                </div>

                                <!-- Commitment -->
                                <div>
                                    <label for="long_term_commitment" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Do you plan long-term commitment? *</label>
                                    <select id="long_term_commitment" name="long_term_commitment" class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-sky-500 focus:outline-none bg-white">
                                        <option value="">Choose commitment</option>
                                        <option value="Yes, 1+ year">Yes, 1+ year</option>
                                        <option value="Yes, 6 months">Yes, 6 months</option>
                                        <option value="No, transient contributor">No, transient contributor</option>
                                    </select>
                                </div>

                                <!-- Revenue-sharing model -->
                                <div class="bg-slate-50/40 p-5 rounded-2xl border border-slate-100 space-y-3">
                                    <div class="flex items-start gap-3">
                                        <span class="text-sky-600 text-sm mt-0.5">💠</span>
                                        <p class="text-[11px] text-slate-500 leading-normal">L'EXTERNE collaborates with many contributors through a percentage-based revenue-sharing model that varies by project and role. Community roles stay volunteer-based, while select technical or editorial engagements may be paid where relevant.</p>
                                    </div>
                                    <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider">Are you comfortable working under a revenue-sharing model? *</label>
                                    <div class="flex flex-wrap items-center gap-6">
                                        <label class="inline-flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
                                            <input type="radio" name="revenue_sharing_response" value="Yes" class="text-sky-600"> Yes
                                        </label>
                                        <label class="inline-flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
                                            <input type="radio" name="revenue_sharing_response" value="No" class="text-sky-600"> No
                                        </label>
                                        <label class="inline-flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
                                            <input type="radio" name="revenue_sharing_response" value="I'd like more information" class="text-sky-600"> I'd like more information
                                        </label>
                                    </div>
                                </div>

                                <!-- Previous experience trigger -->
                                <div>
                                    <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Do you have previous clinical or creative group experience? *</label>
                                    <div class="flex items-center gap-6">
                                        <label class="inline-flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
                                            <input type="radio" name="previous_experience" value="Yes" class="text-sky-600" onchange="toggleExperienceFields(true)"> Yes
                                        </label>
                                        <label class="inline-flex items-center gap-2 text-sm text-slate-600 cursor-pointer">
                                            <input type="radio" name="previous_experience" value="No" checked class="text-sky-600" onchange="toggleExperienceFields(false)"> No
                                        </label>
                                    </div>
                                </div>

                                <!-- Dynamic Experience Fields -->
                                <div id="experience_fields_wrapper" class="hidden cond-wrap space-y-4 bg-slate-50/40 p-5 rounded-2xl border border-slate-100">
                                    <div>
                                        <label for="prev_experience_details" class="block text-xs font-bold text-slate-600 mb-2">Please describe previous projects, role, and achievements:</label>
                                        <textarea id="prev_experience_details" name="previous_experience_details" rows="3" placeholder="I was the lead editor at Clinical-Club Algiers, coordinating book editing for 500+ peers." class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-xs focus:border-sky-500 focus:outline-none bg-white"></textarea>
                                    </div>
                                </div>

                                <!-- Ideas for L'EXTERNE -->
                                <div>
                                    <label for="ideas" class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Ideas or suggestions for L'EXTERNE *</label>
                                    <textarea id="ideas" name="ideas" rows="4" placeholder="What books or features can we add to improve the Algerian med study pool?" class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-sky-500 focus:outline-none"></textarea>
                                </div>
                            </div>

                            <div class="mt-8 flex justify-between">
                                <button type="button" onclick="prevStep()" class="px-5 py-2.5 border border-slate-200 text-slate-700 text-sm font-semibold rounded-xl hover:bg-slate-50 transition-colors">Previous</button>
                                <button type="button" onclick="nextStep()" class="px-5 py-2.5 bg-sky-600 hover:bg-sky-500 text-white text-sm font-semibold rounded-xl shadow-sm transition-colors">Next Stage</button>
                            </div>
                        </div>

                        <!-- STEP 7: AGREEMENT & FINAL SUBMIT -->
                        <div class="form-step" data-step="7">
                            <div class="space-y-6">
                                <h3 class="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3">Agreements & Confirmation</h3>
                                <p class="text-xs text-slate-500">Please review all commitments below. You must accept all points to submit.</p>

                                <div class="space-y-4">
                                    <label class="relative flex items-center justify-between p-4 rounded-xl border border-slate-200 cursor-pointer select-none transition-all hover:border-sky-300">
                                        <div class="flex items-start gap-3">
                                            <input type="checkbox" id="agree_quality" required class="rounded text-sky-600 mt-1 cursor-pointer">
                                            <div>
                                                <span class="text-xs font-bold text-slate-800 block">Commitment to Academic Quality</span>
                                                <span class="text-[10px] text-slate-500 leading-normal">I pledge to write original, medical content reviewed against verified literature. No plagiarism.</span>
                                            </div>
                                        </div>
                                        <span class="selection-checkmark hidden text-sky-600 font-extrabold text-xs bg-sky-100 px-2 py-0.5 rounded-full ml-2">✓ Accepted</span>
                                    </label>

                                    <label class="relative flex items-center justify-between p-4 rounded-xl border border-slate-200 cursor-pointer select-none transition-all hover:border-sky-300">
                                        <div class="flex items-start gap-3">
                                            <input type="checkbox" id="agree_deadline" required class="rounded text-sky-600 mt-1 cursor-pointer">
                                            <div>
                                                <span class="text-xs font-bold text-slate-800 block">Commitment to Collaboration & Timeline</span>
                                                <span class="text-[10px] text-slate-500 leading-normal">I commit to honoring deadlines and communicating transparently within our shared workspace.</span>
                                            </div>
                                        </div>
                                        <span class="selection-checkmark hidden text-sky-600 font-extrabold text-xs bg-sky-100 px-2 py-0.5 rounded-full ml-2">✓ Accepted</span>
                                    </label>

                                    <label class="relative flex items-center justify-between p-4 rounded-xl border border-slate-200 cursor-pointer select-none transition-all hover:border-sky-300">
                                        <div class="flex items-start gap-3">
                                            <input type="checkbox" id="agree_confidentiality" required class="rounded text-sky-600 mt-1 cursor-pointer">
                                            <div>
                                                <span class="text-xs font-bold text-slate-800 block">Confidentiality & Copyright Statement</span>
                                                <span class="text-[10px] text-slate-500 leading-normal">All medical textbooks and materials created during recruitment belong to L'EXTERNE.</span>
                                            </div>
                                        </div>
                                        <span class="selection-checkmark hidden text-sky-600 font-extrabold text-xs bg-sky-100 px-2 py-0.5 rounded-full ml-2">✓ Accepted</span>
                                    </label>
                                </div>
                            </div>

                            <div id="formMessage" class="hidden p-4 rounded-2xl text-xs font-bold"></div>

                            <div class="mt-8 flex justify-between">
                                <button type="button" onclick="prevStep()" class="px-5 py-2.5 border border-slate-200 text-slate-700 text-sm font-semibold rounded-xl hover:bg-slate-50 transition-colors">Previous</button>
                                <button type="submit" id="submitBtn" class="px-5 py-2.5 bg-sky-600 hover:bg-sky-500 text-white text-sm font-bold rounded-xl shadow-md transition-all">Submit Application</button>
                            </div>
                        </div>

                    </form>


        </div><!-- /.apply-card -->

        <!-- Premium success panel (revealed by observer when the form reports success) -->
        <div id="successPanel">
            <div class="success-card">
                <div class="success-check">
                    <svg viewBox="0 0 100 100" aria-hidden="true"><circle cx="50" cy="50" r="42"/><path d="M32 51l13 13 24-27"/></svg>
                </div>
                <h2>You're in the pipeline.</h2>
                <p style="color:var(--muted-invert);margin-top:.7rem;max-width:44ch;margin-left:auto;margin-right:auto;line-height:1.7">
                    Thank you for applying to L'EXTERNE. Your application has been received and is now with our recruitment committee.
                </p>
                <div class="code" id="trackingCode">EXT-0000</div>
                <div class="success-next">
                    <div class="sn"><span class="n">1</span><div><b>We review your profile</b><small>Within 1–5 days, the committee looks over your modules, motivation and experience.</small></div></div>
                    <div class="sn"><span class="n">2</span><div><b>We reach out</b><small>If shortlisted, we'll message you on WhatsApp or Telegram with the next step.</small></div></div>
                    <div class="sn"><span class="n">3</span><div><b>You build with us</b><small>A short assignment and a friendly onboarding chat — then you're on the team.</small></div></div>
                </div>
                <p style="margin-top:1.6rem;font-size:.85rem;color:var(--muted-invert)">Keep your tracking code — you can mention it when we get in touch.</p>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- ========================= FAQ ========================= -->
<section id="faq" class="section" style="background:linear-gradient(180deg,#fff,var(--paper))">
    <div class="wrap-narrow">
        <div style="text-align:center;margin-bottom:2.2rem" class="reveal">
            <span class="eyebrow" style="justify-content:center">Questions</span>
            <h2 class="h-section" style="margin-top:1rem">Frequently asked</h2>
        </div>
        <div class="reveal">
            <?php foreach ($faq as $index => $item): ?>
            <div class="faq-item">
                <button type="button" class="faq-q" onclick="toggleFAQ(this, <?php echo $index; ?>)" aria-expanded="false">
                    <span><?php echo htmlspecialchars($item['question'] ?? ''); ?></span>
                    <span class="faq-ico" id="faq_icon_<?php echo $index; ?>">+</span>
                </button>
                <div class="faq-a" id="faq_ans_<?php echo $index; ?>"><?php echo htmlspecialchars($item['answer'] ?? ''); ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
</main>

<!-- ========================= FOOTER ========================= -->
<footer class="foot">
    <div class="foot-inner">
        <div style="display:flex;flex-wrap:wrap;gap:2rem;justify-content:space-between;align-items:flex-start">
            <div style="max-width:340px">
                <div style="display:flex;align-items:center;gap:.7rem">
                    <img src="assets/images/logo.png" alt="L'EXTERNE" class="foot-logo" width="44" height="44">
                    <h4>L'EXTERNE</h4>
                </div>
                <p style="margin-top:.9rem;font-size:.92rem;line-height:1.7">Algeria's clinical-first medical education platform — books, MCQ banks and study tools, built by students for students.</p>
                <div class="foot-social">
                    <a href="https://www.instagram.com/lexterne_series/" target="_blank" rel="noopener noreferrer" aria-label="L'EXTERNE on Instagram" class="social-ico">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <rect x="3" y="3" width="18" height="18" rx="5"/>
                            <circle cx="12" cy="12" r="4"/>
                            <circle cx="17.2" cy="6.8" r="1.1" fill="currentColor" stroke="none"/>
                        </svg>
                    </a>
                </div>
            </div>
            <div style="display:flex;gap:3rem;flex-wrap:wrap">
                <div>
                    <div style="font-family:var(--font-mono);font-size:.68rem;letter-spacing:.14em;text-transform:uppercase;color:var(--cyan-2);margin-bottom:.9rem">Explore</div>
                    <div style="display:grid;gap:.6rem;font-size:.9rem">
                        <a href="#about">Mission</a><a href="#roles">Roles</a><a href="#process">Process</a><a href="#faq">FAQ</a>
                    </div>
                </div>
                <div>
                    <div style="font-family:var(--font-mono);font-size:.68rem;letter-spacing:.14em;text-transform:uppercase;color:var(--cyan-2);margin-bottom:.9rem">Join</div>
                    <div style="display:grid;gap:.6rem;font-size:.9rem">
                        <?php if ($__open): ?><a href="#apply">Apply now</a><?php endif; ?>
                        <a href="login.php">Committee login</a>
                    </div>
                </div>
            </div>
        </div>
        <svg class="foot-ecg" viewBox="0 0 1200 40" preserveAspectRatio="none" aria-hidden="true"><path d="M0 20 H420 l16 -14 l14 26 l12 -20 l10 12 H720 l30 0 l14 -18 l14 26 H1200"/></svg>
        <div class="foot-bottom">
            <span>&copy; <span id="yr">2026</span> L'EXTERNE. All rights reserved.</span>
            <span class="mono" style="font-size:.72rem;letter-spacing:.04em">Built for medical students, in Algeria.</span>
        </div>
    </div>
</footer>

<button id="backTop" aria-label="Back to top">
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M12 19V5M6 11l6-6 6 6"/></svg>
</button>

    <script>
        let currentStep = 1;
        const totalSteps = 7;
        let recruitmentPath = 'Editorial';

        // Custom modules data store
        const customModulesList = {
            "1st year": [],
            "2nd year": [],
            "3rd year": [],
            "4th year": [],
            "5th year": [],
            "6th year / Internship / Residency": []
        };

        const customDesignerTools = [];
        const portfolioUrls = [];

        // Generic free-tag input store (used by IT Languages & Frameworks, and Marketing/Community work links)
        const tagLists = {
            itLanguages: [],
            itFrameworks: [],
            marketingLinks: [],
            communityLinks: []
        };

        function addTag(stateKey, inputId, listId) {
            const input = document.getElementById(inputId);
            const val = input.value.trim();
            if (!val) return;

            tagLists[stateKey].push(val);
            input.value = '';
            renderTags(stateKey, listId);
            saveFormState();
        }

        function renderTags(stateKey, listId) {
            const list = document.getElementById(listId);
            if (!list) return;
            list.innerHTML = '';
            tagLists[stateKey].forEach((t, idx) => {
                const pill = document.createElement('span');
                pill.className = "inline-flex items-center gap-1 bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded-full text-[10px] font-bold";
                pill.innerHTML = `<span>${t}</span><button type="button" class="text-rose-600 font-bold ml-1" onclick="removeTag('${stateKey}', ${idx}, '${listId}')">x</button>`;
                list.appendChild(pill);
            });
        }

        function removeTag(stateKey, idx, listId) {
            tagLists[stateKey].splice(idx, 1);
            renderTags(stateKey, listId);
            saveFormState();
        }

        // Resets every field inside a conditional section back to its default
        // state. Called whenever that section collapses, so a value typed
        // while it was visible never gets silently submitted afterward.
        function clearContainerFields(container) {
            if (!container) return;
            container.querySelectorAll('input, textarea, select').forEach(el => {
                if (el.type === 'checkbox' || el.type === 'radio') {
                    el.checked = el.defaultChecked;
                } else if (el.tagName === 'SELECT') {
                    el.selectedIndex = 0;
                } else {
                    el.value = '';
                }
            });
            // Collapse any nested "Other" (or similar) sub-wrappers too, so
            // their state resets along with the parent section.
            container.querySelectorAll('.cond-wrap').forEach(w => w.classList.add('hidden'));
        }

        // ----------------------------------------------------
        // Universal "Other (Please specify)" handling.
        // One reusable pair of functions covers every checkbox group,
        // multi-select, and dropdown across the form that offers a
        // free-text alternative — no per-field duplication needed.
        // ----------------------------------------------------
        function toggleOtherWrapper(el, wrapperId) {
            const wrapper = document.getElementById(wrapperId);
            if (!wrapper) return;
            const show = (el.tagName === 'SELECT') ? (el.value === 'Other') : el.checked;
            wrapper.classList.toggle('hidden', !show);
            const input = wrapper.querySelector('input, textarea');
            if (input) {
                input.required = show;
                if (show) {
                    // Let the reveal transition start, then focus the field and
                    // make sure it's actually visible on screen (useful on mobile
                    // where the keyboard can cover the bottom of the viewport).
                    setTimeout(() => {
                        input.focus({ preventScroll: true });
                        wrapper.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
                    }, 150);
                } else {
                    input.value = '';
                    syncOtherValue(el, input);
                }
            }
            saveFormState();
        }

        // Keeps a checkbox's submitted value in sync with its paired free-text
        // field, so autosave, the review summary, and FormData all see the
        // real typed text instead of the literal "Other" placeholder.
        function syncOtherValue(checkbox, textInput) {
            if (!checkbox || checkbox.tagName !== 'INPUT' || checkbox.type !== 'checkbox') return;
            checkbox.value = textInput.value.trim() || 'Other';
        }

        // Native <select> elements can't hold an arbitrary value, so any
        // dropdown offering "Other" needs its submitted value swapped for the
        // typed text right before the request goes out. Config-driven so every
        // "Other" dropdown is handled by this one function.
        const SELECT_OTHER_FIELDS = [
            { name: 'faculty', otherInputId: 'faculty_other' },
            { name: 'academic_year', otherInputId: 'academic_year_other' }
        ];
        function applySelectOtherOverrides(fd) {
            SELECT_OTHER_FIELDS.forEach(cfg => {
                if (fd.get(cfg.name) === 'Other') {
                    const custom = (document.getElementById(cfg.otherInputId)?.value || '').trim();
                    if (custom) fd.set(cfg.name, custom);
                }
            });
        }

        // Restore Autosaved state on load
        window.onload = function() {
            restoreFormState();
        };

        function updateProgress() {
            const progressPct = (currentStep / totalSteps) * 100;
            document.getElementById('progressBar').style.width = `${progressPct}%`;
            document.getElementById('stepCounter').innerText = `Step ${currentStep} of ${totalSteps}`;
        }

        function showStep(step) {
            document.querySelectorAll('.form-step').forEach(div => {
                div.classList.remove('active');
            });
            
            // Skip Step 4 (Editorial) if path is community
            if (step === 4 && recruitmentPath === 'Community') {
                currentStep = (currentStep > 3) ? 5 : 3;
                showStep(currentStep);
                return;
            }

            // Skip Step 5 (Community) if path is editorial
            if (step === 5 && recruitmentPath === 'Editorial') {
                currentStep = (currentStep > 4) ? 6 : 4;
                showStep(currentStep);
                return;
            }

            const activeDiv = document.querySelector(`.form-step[data-step="${step}"]`);
            if (activeDiv) {
                activeDiv.classList.add('active');
                updateProgress();
            }
        }

        function nextStep() {
            if (currentStep < totalSteps) {
                if (validateCurrentStep()) {
                    currentStep++;
                    showStep(currentStep);
                    saveFormState();
                    scrollFormToTop();
                }
            }
        }

        function prevStep() {
            if (currentStep > 1) {
                currentStep--;
                showStep(currentStep);
                saveFormState();
                scrollFormToTop();
            }
        }

        // Smoothly repositions the viewport to the top of the application
        // section on every step change, so the person always lands on the
        // step heading/progress bar instead of wherever the previous step
        // happened to end — keeps transitions from feeling like a layout jump.
        function scrollFormToTop() {
            const target = document.getElementById('apply');
            if (!target) return;
            const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
            window.scrollTo({ top: target.offsetTop - 40, behavior: reduceMotion ? 'auto' : 'smooth' });
        }

        function validateCurrentStep() {
            if (currentStep === 2) {
                const name = document.getElementById('full_name').value.trim();
                const email = document.getElementById('email').value.trim();
                const wa = document.getElementById('whatsapp').value.trim();
                const tg = document.getElementById('telegram').value.trim();
                const faculty = document.getElementById('faculty').value;
                const year = document.getElementById('academic_year').value;

                if (!name || !email || !wa || !tg || !faculty || !year) {
                    alert("Please fill in all required identity details.");
                    return false;
                }

                if (!tg.startsWith('@')) {
                    alert("Telegram username must begin with @");
                    return false;
                }

                if (faculty === 'Other' && !document.getElementById('faculty_other')?.value.trim()) {
                    alert("Please specify your faculty.");
                    return false;
                }

                if (year === 'Other' && !document.getElementById('academic_year_other')?.value.trim()) {
                    alert("Please specify your academic year.");
                    return false;
                }
            }

            if (currentStep === 3) {
                const pathSelected = document.querySelector('input[name="recruitment_path"]:checked');
                if (!pathSelected) {
                    alert("Please select a recruitment track.");
                    return false;
                }
            }
            return true;
        }

        function handlePathChange(input) {
            recruitmentPath = input.value;
            saveFormState();
        }

        // Validate Telegram Input
        function validateTelegram(input) {
            const err = document.getElementById('telegramError');
            if (input.value && !input.value.startsWith('@')) {
                err.classList.remove('hidden');
                input.classList.add('border-rose-400');
            } else {
                err.classList.add('hidden');
                input.classList.remove('border-rose-400');
            }
        }

        // Toggle study year modules checkboxes
        function toggleYearModules(blockId, checkbox, year) {
            const div = document.getElementById(blockId);
            if (checkbox.checked) {
                div.classList.remove('hidden');
            } else {
                div.classList.add('hidden');
                // Deselecting a study year should clear every module (and any
                // custom "Other" modules) that were chosen underneath it, so
                // a stale selection can never be silently submitted.
                clearContainerFields(div);
                if (year && customModulesList[year]) {
                    customModulesList[year].length = 0;
                    const listEl = div.querySelector('[id^="custom_list_"]');
                    if (listEl) renderCustomModules(year, listEl.id);
                }
            }
            saveFormState();
        }

        function toggleCustomModuleInput(inputId, checkbox, year, listId) {
            const div = document.getElementById(inputId);
            if (checkbox.checked) {
                div.classList.remove('hidden');
            } else {
                div.classList.add('hidden');
                const txt = div.querySelector('input[type="text"]');
                if (txt) txt.value = '';
                if (year && customModulesList[year]) {
                    customModulesList[year].length = 0;
                    if (listId) renderCustomModules(year, listId);
                }
            }
            saveFormState();
        }

        // Add custom module to specific study year
        function addCustomModule(year, txtId, listId) {
            const input = document.getElementById(txtId);
            const val = input.value.trim();
            if (!val) return;

            customModulesList[year].push(val);
            input.value = '';

            renderCustomModules(year, listId);
            saveFormState();
        }

        function renderCustomModules(year, listId) {
            const list = document.getElementById(listId);
            list.innerHTML = '';
            customModulesList[year].forEach((m, idx) => {
                const pill = document.createElement('span');
                pill.className = "inline-flex items-center gap-1 bg-sky-100 text-sky-800 px-2 py-0.5 rounded-full text-[10px] font-bold";
                pill.innerHTML = `<span>${m}</span><button type="button" class="text-rose-600 font-bold ml-1" onclick="removeCustomModule('${year}', ${idx}, '${listId}')">x</button>`;
                list.appendChild(pill);
            });
        }

        function removeCustomModule(year, idx, listId) {
            customModulesList[year].splice(idx, 1);
            renderCustomModules(year, listId);
            saveFormState();
        }

        function toggleWriterFields() {
            const isWriter = Array.from(document.querySelectorAll('input[name="roles[]"]:checked'))
                .some(cb => ['Book Writer', 'MCQ Writer', 'Book Updater'].includes(cb.value));

            const container = document.getElementById('writer_spec_container');
            if (isWriter) {
                container.classList.remove('hidden');
            } else {
                container.classList.add('hidden');
                clearContainerFields(container);
            }
        }

        function toggleDesignerFields() {
            const isDesigner = Array.from(document.querySelectorAll('input[name="roles[]"]:checked'))
                .some(cb => cb.value === 'Book Designer');

            const container = document.getElementById('designer_spec_container');
            if (isDesigner) {
                container.classList.remove('hidden');
            } else {
                container.classList.add('hidden');
                clearContainerFields(container);
                customDesignerTools.length = 0;
                renderCustomDesignerTools();
                portfolioUrls.length = 0;
                renderPortfolioUrls();
            }
        }

        // Add Custom Designer Tools
        function addCustomDesignerTool() {
            const input = document.getElementById('custom_designer_tool');
            const val = input.value.trim();
            if (!val) return;

            customDesignerTools.push(val);
            input.value = '';
            renderCustomDesignerTools();
            saveFormState();
        }

        function renderCustomDesignerTools() {
            const list = document.getElementById('custom_tools_list');
            list.innerHTML = '';
            customDesignerTools.forEach((t, idx) => {
                const pill = document.createElement('span');
                pill.className = "inline-flex items-center gap-1 bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded-full text-[10px] font-bold";
                pill.innerHTML = `<span>${t}</span><button type="button" class="text-rose-600 font-bold ml-1" onclick="removeCustomDesignerTool(${idx})">x</button>`;
                list.appendChild(pill);
            });
        }

        function removeCustomDesignerTool(idx) {
            customDesignerTools.splice(idx, 1);
            renderCustomDesignerTools();
            saveFormState();
        }

        // Portfolio links
        function addPortfolioUrl() {
            const input = document.getElementById('portfolio_url_input');
            const val = input.value.trim();
            if (!val) return;

            portfolioUrls.push(val);
            input.value = '';
            renderPortfolioUrls();
            saveFormState();
        }

        function renderPortfolioUrls() {
            const list = document.getElementById('portfolios_list');
            list.innerHTML = '';
            portfolioUrls.forEach((url, idx) => {
                const row = document.createElement('div');
                row.className = "flex items-center justify-between gap-2 text-xs bg-slate-50 p-1.5 rounded-lg border border-slate-100";
                row.innerHTML = `<span class="truncate text-slate-600 max-w-[200px]">${url}</span><button type="button" class="text-rose-500 font-bold" onclick="removePortfolioUrl(${idx})">Remove</button>`;
                list.appendChild(row);
            });
        }

        function removePortfolioUrl(idx) {
            portfolioUrls.splice(idx, 1);
            renderPortfolioUrls();
            saveFormState();
        }

        // Limit Community choices to max 4
        function handleCommunitySelection(checkbox) {
            const selected = Array.from(document.querySelectorAll('input[name="communities[]"]:checked'));
            if (selected.length > 4) {
                checkbox.checked = false;
                alert("You can select a maximum of 4 communities.");
                return;
            }

            // Display supplementary software fields if Marketing or Design selected
            const marketingOrDesign = selected.some(cb => cb.value === 'Marketing & Communication' || cb.value === 'Design & Creation');
            const container = document.getElementById('community_conditional_container');
            if (marketingOrDesign) {
                container.classList.remove('hidden');
            } else {
                container.classList.add('hidden');
                clearContainerFields(container);
            }

            // Display IT/Development questions if Technology selected
            const isTech = selected.some(cb => cb.value === 'Technology');
            const itContainer = document.getElementById('it_dev_container');
            if (itContainer) {
                itContainer.classList.toggle('hidden', !isTech);
                if (!isTech) clearContainerFields(itContainer);
            }

            // Display Marketing questions if Marketing & Communication selected
            const isMarketing = selected.some(cb => cb.value === 'Marketing & Communication');
            const marketingContainer = document.getElementById('marketing_container');
            if (marketingContainer) {
                marketingContainer.classList.toggle('hidden', !isMarketing);
                if (!isMarketing) clearContainerFields(marketingContainer);
            }

            saveFormState();
        }

        function toggleCommunityManagedFields(show) {
            const wrapper = document.getElementById('community_member_count_wrapper');
            if (wrapper) {
                wrapper.classList.toggle('hidden', !show);
                if (!show) clearContainerFields(wrapper);
            }
            saveFormState();
        }

        function toggleMarketingBudgetFields(show) {
            const wrapper = document.getElementById('marketing_budget_details_wrapper');
            if (wrapper) {
                wrapper.classList.toggle('hidden', !show);
                if (!show) clearContainerFields(wrapper);
            }
            saveFormState();
        }

        function toggleExperienceFields(show) {
            const wrapper = document.getElementById('experience_fields_wrapper');
            if (show) {
                wrapper.classList.remove('hidden');
            } else {
                wrapper.classList.add('hidden');
                clearContainerFields(wrapper);
            }
        }

        // FAQ accordion
        function toggleFAQ(btn, idx) {
            const div = document.getElementById(`faq_ans_${idx}`);
            const icon = document.getElementById(`faq_icon_${idx}`);
            const isOpen = div.classList.toggle('open');
            icon.textContent = isOpen ? '−' : '+';
            btn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
        }

        // ----------------------------------------------------
        // Form Autosave engine (saves state to localStorage)
        // ----------------------------------------------------
        function saveFormState() {
            const state = {
                currentStep,
                recruitmentPath,
                full_name: document.getElementById('full_name')?.value || '',
                email: document.getElementById('email')?.value || '',
                whatsapp: document.getElementById('whatsapp')?.value || '',
                telegram: document.getElementById('telegram')?.value || '',
                faculty: document.getElementById('faculty')?.value || '',
                academic_year: document.getElementById('academic_year')?.value || '',
                availability: document.getElementById('availability')?.value || '',
                motivation: document.getElementById('motivation')?.value || '',
                project: document.getElementById('project')?.value || '',
                long_term_commitment: document.getElementById('long_term_commitment')?.value || '',
                previous_experience: document.querySelector('input[name="previous_experience"]:checked')?.value || 'No',
                previous_experience_details: document.getElementById('prev_experience_details')?.value || '',
                ideas: document.getElementById('ideas')?.value || '',
                revenue_sharing_response: document.querySelector('input[name="revenue_sharing_response"]:checked')?.value || '',
                it_github_url: document.getElementById('it_github_url')?.value || '',
                it_portfolio_url: document.getElementById('it_portfolio_url')?.value || '',
                it_years_experience: document.getElementById('it_years_experience')?.value || '',
                it_significant_project: document.getElementById('it_significant_project')?.value || '',
                it_why_join: document.getElementById('it_why_join')?.value || '',
                marketing_budget_experience: document.querySelector('input[name="marketing_budget_experience"]:checked')?.value || 'No',
                marketing_budget_details: document.getElementById('marketing_budget_details')?.value || '',
                marketing_budget_size: document.getElementById('marketing_budget_size')?.value || '',
                marketing_campaign: document.getElementById('marketing_campaign')?.value || '',
                marketing_why_join: document.getElementById('marketing_why_join')?.value || '',
                community_managed_before: document.querySelector('input[name="community_managed_before"]:checked')?.value || 'No',
                community_member_count: document.getElementById('community_member_count')?.value || '',
                community_hours_per_week: document.getElementById('community_hours_per_week')?.value || '',
                community_why_join: document.getElementById('community_why_join')?.value || '',
                community_unique_value: document.getElementById('community_unique_value')?.value || '',
                community_problem_solving: document.getElementById('community_problem_solving')?.value || '',
                faculty_other: document.getElementById('faculty_other')?.value || '',
                academic_year_other: document.getElementById('academic_year_other')?.value || '',
                customModulesList,
                customDesignerTools,
                portfolioUrls,
                tagLists
            };
            localStorage.setItem('lexterne_application_draft', JSON.stringify(state));
        }

        function restoreFormState() {
            const saved = localStorage.getItem('lexterne_application_draft');
            if (!saved) return;

            try {
                const state = JSON.parse(saved);
                currentStep = state.currentStep || 1;
                recruitmentPath = state.recruitmentPath || 'Editorial';

                // Restore Textboxes
                if (document.getElementById('full_name')) document.getElementById('full_name').value = state.full_name;
                if (document.getElementById('email')) document.getElementById('email').value = state.email;
                if (document.getElementById('whatsapp')) document.getElementById('whatsapp').value = state.whatsapp;
                if (document.getElementById('telegram')) document.getElementById('telegram').value = state.telegram;
                if (document.getElementById('faculty')) {
                    document.getElementById('faculty').value = state.faculty;
                    if (state.faculty === 'Other') toggleOtherWrapper(document.getElementById('faculty'), 'faculty_other_wrapper');
                }
                if (document.getElementById('academic_year')) {
                    document.getElementById('academic_year').value = state.academic_year;
                    if (state.academic_year === 'Other') toggleOtherWrapper(document.getElementById('academic_year'), 'academic_year_other_wrapper');
                }
                if (document.getElementById('availability')) document.getElementById('availability').value = state.availability;
                if (document.getElementById('motivation')) document.getElementById('motivation').value = state.motivation;
                if (document.getElementById('project')) document.getElementById('project').value = state.project;
                if (document.getElementById('long_term_commitment')) document.getElementById('long_term_commitment').value = state.long_term_commitment;
                if (document.getElementById('prev_experience_details')) document.getElementById('prev_experience_details').value = state.previous_experience_details;
                if (document.getElementById('ideas')) document.getElementById('ideas').value = state.ideas;
                if (document.getElementById('it_github_url')) document.getElementById('it_github_url').value = state.it_github_url || '';
                if (document.getElementById('it_portfolio_url')) document.getElementById('it_portfolio_url').value = state.it_portfolio_url || '';
                if (document.getElementById('it_years_experience')) document.getElementById('it_years_experience').value = state.it_years_experience || '';
                if (document.getElementById('it_significant_project')) document.getElementById('it_significant_project').value = state.it_significant_project || '';
                if (document.getElementById('it_why_join')) document.getElementById('it_why_join').value = state.it_why_join || '';
                if (document.getElementById('marketing_budget_details')) document.getElementById('marketing_budget_details').value = state.marketing_budget_details || '';
                if (document.getElementById('marketing_budget_size')) document.getElementById('marketing_budget_size').value = state.marketing_budget_size || '';
                if (document.getElementById('marketing_campaign')) document.getElementById('marketing_campaign').value = state.marketing_campaign || '';
                if (document.getElementById('marketing_why_join')) document.getElementById('marketing_why_join').value = state.marketing_why_join || '';
                if (document.getElementById('community_member_count')) document.getElementById('community_member_count').value = state.community_member_count || '';
                if (document.getElementById('community_hours_per_week')) document.getElementById('community_hours_per_week').value = state.community_hours_per_week || '';
                if (document.getElementById('community_why_join')) document.getElementById('community_why_join').value = state.community_why_join || '';
                if (document.getElementById('community_unique_value')) document.getElementById('community_unique_value').value = state.community_unique_value || '';
                if (document.getElementById('community_problem_solving')) document.getElementById('community_problem_solving').value = state.community_problem_solving || '';
                if (document.getElementById('faculty_other')) document.getElementById('faculty_other').value = state.faculty_other || '';
                if (document.getElementById('academic_year_other')) document.getElementById('academic_year_other').value = state.academic_year_other || '';

                // Restore Path Radio
                const pathRadio = document.querySelector(`input[name="recruitment_path"][value="${recruitmentPath}"]`);
                if (pathRadio) pathRadio.checked = true;

                // Restore Previous Exp
                const expRadio = document.querySelector(`input[name="previous_experience"][value="${state.previous_experience}"]`);
                if (expRadio) {
                    expRadio.checked = true;
                    toggleExperienceFields(state.previous_experience === 'Yes');
                }

                // Restore revenue-sharing response
                if (state.revenue_sharing_response) {
                    const revRadio = document.querySelector(`input[name="revenue_sharing_response"][value="${state.revenue_sharing_response}"]`);
                    if (revRadio) revRadio.checked = true;
                }

                // Restore marketing budget experience
                const budgetRadio = document.querySelector(`input[name="marketing_budget_experience"][value="${state.marketing_budget_experience}"]`);
                if (budgetRadio) {
                    budgetRadio.checked = true;
                    toggleMarketingBudgetFields(state.marketing_budget_experience === 'Yes');
                }

                // Restore community managed-before
                const managedRadio = document.querySelector(`input[name="community_managed_before"][value="${state.community_managed_before}"]`);
                if (managedRadio) {
                    managedRadio.checked = true;
                    toggleCommunityManagedFields(state.community_managed_before === 'Yes');
                }

                // Restore Lists
                if (state.customModulesList) {
                    Object.assign(customModulesList, state.customModulesList);
                    for (let i = 1; i <= 6; i++) {
                        let y = Object.keys(customModulesList)[i - 1];
                        renderCustomModules(y, `custom_list_${i}`);
                    }
                }
                if (state.customDesignerTools) {
                    customDesignerTools.push(...state.customDesignerTools);
                    renderCustomDesignerTools();
                }
                if (state.portfolioUrls) {
                    portfolioUrls.push(...state.portfolioUrls);
                    renderPortfolioUrls();
                }
                if (state.tagLists) {
                    if (state.tagLists.itLanguages) {
                        tagLists.itLanguages.push(...state.tagLists.itLanguages);
                        renderTags('itLanguages', 'it_languages_list');
                    }
                    if (state.tagLists.itFrameworks) {
                        tagLists.itFrameworks.push(...state.tagLists.itFrameworks);
                        renderTags('itFrameworks', 'it_frameworks_list');
                    }
                    if (state.tagLists.marketingLinks) {
                        tagLists.marketingLinks.push(...state.tagLists.marketingLinks);
                        renderTags('marketingLinks', 'marketing_links_list');
                    }
                    if (state.tagLists.communityLinks) {
                        tagLists.communityLinks.push(...state.tagLists.communityLinks);
                        renderTags('communityLinks', 'community_links_list');
                    }
                }

                showStep(currentStep);
            } catch (e) {
                console.error("Autosave restore error:", e);
            }
        }

        // ----------------------------------------------------
        // Submit via AJAX Fetch
        // ----------------------------------------------------
        function submitForm(event) {
            event.preventDefault();
            const btn = document.getElementById('submitBtn');
            const msg = document.getElementById('formMessage');

            btn.disabled = true;
            btn.innerText = "Submitting application...";

            // Auto-capture typed custom module text fields if user did not click 'Add' button
            const yearKeys = ["1st year", "2nd year", "3rd year", "4th year", "5th year", "6th year / Internship / Residency"];
            for (let i = 1; i <= 6; i++) {
                const txtInput = document.getElementById(`txt_custom_${i}`);
                if (txtInput && txtInput.value.trim()) {
                    const yKey = yearKeys[i - 1];
                    if (yKey) {
                        const val = txtInput.value.trim();
                        if (!customModulesList[yKey].includes(val)) {
                            customModulesList[yKey].push(val);
                        }
                    }
                }
            }

            // Assemble Form Data with custom modules, designer tools & portfolio urls arrays
            const fd = new FormData(document.getElementById('recruitmentForm'));
            fd.append('custom_modules', JSON.stringify(customModulesList));
            fd.append('custom_designer_tools', JSON.stringify(customDesignerTools));
            fd.append('portfolio_urls', JSON.stringify(portfolioUrls));

            // IT/Development free-tag fields (languages & frameworks)
            fd.append('it_languages', tagLists.itLanguages.join(', '));
            fd.append('it_frameworks', tagLists.itFrameworks.join(', '));

            // Marketing "Links to previous work" free-tag field
            fd.append('marketing_work_links', tagLists.marketingLinks.join(', '));

            // Community "Links to previous work / relevant experience" free-tag field
            fd.append('community_portfolio_links', tagLists.communityLinks.join(', '));

            // Gather marketing software if selected
            const commTools = [];
            if (document.getElementById('comm_tool_figma')?.checked) commTools.push('Figma');
            if (document.getElementById('comm_tool_photoshop')?.checked) commTools.push('Adobe Photoshop');
            if (document.getElementById('comm_tool_canva')?.checked) commTools.push('Canva');
            fd.append('community_tools', JSON.stringify(commTools));

            // Universal "Other" handling: swap "Other" for the typed text on
            // any dropdown that offers a free-text alternative (checkbox groups
            // are already kept in sync live via syncOtherValue()).
            applySelectOtherOverrides(fd);

            fetch('api.php', {
                method: 'POST',
                body: fd
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    // Clear Autosave
                    localStorage.removeItem('lexterne_application_draft');
                    
                    msg.className = "p-4 rounded-2xl text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-100";
                    msg.innerHTML = `<p>🎉 Application submitted successfully!</p><p class="mt-1 font-normal text-[10px]">Your tracking code is: <code class="font-bold text-sky-800">${data.tracking_code}</code>. The recruitment heads will contact you via WhatsApp/Telegram shortly.</p>`;
                    msg.classList.remove('hidden');
                    
                    // Reset form and scroll to message
                    document.getElementById('recruitmentForm').reset();
                    msg.scrollIntoView({ behavior: 'smooth' });
                } else {
                    btn.disabled = false;
                    btn.innerText = "Submit Application";
                    msg.className = "p-4 rounded-2xl text-xs font-bold bg-rose-50 text-rose-800 border border-rose-100";
                    msg.innerText = `⚠️ Error submitting: ${data.message}`;
                    msg.classList.remove('hidden');
                    msg.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            })
            .catch(err => {
                btn.disabled = false;
                btn.innerText = "Submit Application";
                msg.className = "p-4 rounded-2xl text-xs font-bold bg-rose-50 text-rose-800 border border-rose-100";
                msg.innerText = "⚠️ Network error. Please try again.";
                msg.classList.remove('hidden');
                msg.scrollIntoView({ behavior: 'smooth', block: 'center' });
            });
        }

        // Global event handler to update selection highlight classes on all selectable elements
        document.addEventListener('change', function(e) {
            if (e.target.matches('input[type="checkbox"], input[type="radio"]')) {
                if (e.target.type === 'radio' && e.target.name) {
                    document.querySelectorAll(`input[name="${e.target.name}"]`).forEach(r => {
                        const l = r.closest('label');
                        if (l) l.classList.remove('is-selected');
                    });
                }
                const label = e.target.closest('label');
                if (label) {
                    if (e.target.checked) {
                        label.classList.add('is-selected');
                    } else {
                        label.classList.remove('is-selected');
                    }
                }
            }
        });
    </script>


<script>
(function(){
    "use strict";
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    /* year */
    var yr = document.getElementById('yr'); if(yr) yr.textContent = new Date().getFullYear();

    /* nav scrolled state + scroll progress + back-to-top */
    var nav = document.getElementById('siteNav');
    var prog = document.getElementById('scrollProgress');
    var back = document.getElementById('backTop');
    function onScroll(){
        var y = window.scrollY || document.documentElement.scrollTop;
        if(nav) nav.classList.toggle('scrolled', y > 12);
        var h = document.documentElement.scrollHeight - window.innerHeight;
        if(prog) prog.style.width = (h>0 ? (y/h*100) : 0) + '%';
        if(back) back.classList.toggle('show', y > 600);
    }
    window.addEventListener('scroll', onScroll, {passive:true}); onScroll();
    if(back) back.addEventListener('click', function(){ window.scrollTo({top:0, behavior: reduce?'auto':'smooth'}); });

    /* mobile menu */
    var tgl = document.getElementById('navToggle'), mm = document.getElementById('mobileMenu');
    if(tgl && mm){
        tgl.addEventListener('click', function(){
            var open = mm.classList.toggle('show');
            tgl.setAttribute('aria-expanded', open ? 'true':'false');
        });
        mm.querySelectorAll('a').forEach(function(a){ a.addEventListener('click', function(){ mm.classList.remove('show'); }); });
    }

    /* reveal on scroll */
    var revs = document.querySelectorAll('.reveal');
    if('IntersectionObserver' in window && !reduce){
        var io = new IntersectionObserver(function(es){
            es.forEach(function(e){ if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); } });
        }, {threshold:.12, rootMargin:'0px 0px -8% 0px'});
        revs.forEach(function(el){ io.observe(el); });
    } else { revs.forEach(function(el){ el.classList.add('in'); }); }

    /* count-up stats */
    var counters = document.querySelectorAll('.count');
    function runCount(el){
        var target = parseFloat(el.getAttribute('data-target')) || 0, t0 = null, dur = 1400;
        if(reduce){ el.textContent = target; return; }
        function tick(ts){ if(!t0) t0=ts; var p=Math.min((ts-t0)/dur,1);
            var val = Math.floor((1-Math.pow(1-p,3))*target);
            el.textContent = val; if(p<1) requestAnimationFrame(tick); else el.textContent = target; }
        requestAnimationFrame(tick);
    }
    if('IntersectionObserver' in window){
        var cio = new IntersectionObserver(function(es){ es.forEach(function(e){ if(e.isIntersecting){ runCount(e.target); cio.unobserve(e.target); } }); }, {threshold:.6});
        counters.forEach(function(c){ cio.observe(c); });
    } else { counters.forEach(runCount); }

    /* button ripple (decorative, all .btn and form primary buttons) */
    document.addEventListener('click', function(e){
        var b = e.target.closest('.btn, #recruitmentForm #submitBtn, #recruitmentForm button[onclick*="nextStep"]');
        if(!b) return;
        var r = document.createElement('span'); r.className='ripple';
        var rect = b.getBoundingClientRect(), size = Math.max(rect.width, rect.height);
        r.style.width = r.style.height = size+'px';
        r.style.left = (e.clientX-rect.left-size/2)+'px';
        r.style.top = (e.clientY-rect.top-size/2)+'px';
        b.appendChild(r); setTimeout(function(){ r.remove(); }, 620);
    });

    /* ---------- Review summary (final step) ---------- */
    var step7 = document.querySelector('#recruitmentForm .form-step[data-step="7"]');
    var review = null;
    if(step7){
        review = document.createElement('div');
        review.id = 'reviewSummary';
        step7.insertBefore(review, step7.firstChild);
        // delegated Edit buttons -> jump to a step. Runs in this classic script's scope so
        // `currentStep` (a top-level let) and showStep() resolve to the form's own bindings.
        review.addEventListener('click', function(e){
            var btn = e.target.closest('.rev-edit'); if(!btn) return;
            var go = parseInt(btn.getAttribute('data-goto'),10);
            if(!isNaN(go)){ currentStep = go; showStep(go); window.scrollTo({top: document.getElementById('apply').offsetTop-40, behavior: reduce?'auto':'smooth'}); }
        });
    }
    function val(id){ var el=document.getElementById(id); return el ? el.value.trim() : ''; }
    // Shows the typed custom text instead of the literal "Other" placeholder
    // for any dropdown paired with a free-text "Other" field.
    function otherAware(fieldId, otherId){ var v = val(fieldId); return (v === 'Other') ? (val(otherId) || 'Other') : v; }
    function checkedVals(name){ return Array.prototype.map.call(document.querySelectorAll('input[name="'+name+'"]:checked'), function(i){return i.value;}); }
    function chips(arr){ return arr.length ? arr.map(function(x){return '<span class="chip">'+esc(x)+'</span>';}).join('') : '<span class="rev-empty">None selected</span>'; }
    function esc(s){ return (s||'').replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];}); }
    function text(v){ return v ? esc(v) : '<span class="rev-empty">Not provided</span>'; }

    function buildReview(){
        if(!review) return;
        var path = (document.querySelector('input[name="recruitment_path"]:checked')||{}).value || '';
        // modules grouped
        var mods = [];
        document.querySelectorAll('input[name^="modules["]:checked').forEach(function(i){ mods.push(i.value); });
        (function(){ try{ Object.keys(customModulesList||{}).forEach(function(y){ (customModulesList[y]||[]).forEach(function(m){ mods.push(m); }); }); }catch(e){} })();
        // designer tool proficiencies
        var tools = [];
        document.querySelectorAll('#designer_spec_container input[type="radio"]:checked').forEach(function(i){
            var nm=(i.getAttribute('name')||'').replace('tools[','').replace(']',''); tools.push(nm+': '+i.value);
        });
        try{ (customDesignerTools||[]).forEach(function(t){ tools.push(t); }); }catch(e){}
        var comms = checkedVals('communities[]');
        var roles = checkedVals('roles[]');
        var ports = [];
        try{ ports = (portfolioUrls||[]).slice(); }catch(e){}
        var cp = val('comm_portfolio'); if(cp) ports.push(cp);
        var revShare = (document.querySelector('input[name="revenue_sharing_response"]:checked')||{}).value || '';
        var commContrib = checkedVals('community_contributions[]');
        var itFocus = checkedVals('it_focus[]');
        var mktExpertise = checkedVals('marketing_expertise[]');
        var designSpecialties = checkedVals('design_specialties[]');

        var rows = '';
        rows += block('Name', text(val('full_name')), 2);
        rows += block('Contact', text(val('email')) + (val('telegram') ? ' · '+esc(val('telegram')) : ''), 2);
        rows += block('Faculty & year', text(otherAware('faculty','faculty_other')) + (val('academic_year') ? ' · '+esc(otherAware('academic_year','academic_year_other')) : ''), 2);
        rows += block('Track', path ? '<span class="chip">'+esc(path)+'</span>' : '<span class="rev-empty">Not selected</span>', 3);
        if(path==='Editorial' || path==='Both'){
            rows += block('Roles', chips(roles), 4);
            if(mods.length) rows += block('Modules', chips(mods), 4);
            if(tools.length) rows += block('Design tools', chips(tools), 4);
            if(designSpecialties.length) rows += block('Design specialties', chips(designSpecialties), 4);
        }
        if(path==='Community' || path==='Both'){
            rows += block('Communities', chips(comms), 5);
            if(commContrib.length) rows += block('Community contribution', chips(commContrib), 5);
            if(itFocus.length) rows += block('IT/Development focus', chips(itFocus), 5);
            if(mktExpertise.length) rows += block('Marketing expertise', chips(mktExpertise), 5);
        }
        if(ports.length) rows += block('Portfolio', chips(ports), (path==='Community'?5:4));
        rows += block('Availability', text(val('availability')), (path==='Community'?5:4));
        rows += block('Motivation', text(val('motivation')), 4);
        rows += block('Project & goals', text(val('project')) + (val('long_term_commitment') ? ' · '+esc(val('long_term_commitment')) : ''), 6);
        rows += block('Revenue-sharing', revShare ? '<span class="chip">'+esc(revShare)+'</span>' : '<span class="rev-empty">Not answered</span>', 6);
        rows += block('Ideas', text(val('ideas')), 6);

        review.innerHTML =
            '<div class="rev-top"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#0B8A96" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg> Review your application</div>' + rows;
    }
    function block(k, v, goto){
        return '<div class="rev-block"><div class="rev-k">'+k+'</div><div class="rev-v">'+v+'</div>'+
               (goto?'<button type="button" class="rev-edit" data-goto="'+goto+'">Edit</button>':'')+'</div>';
    }
    if(step7 && 'MutationObserver' in window){
        new MutationObserver(function(){ if(step7.classList.contains('active')) buildReview(); })
            .observe(step7, {attributes:true, attributeFilter:['class']});
    }

    /* ---------- Premium success panel ---------- */
    var msg = document.getElementById('formMessage');
    var panel = document.getElementById('successPanel');
    var applyCard = document.getElementById('applyCard');
    if(msg && panel && 'MutationObserver' in window){
        new MutationObserver(function(){
            var cls = msg.className || '';
            var isSuccess = cls.indexOf('emerald') !== -1 || /successfully/i.test(msg.textContent||'');
            if(isSuccess && !panel.classList.contains('show')){
                var code = (msg.querySelector('code') && msg.querySelector('code').textContent) || '';
                if(code){ var tc = document.getElementById('trackingCode'); if(tc) tc.textContent = code; }
                if(applyCard) applyCard.style.display = 'none';
                panel.classList.add('show');
                setTimeout(function(){ panel.scrollIntoView({behavior: reduce?'auto':'smooth', block:'center'}); }, 60);
            }
        }).observe(msg, {attributes:true, childList:true, subtree:true, attributeFilter:['class']});
    }
})();
</script>
</body>
</html>