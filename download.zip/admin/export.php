<?php
/**
 * L'EXTERNE ATS - Candidate Data Export Utility
 * Redesigned clean CSV & XLSX Export generator.
 * Standardized format: One applicant per row, one field per column, UTF-8 with BOM for Excel.
 */

require_once __DIR__ . '/../functions.php';

// Force authenticated reviewer access
require_login();

$format = strtolower($_GET['format'] ?? 'csv');
if ($format === 'excel') {
    $format = 'xlsx';
}

$filename_base = "lexterne_applicants_" . date('Y-m-d_Hi');

// Professional headers definition matching exact requirements
$headers = [
    'ID / Tracking Code',
    'Full Name',
    'Email',
    'WhatsApp',
    'Telegram Username',
    'Faculty',
    'Academic Year',
    'Recruitment Path',
    'Chosen Roles',
    'Selected Modules',
    'Software Tools & Proficiency',
    'Design Specialties',
    'Portfolio URLs',
    'Communities',
    'Community Contribution',
    'Community Managed Before',
    'Community Member Count',
    'Community Platforms Managed',
    'Community Hours / Week',
    'Community Why Join',
    'Community Unique Value',
    'Community Problem-Solving Example',
    'Community Portfolio / Previous Work Links',
    'IT Focus',
    'IT GitHub URL',
    'IT Portfolio URL',
    'IT Languages',
    'IT Frameworks',
    'IT Years Experience',
    'IT Significant Project',
    'IT Why Join',
    'Marketing Expertise',
    'Marketing Platforms Managed',
    'Marketing Budget Experience',
    'Marketing Budget Details',
    'Marketing Budget Size',
    'Marketing Campaign',
    'Marketing Work Links',
    'Marketing Why Join',
    'Revenue-Sharing Response',
    'Weekly Availability',
    'Long-term Commitment',
    'Previous Experience Details',
    'Ideas & Suggestions',
    'Submission Date',
    'Status',
    'Reviewer Notes',
    'Internal Tags'
];

try {
    $stmt = $pdo->query("SELECT * FROM applications ORDER BY submitted_at DESC");
    $applicants = $stmt->fetchAll();

    $rows = [];

    foreach ($applicants as $app) {
        $id = $app['id'];

        // 1. Tracking code
        $tracking_code = 'EXT-' . str_pad($id, 4, '0', STR_PAD_LEFT);

        // 2. Chosen Roles
        $r_stmt = $pdo->prepare("SELECT role_name FROM application_roles WHERE application_id = ?");
        $r_stmt->execute([$id]);
        $roles_list = $r_stmt->fetchAll(PDO::FETCH_COLUMN);
        $roles_str = !empty($roles_list) ? implode(', ', $roles_list) : 'None';

        // 3. Selected Modules (Grouped clearly by year, e.g. "2nd Year: Genetics, Microbio; 3rd Year: Digestive System Unit")
        $m_stmt = $pdo->prepare("SELECT study_year, module_name, is_custom FROM application_modules WHERE application_id = ? ORDER BY study_year, is_custom, module_name");
        $m_stmt->execute([$id]);
        $mods_raw = $m_stmt->fetchAll();

        $grouped_mods = [];
        foreach ($mods_raw as $m) {
            $y = $m['study_year'];
            $mod_label = $m['module_name'] . ($m['is_custom'] ? ' [Custom]' : '');
            $grouped_mods[$y][] = $mod_label;
        }

        $grouped_mods_str_arr = [];
        foreach ($grouped_mods as $year_name => $mod_names) {
            $grouped_mods_str_arr[] = $year_name . ': ' . implode(', ', $mod_names);
        }
        $modules_str = !empty($grouped_mods_str_arr) ? implode('; ', $grouped_mods_str_arr) : 'None';

        // 4. Software tools & proficiency
        $t_stmt = $pdo->prepare("SELECT tool_name, proficiency_level FROM application_tools WHERE application_id = ?");
        $t_stmt->execute([$id]);
        $tools_raw = $t_stmt->fetchAll();
        $tools_arr = [];
        foreach ($tools_raw as $t) {
            $tools_arr[] = $t['tool_name'] . ' (' . $t['proficiency_level'] . ')';
        }
        $tools_str = !empty($tools_arr) ? implode(', ', $tools_arr) : 'None';

        // 5. Portfolio URLs
        $p_stmt = $pdo->prepare("SELECT portfolio_url FROM application_portfolios WHERE application_id = ?");
        $p_stmt->execute([$id]);
        $ports = $p_stmt->fetchAll(PDO::FETCH_COLUMN);
        $portfolios_str = !empty($ports) ? implode('; ', $ports) : 'None';

        // 6. Communities
        $c_stmt = $pdo->prepare("SELECT community_name FROM application_communities WHERE application_id = ?");
        $c_stmt->execute([$id]);
        $comms = $c_stmt->fetchAll(PDO::FETCH_COLUMN);
        $communities_str = !empty($comms) ? implode(', ', $comms) : 'None';

        // 7. Design specialties
        $spec_stmt = $pdo->prepare("SELECT specialty_name FROM application_design_specialties WHERE application_id = ?");
        $spec_stmt->execute([$id]);
        $specs = $spec_stmt->fetchAll(PDO::FETCH_COLUMN);
        $specialties_str = !empty($specs) ? implode(', ', $specs) : 'None';

        // 8. Community sub-role contribution & platforms
        $cc_stmt = $pdo->prepare("SELECT contribution_name FROM application_community_contributions WHERE application_id = ?");
        $cc_stmt->execute([$id]);
        $comm_contrib_str = implode(', ', $cc_stmt->fetchAll(PDO::FETCH_COLUMN)) ?: 'None';

        $cp_stmt = $pdo->prepare("SELECT platform_name FROM application_community_platforms WHERE application_id = ?");
        $cp_stmt->execute([$id]);
        $comm_platforms_str = implode(', ', $cp_stmt->fetchAll(PDO::FETCH_COLUMN)) ?: 'None';

        // 9. IT / Development focus
        $it_stmt = $pdo->prepare("SELECT focus_name FROM application_it_focus WHERE application_id = ?");
        $it_stmt->execute([$id]);
        $it_focus_str = implode(', ', $it_stmt->fetchAll(PDO::FETCH_COLUMN)) ?: 'None';

        // 10. Marketing expertise & platforms
        $me_stmt = $pdo->prepare("SELECT expertise_name FROM application_marketing_expertise WHERE application_id = ?");
        $me_stmt->execute([$id]);
        $mkt_expertise_str = implode(', ', $me_stmt->fetchAll(PDO::FETCH_COLUMN)) ?: 'None';

        $mp_stmt = $pdo->prepare("SELECT platform_name FROM application_marketing_platforms WHERE application_id = ?");
        $mp_stmt->execute([$id]);
        $mkt_platforms_str = implode(', ', $mp_stmt->fetchAll(PDO::FETCH_COLUMN)) ?: 'None';

        // 11. Previous experience details
        $prev_exp_details = ($app['previous_experience'] === 'Yes' && !empty($app['previous_experience_details'])) 
            ? $app['previous_experience_details'] 
            : 'No previous experience';

        $row = [
            $tracking_code,
            $app['full_name'],
            $app['email'],
            $app['whatsapp'],
            $app['telegram'],
            $app['faculty'],
            $app['academic_year'],
            $app['recruitment_path'],
            $roles_str,
            $modules_str,
            $tools_str,
            $specialties_str,
            $portfolios_str,
            $communities_str,
            $comm_contrib_str,
            $app['community_managed_before'] ?? 'No',
            $app['community_member_count'] ?? '',
            $comm_platforms_str,
            $app['community_hours_per_week'] ?? '',
            $app['community_why_join'] ?? '',
            $app['community_unique_value'] ?? '',
            $app['community_problem_solving'] ?? '',
            $app['community_portfolio_links'] ?? '',
            $it_focus_str,
            $app['it_github_url'] ?? '',
            $app['it_portfolio_url'] ?? '',
            $app['it_languages'] ?? '',
            $app['it_frameworks'] ?? '',
            $app['it_years_experience'] ?? '',
            $app['it_significant_project'] ?? '',
            $app['it_why_join'] ?? '',
            $mkt_expertise_str,
            $mkt_platforms_str,
            $app['marketing_budget_experience'] ?? 'No',
            $app['marketing_budget_details'] ?? '',
            $app['marketing_budget_size'] ?? '',
            $app['marketing_campaign'] ?? '',
            $app['marketing_work_links'] ?? '',
            $app['marketing_why_join'] ?? '',
            $app['revenue_sharing_response'] ?? '',
            $app['availability'],
            $app['long_term_commitment'],
            $prev_exp_details,
            $app['ideas'],
            $app['submitted_at'],
            $app['status'],
            $app['notes'] ?? '',
            $app['internal_tags'] ?? ''
        ];

        $rows[] = $row;
    }

} catch (Exception $e) {
    die("Export Error: " . $e->getMessage());
}

if ($format === 'xlsx') {
    // Send Excel HTML Table format
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename_base . '.xls"');
    header('Cache-Control: max-age=0');
    
    echo '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">';
    echo '<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">';
    echo '<!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>Applicants</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]-->';
    echo '<style>';
    echo 'th { background-color: #0284c7; color: #ffffff; font-weight: bold; border: 1px solid #0369a1; text-align: left; padding: 10px 14px; font-family: Arial, sans-serif; font-size: 11pt; }';
    echo 'td { border: 1px solid #cbd5e1; vertical-align: top; padding: 8px 12px; font-family: Arial, sans-serif; font-size: 10pt; mso-number-format: "\@"; }';
    echo 'tr:nth-child(even) td { background-color: #f8fafc; }';
    echo '</style>';
    echo '</head><body>';
    echo '<table><thead><tr>';
    foreach ($headers as $h) {
        echo '<th>' . htmlspecialchars($h) . '</th>';
    }
    echo '</tr></thead><tbody>';
    foreach ($rows as $r) {
        echo '<tr>';
        foreach ($r as $val) {
            echo '<td>' . nl2br(htmlspecialchars($val ?? '')) . '</td>';
        }
        echo '</tr>';
    }
    echo '</tbody></table></body></html>';
    exit;

} else {
    // Standard CSV format with UTF-8 BOM
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename_base . '.csv"');
    header('Pragma: no-cache');
    header('Expires: 0');

    $output = fopen('php://output', 'w');
    
    // Output UTF-8 BOM for Microsoft Excel Arabic & French rendering
    fwrite($output, "\xEF\xBB\xBF");
    
    // Header
    fputcsv($output, $headers);

    // Rows
    foreach ($rows as $r) {
        fputcsv($output, $r);
    }

    fclose($output);
    exit;
}
