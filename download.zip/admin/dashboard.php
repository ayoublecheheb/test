<?php
/**
 * L'EXTERNE ATS - Main Admin Dashboard
 * Secure, advanced filter and table rendering of applicants.
 * Light mode glassmorphism UI.
 */

require_once __DIR__ . '/../functions.php';

// Force review board access
require_login();

// Gather global counts for metrics
$stats_submitted = 0;
$stats_accepted = 0;
$stats_interview = 0;
$stats_views = intval(get_setting('views_total', '1480'));

try {
    $stats_submitted = $pdo->query("SELECT COUNT(*) FROM applications")->fetchColumn();
    $stats_accepted = $pdo->query("SELECT COUNT(*) FROM applications WHERE status = 'Accepted'")->fetchColumn();
    $stats_interview = $pdo->query("SELECT COUNT(*) FROM applications WHERE status = 'Interview'")->fetchColumn();
} catch (Exception $e) {}

// Extract filter parameters
$search = trim($_GET['search'] ?? '');
$filter_status = trim($_GET['status'] ?? '');
$filter_path = trim($_GET['path'] ?? '');
$filter_faculty = trim($_GET['faculty'] ?? '');
$filter_year = trim($_GET['year'] ?? '');
$filter_favorite = isset($_GET['favorite']) ? intval($_GET['favorite']) : -1;
$sort_by = trim($_GET['sort'] ?? 'submitted_at');
$sort_order = trim($_GET['order'] ?? 'DESC');

// Pagination params
$page = max(1, intval($_GET['page'] ?? 1));
$limit = 15;
$offset = ($page - 1) * $limit;

// Construct SQL query dynamically
$query_parts = ["WHERE 1=1"];
$params = [];

if (!empty($search)) {
    $query_parts[] = "AND (full_name LIKE ? OR email LIKE ? OR telegram LIKE ? OR whatsapp LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if (!empty($filter_status)) {
    $query_parts[] = "AND status = ?";
    $params[] = $filter_status;
}

if (!empty($filter_path)) {
    $query_parts[] = "AND recruitment_path = ?";
    $params[] = $filter_path;
}

if (!empty($filter_faculty)) {
    $query_parts[] = "AND faculty = ?";
    $params[] = $filter_faculty;
}

if (!empty($filter_year)) {
    $query_parts[] = "AND academic_year = ?";
    $params[] = $filter_year;
}

if ($filter_favorite === 1) {
    $query_parts[] = "AND is_favorite = 1";
}

$where_clause = implode(" ", $query_parts);

// Validate sorting inputs
$allowed_sorts = ['submitted_at', 'full_name', 'academic_year', 'status'];
if (!in_array($sort_by, $allowed_sorts)) {
    $sort_by = 'submitted_at';
}
$sort_order = ($sort_order === 'ASC') ? 'ASC' : 'DESC';

// Fetch matching applicants
$applicants = [];
$total_matching = 0;

try {
    // Count matches
    $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM applications $where_clause");
    $count_stmt->execute($params);
    $total_matching = $count_stmt->fetchColumn();

    // Select page
    $select_sql = "SELECT * FROM applications $where_clause ORDER BY $sort_by $sort_order LIMIT $limit OFFSET $offset";
    $select_stmt = $pdo->prepare($select_sql);
    $select_stmt->execute($params);
    $applicants = $select_stmt->fetchAll();
} catch (PDOException $e) {
    $error_sql = $e->getMessage();
}

$total_pages = ceil($total_matching / $limit);
?>
<!DOCTYPE html>
<html lang="en" class="h-full bg-slate-50">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Board - L'EXTERNE ATS</title>
    <link rel="icon" type="image/png" href="../assets/images/logo.png">
    
    <!-- Tailwind and UI fonts -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace'],
                    }
                }
            }
        }
    </script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
    </style>
</head>
<body class="min-h-full flex flex-col">

    <!-- Top Admin Header -->
    <header class="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <a href="../index.php" class="flex items-center gap-2">
                    <img src="../assets/images/logo.png" alt="L'EXTERNE Logo" class="h-8 w-8 object-contain">
                    <span class="text-lg font-bold text-slate-900 tracking-tight">L'EXTERNE</span>
                </a>
                <span class="px-2 py-0.5 rounded-md bg-sky-50 text-[10px] font-bold text-sky-700 uppercase tracking-wider border border-sky-100">Review Board</span>
            </div>
            <div class="flex items-center gap-4">
                <span class="text-xs text-slate-500 font-medium">Hello, <strong><?php echo htmlspecialchars($_SESSION['user_name']); ?></strong></span>
                <a href="../logout.php" class="text-xs font-semibold text-rose-600 hover:text-rose-500 bg-rose-50 border border-rose-100/50 px-2.5 py-1.5 rounded-lg transition-colors">Sign Out</a>
            </div>
        </div>
    </header>

    <div class="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col md:flex-row gap-8">
        
        <!-- SIDEBAR NAVIGATION -->
        <aside class="w-full md:w-64 shrink-0 space-y-2">
            <a href="dashboard.php" class="flex items-center gap-3 px-4 py-3 bg-sky-50 text-sky-700 font-bold rounded-xl text-sm border border-sky-100">
                <span>📋</span> Applicants List
            </a>
            <a href="analytics.php" class="flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-slate-100 hover:text-slate-900 rounded-xl text-sm transition-colors">
                <span>📈</span> Analytical Charts
            </a>
            <a href="settings.php" class="flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-slate-100 hover:text-slate-900 rounded-xl text-sm transition-colors">
                <span>⚙️</span> Campaign Settings
            </a>
            <div class="pt-2">
                <p class="text-[10px] font-bold uppercase text-slate-400 tracking-wider px-4 mb-1">Export Candidates</p>
                <div class="grid grid-cols-2 gap-2 px-2">
                    <a href="export.php?format=xlsx" class="flex items-center justify-center gap-1.5 px-3 py-2 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 font-bold rounded-xl text-xs border border-emerald-200 transition-colors">
                        <span>📊</span> Excel (.xlsx)
                    </a>
                    <a href="export.php?format=csv" class="flex items-center justify-center gap-1.5 px-3 py-2 bg-sky-50 text-sky-700 hover:bg-sky-100 font-bold rounded-xl text-xs border border-sky-200 transition-colors">
                        <span>📄</span> CSV File
                    </a>
                </div>
            </div>
            <div class="pt-6 border-t border-slate-200 mt-6">
                <p class="text-[10px] font-bold uppercase text-slate-400 tracking-wider px-4">Setup Quick Links</p>
                <a href="../index.php" target="_blank" class="flex items-center gap-3 px-4 py-2 text-xs text-slate-500 hover:text-sky-600 transition-colors">
                    🔗 View Live Site
                </a>
                <a href="../fix.php" class="flex items-center gap-3 px-4 py-2 text-xs text-slate-500 hover:text-sky-600 transition-colors">
                    🔧 Run DB Diagnostics
                </a>
            </div>
        </aside>

        <!-- DASHBOARD BODY CONTAINER -->
        <main class="flex-grow space-y-8 min-w-0">
            
            <!-- Metric Overview Cards -->
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <p class="text-xs font-bold uppercase text-slate-400 tracking-wider">Total Applicants</p>
                    <p class="text-2xl font-black text-slate-900 mt-2"><?php echo $stats_submitted; ?></p>
                </div>
                <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <p class="text-xs font-bold uppercase text-slate-400 tracking-wider">Interviews Set</p>
                    <p class="text-2xl font-black text-blue-600 mt-2"><?php echo $stats_interview; ?></p>
                </div>
                <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <p class="text-xs font-bold uppercase text-slate-400 tracking-wider">Accepted Candidates</p>
                    <p class="text-2xl font-black text-emerald-600 mt-2"><?php echo $stats_accepted; ?></p>
                </div>
                <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <p class="text-xs font-bold uppercase text-slate-400 tracking-wider">Unique Site Views</p>
                    <p class="text-2xl font-black text-slate-700 mt-2"><?php echo $stats_views; ?></p>
                </div>
            </div>

            <!-- SEARCH, FILTERS & ACTION BAR -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
                <form method="GET" action="dashboard.php" class="space-y-4">
                    <!-- Global Search input -->
                    <div class="flex flex-col sm:flex-row gap-4">
                        <div class="relative flex-grow">
                            <span class="absolute left-3.5 top-3 text-slate-400 text-sm">🔍</span>
                            <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search by name, email, WhatsApp, Telegram..." class="w-full rounded-xl border border-slate-200 pl-10 pr-4 py-2.5 text-sm focus:border-sky-500 focus:outline-none transition-colors">
                        </div>
                        <button type="submit" class="px-5 py-2.5 bg-sky-600 hover:bg-sky-500 text-white font-bold text-sm rounded-xl transition-colors shrink-0">Apply Filters</button>
                        <a href="dashboard.php" class="px-4 py-2.5 border border-slate-200 text-slate-600 hover:bg-slate-50 font-bold text-sm rounded-xl transition-colors shrink-0 text-center">Clear Filters</a>
                    </div>

                    <!-- Dropdown Filters Rail -->
                    <div class="grid grid-cols-2 sm:grid-cols-5 gap-3">
                        <!-- Status -->
                        <select name="status" class="rounded-xl border border-slate-200 px-3 py-2 text-xs focus:outline-none focus:border-sky-500 bg-white">
                            <option value="">All Statuses</option>
                            <option value="Pending" <?php echo $filter_status === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="Interview" <?php echo $filter_status === 'Interview' ? 'selected' : ''; ?>>Interview</option>
                            <option value="Accepted" <?php echo $filter_status === 'Accepted' ? 'selected' : ''; ?>>Accepted</option>
                            <option value="Rejected" <?php echo $filter_status === 'Rejected' ? 'selected' : ''; ?>>Rejected</option>
                            <option value="Archived" <?php echo $filter_status === 'Archived' ? 'selected' : ''; ?>>Archived</option>
                        </select>

                        <!-- Path -->
                        <select name="path" class="rounded-xl border border-slate-200 px-3 py-2 text-xs focus:outline-none focus:border-sky-500 bg-white">
                            <option value="">All Paths</option>
                            <option value="Editorial" <?php echo $filter_path === 'Editorial' ? 'selected' : ''; ?>>Editorial</option>
                            <option value="Community" <?php echo $filter_path === 'Community' ? 'selected' : ''; ?>>Community</option>
                            <option value="Both" <?php echo $filter_path === 'Both' ? 'selected' : ''; ?>>Both Tracks</option>
                        </select>

                        <!-- Academic Year -->
                        <select name="year" class="rounded-xl border border-slate-200 px-3 py-2 text-xs focus:outline-none focus:border-sky-500 bg-white">
                            <option value="">All Academic Years</option>
                            <?php foreach (get_academic_years() as $y): ?>
                                <option value="<?php echo htmlspecialchars($y); ?>" <?php echo $filter_year === $y ? 'selected' : ''; ?>><?php echo htmlspecialchars($y); ?></option>
                            <?php endforeach; ?>
                        </select>

                        <!-- Favorites -->
                        <select name="favorite" class="rounded-xl border border-slate-200 px-3 py-2 text-xs focus:outline-none focus:border-sky-500 bg-white">
                            <option value="-1">All Favorites</option>
                            <option value="1" <?php echo $filter_favorite === 1 ? 'selected' : ''; ?>>Starred Only</option>
                        </select>

                        <!-- Sorting Option -->
                        <select name="sort" class="rounded-xl border border-slate-200 px-3 py-2 text-xs focus:outline-none focus:border-sky-500 bg-white">
                            <option value="submitted_at" <?php echo $sort_by === 'submitted_at' ? 'selected' : ''; ?>>Submission Date</option>
                            <option value="full_name" <?php echo $sort_by === 'full_name' ? 'selected' : ''; ?>>Candidate Name</option>
                            <option value="status" <?php echo $sort_by === 'status' ? 'selected' : ''; ?>>Review Status</option>
                        </select>
                    </div>
                </form>
            </div>

            <!-- APPLICANTS LIST TABLE CARD -->
            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                <div class="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
                    <h3 class="text-sm font-bold text-slate-800">Applicants Match Pool (<?php echo $total_matching; ?> found)</h3>
                    <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Light Theme Console</div>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-slate-50 border-b border-slate-200/80 text-[10px] font-bold uppercase text-slate-400 tracking-wider">
                                <th class="py-3.5 px-6">Candidate</th>
                                <th class="py-3.5 px-4">Contact Detail</th>
                                <th class="py-3.5 px-4">University & Year</th>
                                <th class="py-3.5 px-4">Chosen Track</th>
                                <th class="py-3.5 px-4">Date Submitted</th>
                                <th class="py-3.5 px-4">Status</th>
                                <th class="py-3.5 px-6 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 text-xs">
                            <?php if (empty($applicants)): ?>
                                <tr>
                                    <td colspan="7" class="py-12 text-center text-slate-400 font-medium">No candidates match your search parameters.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($applicants as $app): ?>
                                    <tr class="hover:bg-slate-50/50 transition-colors">
                                        <!-- Candidate Identity + Fav Star -->
                                        <td class="py-4 px-6 font-semibold text-slate-900">
                                            <div class="flex items-center gap-2">
                                                <button onclick="toggleFavorite(<?php echo $app['id']; ?>, this)" class="text-sm focus:outline-none">
                                                    <span class="fav-star <?php echo $app['is_favorite'] ? 'text-amber-400' : 'text-slate-200 hover:text-slate-400'; ?>">★</span>
                                                </button>
                                                <a href="applicant.php?id=<?php echo $app['id']; ?>" class="hover:text-sky-600 hover:underline"><?php echo htmlspecialchars($app['full_name']); ?></a>
                                            </div>
                                        </td>
                                        <!-- Contacts -->
                                        <td class="py-4 px-4 text-slate-500">
                                            <div class="space-y-0.5">
                                                <p><?php echo htmlspecialchars($app['email']); ?></p>
                                                <div class="flex items-center gap-2 text-[10px] font-bold">
                                                    <span class="text-indigo-600">Tel: <?php echo htmlspecialchars($app['telegram']); ?></span>
                                                    <span class="text-emerald-600">WA: <?php echo htmlspecialchars($app['whatsapp']); ?></span>
                                                </div>
                                            </div>
                                        </td>
                                        <!-- University / Year -->
                                        <td class="py-4 px-4 text-slate-600">
                                            <div class="space-y-0.5 max-w-[180px] truncate">
                                                <p class="truncate font-medium"><?php echo htmlspecialchars($app['faculty']); ?></p>
                                                <p class="text-[10px] font-semibold text-slate-400 uppercase"><?php echo htmlspecialchars($app['academic_year']); ?></p>
                                            </div>
                                        </td>
                                        <!-- Chosen Track -->
                                        <td class="py-4 px-4 font-bold text-slate-700">
                                            <?php echo htmlspecialchars($app['recruitment_path']); ?>
                                        </td>
                                        <!-- Date -->
                                        <td class="py-4 px-4 text-slate-400 font-medium">
                                            <?php echo date('M d, Y', strtotime($app['submitted_at'])); ?>
                                        </td>
                                        <!-- Status indicator -->
                                        <td class="py-4 px-4">
                                            <span class="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-bold border <?php echo get_status_badge_class($app['status']); ?>">
                                                <?php echo htmlspecialchars($app['status']); ?>
                                            </span>
                                        </td>
                                        <!-- Actions -->
                                        <td class="py-4 px-6 text-right">
                                            <div class="flex items-center justify-end gap-2">
                                                <a href="applicant.php?id=<?php echo $app['id']; ?>" class="px-2 py-1 bg-slate-50 hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-md font-bold text-[10px] transition-colors">Review profile</a>
                                                <button onclick="confirmDelete(<?php echo $app['id']; ?>, '<?php echo addslashes($app['full_name']); ?>')" class="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-100 rounded-md font-bold text-[10px] transition-colors">Delete</button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- PAGINATION BAR -->
                <?php if ($total_pages > 1): ?>
                    <div class="px-6 py-4 border-t border-slate-100 bg-slate-50/50 flex items-center justify-between">
                        <span class="text-xs text-slate-500">Showing page <strong><?php echo $page; ?></strong> of <strong><?php echo $total_pages; ?></strong> (<?php echo $total_matching; ?> applicants)</span>
                        <div class="flex items-center gap-1.5">
                            <?php if ($page > 1): ?>
                                <a href="?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($filter_status); ?>&path=<?php echo urlencode($filter_path); ?>&year=<?php echo urlencode($filter_year); ?>" class="px-3 py-1.5 border border-slate-200 text-slate-600 bg-white rounded-lg hover:bg-slate-50 text-xs font-bold">Previous</a>
                            <?php endif; ?>
                            <?php if ($page < $total_pages): ?>
                                <a href="?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&status=<?php echo urlencode($filter_status); ?>&path=<?php echo urlencode($filter_path); ?>&year=<?php echo urlencode($filter_year); ?>" class="px-3 py-1.5 border border-slate-200 text-slate-600 bg-white rounded-lg hover:bg-slate-50 text-xs font-bold">Next</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <!-- Confirm Deletion Dialog Modal -->
    <div id="deleteModal" class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center hidden">
        <div class="bg-white rounded-2xl border border-slate-200 max-w-sm w-full mx-4 p-6 shadow-xl animate-fadeIn">
            <h4 class="text-base font-bold text-slate-900">Confirm Candidate Removal</h4>
            <p class="text-xs text-slate-600 mt-2 leading-relaxed">
                Are you absolutely sure you want to delete <strong id="deleteCandidateName">Sofia</strong> from the recruitment database? This operation is completely irreversible.
            </p>
            <div class="mt-6 flex justify-end gap-3">
                <button onclick="closeDeleteModal()" class="px-3 py-2 border border-slate-200 text-slate-700 font-bold text-xs rounded-xl hover:bg-slate-50">Cancel</button>
                <button id="deleteConfirmBtn" class="px-3 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-xl shadow-sm">Permanently Delete</button>
            </div>
        </div>
    </div>

    <!-- AJAX OPERATIONS -->
    <script>
        let applicantIdToDelete = null;

        function toggleFavorite(id, button) {
            const fd = new FormData();
            fd.append('action', 'toggle_favorite');
            fd.append('id', id);

            fetch('../api.php', {
                method: 'POST',
                body: fd
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    const star = button.querySelector('.fav-star');
                    if (star.classList.contains('text-amber-400')) {
                        star.className = "fav-star text-slate-200 hover:text-slate-400";
                    } else {
                        star.className = "fav-star text-amber-400";
                    }
                }
            });
        }

        function confirmDelete(id, name) {
            applicantIdToDelete = id;
            document.getElementById('deleteCandidateName').innerText = name;
            
            const btn = document.getElementById('deleteConfirmBtn');
            btn.onclick = executeDelete;

            document.getElementById('deleteModal').classList.remove('hidden');
        }

        function closeDeleteModal() {
            document.getElementById('deleteModal').classList.add('hidden');
            applicantIdToDelete = null;
        }

        function executeDelete() {
            if (!applicantIdToDelete) return;

            const fd = new FormData();
            fd.append('action', 'delete_applicant');
            fd.append('id', applicantIdToDelete);

            fetch('../api.php', {
                method: 'POST',
                body: fd
            })
            .then(res => res.json())
            .then(data => {
                closeDeleteModal();
                if (data.status === 'success') {
                    window.location.reload();
                } else {
                    alert("Failure deleting candidate: " + data.message);
                }
            })
            .catch(err => {
                closeDeleteModal();
                alert("Network error. Please try again.");
            });
        }
    </script>
</body>
</html>
