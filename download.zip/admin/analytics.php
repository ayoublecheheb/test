<?php
/**
 * L'EXTERNE ATS - Real-Time Analytics & Report Console
 * Fully modular and compatible with shared hosts.
 * Renders beautiful inline SVG and CSS metrics bars without external slow JS.
 */

require_once __DIR__ . '/../functions.php';

// Force admin access
require_login();

// Initial database aggregates
$metrics = [
    'total' => 0,
    'pending' => 0,
    'interview' => 0,
    'accepted' => 0,
    'rejected' => 0,
    'archived' => 0,
    'editorial' => 0,
    'community' => 0,
    'both' => 0,
    'faculties' => [],
    'academic_years' => [],
    'design_tools' => [],
    'communities' => []
];

try {
    // 1. Core statuses
    $metrics['total'] = $pdo->query("SELECT COUNT(*) FROM applications")->fetchColumn();
    $metrics['pending'] = $pdo->query("SELECT COUNT(*) FROM applications WHERE status = 'Pending'")->fetchColumn();
    $metrics['interview'] = $pdo->query("SELECT COUNT(*) FROM applications WHERE status = 'Interview'")->fetchColumn();
    $metrics['accepted'] = $pdo->query("SELECT COUNT(*) FROM applications WHERE status = 'Accepted'")->fetchColumn();
    $metrics['rejected'] = $pdo->query("SELECT COUNT(*) FROM applications WHERE status = 'Rejected'")->fetchColumn();
    $metrics['archived'] = $pdo->query("SELECT COUNT(*) FROM applications WHERE status = 'Archived'")->fetchColumn();

    // 2. Tracks count
    $metrics['editorial'] = $pdo->query("SELECT COUNT(*) FROM applications WHERE recruitment_path = 'Editorial'")->fetchColumn();
    $metrics['community'] = $pdo->query("SELECT COUNT(*) FROM applications WHERE recruitment_path = 'Community'")->fetchColumn();
    $metrics['both'] = $pdo->query("SELECT COUNT(*) FROM applications WHERE recruitment_path = 'Both'")->fetchColumn();

    // 3. Faculty ranking
    $f_stmt = $pdo->query("SELECT faculty, COUNT(*) as c FROM applications GROUP BY faculty ORDER BY c DESC");
    $metrics['faculties'] = $f_stmt->fetchAll();

    // 4. Year ranking
    $y_stmt = $pdo->query("SELECT academic_year, COUNT(*) as c FROM applications GROUP BY academic_year ORDER BY c DESC");
    $metrics['academic_years'] = $y_stmt->fetchAll();

    // 5. Popular design tools
    $t_stmt = $pdo->query("SELECT tool_name, COUNT(*) as c FROM application_tools GROUP BY tool_name ORDER BY c DESC LIMIT 10");
    $metrics['design_tools'] = $t_stmt->fetchAll();

    // 6. Communities ranking
    $c_stmt = $pdo->query("SELECT community_name, COUNT(*) as c FROM application_communities GROUP BY community_name ORDER BY c DESC");
    $metrics['communities'] = $c_stmt->fetchAll();

} catch (Exception $e) {
    $db_err = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en" class="h-full bg-slate-50">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recruitment Analytics - L'EXTERNE Console</title>
    <link rel="icon" type="image/png" href="../assets/images/logo.png">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
    </style>
</head>
<body class="min-h-full flex flex-col">

    <!-- Top Navigation Header -->
    <header class="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <a href="../index.php" class="flex items-center gap-2">
                    <img src="../assets/images/logo.png" alt="L'EXTERNE Logo" class="h-8 w-8 object-contain">
                    <span class="text-lg font-bold text-slate-900 tracking-tight">L'EXTERNE</span>
                </a>
                <span class="px-2 py-0.5 rounded-md bg-sky-50 text-[10px] font-bold text-sky-700 uppercase border border-sky-100">Analytics Console</span>
            </div>
            <div class="flex items-center gap-4">
                <span class="text-xs text-slate-500">Hello, <strong><?php echo htmlspecialchars($_SESSION['user_name']); ?></strong></span>
                <a href="../logout.php" class="text-xs font-semibold text-rose-600 bg-rose-50 px-2.5 py-1.5 rounded-lg">Sign Out</a>
            </div>
        </div>
    </header>

    <div class="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col md:flex-row gap-8">
        
        <!-- SIDEBAR -->
        <aside class="w-full md:w-64 shrink-0 space-y-2">
            <a href="dashboard.php" class="flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-slate-100 hover:text-slate-900 rounded-xl text-sm transition-colors">
                <span>📋</span> Applicants List
            </a>
            <a href="analytics.php" class="flex items-center gap-3 px-4 py-3 bg-sky-50 text-sky-700 font-bold rounded-xl text-sm border border-sky-100">
                <span>📈</span> Analytical Charts
            </a>
            <a href="settings.php" class="flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-slate-100 hover:text-slate-900 rounded-xl text-sm transition-colors">
                <span>⚙️</span> Campaign Settings
            </a>
            <a href="export.php" class="flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-slate-100 hover:text-slate-900 rounded-xl text-sm transition-colors">
                <span>📦</span> Download XLSX/CSV
            </a>
        </aside>

        <!-- ANALYTICS CHARTS VIEW -->
        <main class="flex-grow space-y-8 min-w-0">
            <h2 class="text-xl font-extrabold text-slate-900 tracking-tight">System Analytics Report</h2>

            <?php if (isset($db_err)): ?>
                <div class="p-4 bg-rose-50 text-rose-800 rounded-xl text-xs font-semibold">Database aggregates failed: <?php echo htmlspecialchars($db_err); ?></div>
            <?php endif; ?>

            <!-- STATUS KPI METERS -->
            <div class="grid grid-cols-2 sm:grid-cols-5 gap-4">
                <div class="bg-white p-4 rounded-xl border border-slate-200">
                    <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Pending</span>
                    <span class="block text-xl font-extrabold text-amber-600 mt-1"><?php echo $metrics['pending']; ?></span>
                </div>
                <div class="bg-white p-4 rounded-xl border border-slate-200">
                    <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Interviews</span>
                    <span class="block text-xl font-extrabold text-blue-600 mt-1"><?php echo $metrics['interview']; ?></span>
                </div>
                <div class="bg-white p-4 rounded-xl border border-slate-200">
                    <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Accepted</span>
                    <span class="block text-xl font-extrabold text-emerald-600 mt-1"><?php echo $metrics['accepted']; ?></span>
                </div>
                <div class="bg-white p-4 rounded-xl border border-slate-200">
                    <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Rejected</span>
                    <span class="block text-xl font-extrabold text-rose-600 mt-1"><?php echo $metrics['rejected']; ?></span>
                </div>
                <div class="bg-white p-4 rounded-xl border border-slate-200">
                    <span class="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Archived</span>
                    <span class="block text-xl font-extrabold text-slate-500 mt-1"><?php echo $metrics['archived']; ?></span>
                </div>
            </div>

            <!-- GRID OF ADVANCED CHARTS -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                
                <!-- CHART 1: RECRUITMENT PATHS (SVG DONUT OR METER) -->
                <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                    <h3 class="text-sm font-bold text-slate-800">Recruitment Paths Weights</h3>
                    
                    <div class="space-y-4 pt-4">
                        <?php
                        $total_paths = max(1, $metrics['editorial'] + $metrics['community'] + $metrics['both']);
                        $pct_ed = round(($metrics['editorial'] / $total_paths) * 100, 1);
                        $pct_comm = round(($metrics['community'] / $total_paths) * 100, 1);
                        $pct_both = round(($metrics['both'] / $total_paths) * 100, 1);
                        ?>
                        <div>
                            <div class="flex justify-between text-xs font-bold text-slate-600 mb-1.5">
                                <span>✍️ Editorial Only (Writers/Designers)</span>
                                <span><?php echo $metrics['editorial']; ?> (<?php echo $pct_ed; ?>%)</span>
                            </div>
                            <div class="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                                <div class="bg-sky-500 h-full rounded-full" style="width: <?php echo $pct_ed; ?>%"></div>
                            </div>
                        </div>

                        <div>
                            <div class="flex justify-between text-xs font-bold text-slate-600 mb-1.5">
                                <span>👥 Community Only (Tech/Ops/HR)</span>
                                <span><?php echo $metrics['community']; ?> (<?php echo $pct_comm; ?>%)</span>
                            </div>
                            <div class="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                                <div class="bg-indigo-500 h-full rounded-full" style="width: <?php echo $pct_comm; ?>%"></div>
                            </div>
                        </div>

                        <div>
                            <div class="flex justify-between text-xs font-bold text-slate-600 mb-1.5">
                                <span>🔮 Both tracks interested</span>
                                <span><?php echo $metrics['both']; ?> (<?php echo $pct_both; ?>%)</span>
                            </div>
                            <div class="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                                <div class="bg-emerald-500 h-full rounded-full" style="width: <?php echo $pct_both; ?>%"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- CHART 2: TOP MEDICAL FACULTIES -->
                <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                    <h3 class="text-sm font-bold text-slate-800">Top faculties represented</h3>
                    
                    <div class="space-y-3 max-h-[220px] overflow-y-auto pr-2">
                        <?php if (empty($metrics['faculties'])): ?>
                            <p class="text-xs text-slate-400 italic">No faculty data available.</p>
                        <?php else: ?>
                            <?php 
                            $max_fac = max(1, $metrics['faculties'][0]['c'] ?? 1);
                            foreach ($metrics['faculties'] as $fac): 
                                $pct = round(($fac['c'] / $max_fac) * 100);
                            ?>
                                <div>
                                    <div class="flex justify-between text-[11px] font-semibold text-slate-600 mb-1">
                                        <span class="truncate max-w-[200px]"><?php echo htmlspecialchars($fac['faculty']); ?></span>
                                        <span><?php echo $fac['c']; ?> candidates</span>
                                    </div>
                                    <div class="w-full bg-slate-50 h-2 rounded-full overflow-hidden">
                                        <div class="bg-sky-600 h-full rounded-full" style="width: <?php echo $pct; ?>%"></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- CHART 3: ACADEMIC YEARS DISTRIBUTION -->
                <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                    <h3 class="text-sm font-bold text-slate-800">Academic Study Levels</h3>
                    
                    <div class="space-y-3 max-h-[220px] overflow-y-auto pr-2">
                        <?php if (empty($metrics['academic_years'])): ?>
                            <p class="text-xs text-slate-400 italic">No academic year data available.</p>
                        <?php else: ?>
                            <?php 
                            $max_yr = max(1, $metrics['academic_years'][0]['c'] ?? 1);
                            foreach ($metrics['academic_years'] as $yr): 
                                $pct = round(($yr['c'] / $max_yr) * 100);
                            ?>
                                <div>
                                    <div class="flex justify-between text-[11px] font-semibold text-slate-600 mb-1">
                                        <span><?php echo htmlspecialchars($yr['academic_year']); ?></span>
                                        <span><?php echo $yr['c']; ?> candidates</span>
                                    </div>
                                    <div class="w-full bg-slate-50 h-2 rounded-full overflow-hidden">
                                        <div class="bg-indigo-600 h-full rounded-full" style="width: <?php echo $pct; ?>%"></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- CHART 4: DESIGN & MEDIA SOFTWARES -->
                <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                    <h3 class="text-sm font-bold text-slate-800">Software Suite Popularity</h3>
                    
                    <div class="space-y-3 max-h-[220px] overflow-y-auto pr-2">
                        <?php if (empty($metrics['design_tools'])): ?>
                            <p class="text-xs text-slate-400 italic">No software data logged.</p>
                        <?php else: ?>
                            <?php 
                            $max_tl = max(1, $metrics['design_tools'][0]['c'] ?? 1);
                            foreach ($metrics['design_tools'] as $tl): 
                                $pct = round(($tl['c'] / $max_tl) * 100);
                            ?>
                                <div>
                                    <div class="flex justify-between text-[11px] font-semibold text-slate-600 mb-1">
                                        <span><?php echo htmlspecialchars($tl['tool_name']); ?></span>
                                        <span><?php echo $tl['c']; ?> mentions</span>
                                    </div>
                                    <div class="w-full bg-slate-50 h-2 rounded-full overflow-hidden">
                                        <div class="bg-emerald-600 h-full rounded-full" style="width: <?php echo $pct; ?>%"></div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

            </div>

        </main>
    </div>
</body>
</html>
