<?php
/**
 * L'EXTERNE ATS - Campaign & CMS Settings Control Panel
 * Fully functional form for editing site copy, FAQ json and campaign availability.
 */

require_once __DIR__ . '/../functions.php';

// Force admin access
require_login();

$message = '';
$message_type = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Save settings
    $status = trim($_POST['recruitment_status'] ?? 'open');
    $title = trim($_POST['site_title'] ?? "L'EXTERNE Recruitment");
    $desc = trim($_POST['site_description'] ?? '');
    $hero_t = trim($_POST['hero_title'] ?? '');
    $hero_sub = trim($_POST['hero_subtitle'] ?? '');
    $stats_b = trim($_POST['stats_books'] ?? '45+ Books Published');
    $stats_u = trim($_POST['stats_users'] ?? '15k+ Med Students');
    $stats_c = trim($_POST['stats_contributors'] ?? '120+ Team Members');

    // Parse FAQ fields (dedicated `faqs` table — supports add/edit/delete/reorder/show-hide)
    $faq_id = $_POST['faq_id'] ?? [];
    $faq_q = $_POST['faq_q'] ?? [];
    $faq_a = $_POST['faq_a'] ?? [];
    $faq_visible = $_POST['faq_visible'] ?? [];

    // Validate & normalize FAQ rows (question + answer both required per row)
    $faq_errors = [];
    $faq_sync = [];
    for ($i = 0; $i < count($faq_q); $i++) {
        $q = trim($faq_q[$i] ?? '');
        $a = trim($faq_a[$i] ?? '');
        if ($q === '' && $a === '') {
            continue; // fully blank row (e.g. an added-then-untouched card) — ignore silently
        }
        if ($q === '' || $a === '') {
            $faq_errors[] = "FAQ #" . ($i + 1) . " needs both a question and an answer.";
            continue;
        }
        $faq_sync[] = [
            'id' => !empty($faq_id[$i]) ? intval($faq_id[$i]) : null,
            'question' => $q,
            'answer' => $a,
            'is_visible' => (isset($faq_visible[$i]) && $faq_visible[$i] === '1') ? 1 : 0,
            'sort_order' => $i + 1
        ];
    }

    // Parse Testimonial fields
    $test_n = $_POST['test_n'] ?? [];
    $test_r = $_POST['test_r'] ?? [];
    $test_t = $_POST['test_t'] ?? [];
    $test_arr = [];
    for ($i = 0; $i < count($test_n); $i++) {
        if (!empty(trim($test_n[$i]))) {
            $test_arr[] = [
                'name' => trim($test_n[$i]),
                'role' => trim($test_r[$i] ?? ''),
                'text' => trim($test_t[$i] ?? '')
            ];
        }
    }
    $testimonials_json = json_encode($test_arr, JSON_UNESCAPED_UNICODE);

    try {
        set_setting('recruitment_status', $status);
        set_setting('site_title', $title);
        set_setting('site_description', $desc);
        set_setting('hero_title', $hero_t);
        set_setting('hero_subtitle', $hero_sub);
        set_setting('stats_books', $stats_b);
        set_setting('stats_users', $stats_u);
        set_setting('stats_contributors', $stats_c);
        set_setting('testimonials_json', $testimonials_json);

        // Sync the `faqs` table: updates existing rows, inserts new ones,
        // deletes any row no longer present, and applies the submitted
        // order (sort_order) and Show/Hide state (is_visible) in one pass.
        $keep_ids = array_values(array_filter(array_column($faq_sync, 'id')));
        if (!empty($keep_ids)) {
            $placeholders = implode(',', array_fill(0, count($keep_ids), '?'));
            $del_stmt = $pdo->prepare("DELETE FROM faqs WHERE id NOT IN ($placeholders)");
            $del_stmt->execute($keep_ids);
        } else {
            $pdo->exec("DELETE FROM faqs");
        }
        foreach ($faq_sync as $item) {
            if ($item['id']) {
                $upd = $pdo->prepare("UPDATE faqs SET question = ?, answer = ?, sort_order = ?, is_visible = ? WHERE id = ?");
                $upd->execute([$item['question'], $item['answer'], $item['sort_order'], $item['is_visible'], $item['id']]);
            } else {
                $ins = $pdo->prepare("INSERT INTO faqs (question, answer, sort_order, is_visible) VALUES (?, ?, ?, ?)");
                $ins->execute([$item['question'], $item['answer'], $item['sort_order'], $item['is_visible']]);
            }
        }

        // Log settings update
        add_activity_log('Settings Saved', "CMS Configurations updated. Campaign status: {$status}.");

        if (!empty($faq_errors)) {
            $message = 'Saved, but skipped invalid FAQ rows: ' . implode(' ', $faq_errors);
            $message_type = 'error';
        } else {
            $message = 'Campaign parameters and landing CMS content updated successfully.';
            $message_type = 'success';
        }
    } catch (Exception $e) {
        $message = 'Error updating parameters: ' . $e->getMessage();
        $message_type = 'error';
    }
}

// Fetch active parameters
$status = get_setting('recruitment_status', 'open');
$title = get_setting('site_title', "L'EXTERNE Recruitment");
$desc = get_setting('site_description', '');
$hero_t = get_setting('hero_title', "Shape the Future of Medical Education");
$hero_sub = get_setting('hero_subtitle', '');
$stats_b = get_setting('stats_books', '45+ Books Published');
$stats_u = get_setting('stats_users', '15k+ Med Students');
$stats_c = get_setting('stats_contributors', '120+ Team Members');

$faq = get_faqs(); // all rows (visible + hidden) so admins can manage every FAQ
$testimonials = json_decode(get_setting('testimonials_json', '[]'), true);
?>
<!DOCTYPE html>
<html lang="en" class="h-full bg-slate-50">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Campaign settings - L'EXTERNE Review Console</title>
    <link rel="icon" type="image/png" href="../assets/images/logo.png">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
    </style>
</head>
<body class="min-h-full flex flex-col">

    <!-- Top Admin Header -->
    <header class="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <a href="../index.php" class="flex items-center gap-2">
                    <img src="../assets/images/logo.png" alt="L'EXTERNE Logo" class="h-8 w-8 object-contain">
                    <span class="text-lg font-bold text-slate-900 tracking-tight">L'EXTERNE</span>
                </a>
                <span class="px-2 py-0.5 rounded-md bg-sky-50 text-[10px] font-bold text-sky-700 uppercase tracking-wider border border-sky-100">CMS Panel</span>
            </div>
            <div class="flex items-center gap-4">
                <span class="text-xs text-slate-500">Hello, <strong><?php echo htmlspecialchars($_SESSION['user_name']); ?></strong></span>
                <a href="../logout.php" class="text-xs font-semibold text-rose-600 bg-rose-50 px-2.5 py-1.5 rounded-lg">Sign Out</a>
            </div>
        </div>
    </header>

    <div class="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col md:flex-row gap-8">
        
        <!-- SIDEBAR -->
        <aside class="w-full md:w-64 shrink-0 space-y-2">
            <a href="dashboard.php" class="flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-slate-100 hover:text-slate-900 rounded-xl text-sm transition-colors">
                <span>📋</span> Applicants List
            </a>
            <a href="analytics.php" class="flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-slate-100 hover:text-slate-900 rounded-xl text-sm transition-colors">
                <span>📈</span> Analytical Charts
            </a>
            <a href="settings.php" class="flex items-center gap-3 px-4 py-3 bg-sky-50 text-sky-700 font-bold rounded-xl text-sm border border-sky-100">
                <span>⚙️</span> Campaign Settings
            </a>
            <a href="export.php" class="flex items-center gap-3 px-4 py-3 text-slate-600 hover:bg-slate-100 hover:text-slate-900 rounded-xl text-sm transition-colors">
                <span>📦</span> Download XLSX/CSV
            </a>
        </aside>

        <!-- CMS FORM BODY -->
        <main class="flex-grow space-y-8 min-w-0">
            
            <div class="flex items-center justify-between">
                <h2 class="text-xl font-extrabold text-slate-900 tracking-tight">Recruitment CMS & System settings</h2>
                <a href="../index.php" target="_blank" class="text-xs font-bold text-sky-600 hover:underline">View Public Site →</a>
            </div>

            <?php if (!empty($message)): ?>
                <div class="p-4 rounded-xl text-xs font-bold <?php echo $message_type === 'success' ? 'bg-emerald-50 text-emerald-800 border border-emerald-100' : 'bg-rose-50 text-rose-800 border border-rose-100'; ?>">
                    <?php echo htmlspecialchars($message); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="settings.php" class="space-y-8">
                
                <!-- SECTION 1: CAMPAIGN TOGGLES -->
                <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                    <h3 class="text-sm font-bold text-slate-800 border-b border-slate-100 pb-3">🔋 Recruitment Campaign Availability</h3>
                    
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Toggle Status</label>
                            <select name="recruitment_status" class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:outline-none focus:border-sky-500 bg-white font-bold text-slate-800">
                                <option value="open" <?php echo $status === 'open' ? 'selected' : ''; ?>>🟢 Open (Accept application submissions)</option>
                                <option value="closed" <?php echo $status === 'closed' ? 'selected' : ''; ?>>🔴 Closed (Display closed message & block inputs)</option>
                            </select>
                        </div>
                    </div>
                </div>

                <!-- SECTION 2: HERO & BASICS COPY -->
                <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
                    <h3 class="text-sm font-bold text-slate-800 border-b border-slate-100 pb-3">🌟 Landing Page Core Metadata</h3>

                    <div class="grid grid-cols-1 gap-6">
                        <div>
                            <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Portal Title Header</label>
                            <input type="text" name="site_title" value="<?php echo htmlspecialchars($title); ?>" class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-sky-500 focus:outline-none">
                        </div>

                        <div>
                            <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Search Snippet Description</label>
                            <textarea name="site_description" rows="2" class="w-full rounded-xl border border-slate-200 p-3 text-sm focus:border-sky-500 focus:outline-none"><?php echo htmlspecialchars($desc); ?></textarea>
                        </div>

                        <div>
                            <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Hero Main Catchphrase Title</label>
                            <input type="text" name="hero_title" value="<?php echo htmlspecialchars($hero_t); ?>" class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:border-sky-500 focus:outline-none">
                        </div>

                        <div>
                            <label class="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Hero Explanatory Subtitle</label>
                            <textarea name="hero_subtitle" rows="3" class="w-full rounded-xl border border-slate-200 p-3 text-sm focus:border-sky-500 focus:outline-none"><?php echo htmlspecialchars($hero_sub); ?></textarea>
                        </div>
                    </div>
                </div>

                <!-- SECTION 3: SYSTEM COOP COUNTERS -->
                <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
                    <h3 class="text-sm font-bold text-slate-800 border-b border-slate-100 pb-3">📊 Statistical Achievements CMS</h3>
                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-6">
                        <div>
                            <label class="block text-xs font-bold text-slate-700 uppercase mb-2">Books Stat line</label>
                            <input type="text" name="stats_books" value="<?php echo htmlspecialchars($stats_b); ?>" class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:outline-none focus:border-sky-500">
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-slate-700 uppercase mb-2">Students Stat line</label>
                            <input type="text" name="stats_users" value="<?php echo htmlspecialchars($stats_u); ?>" class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:outline-none focus:border-sky-500">
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-slate-700 uppercase mb-2">Contributors Stat line</label>
                            <input type="text" name="stats_contributors" value="<?php echo htmlspecialchars($stats_c); ?>" class="w-full rounded-xl border border-slate-200 px-4 py-2.5 text-sm focus:outline-none focus:border-sky-500">
                        </div>
                    </div>
                </div>

                <!-- SECTION 4: FAQ REPEATER CMS -->
                <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
                    <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                        <h3 class="text-sm font-bold text-slate-800">🙋 FAQ Accordion Editor</h3>
                        <button type="button" onclick="addNewFaqRow()" class="px-2 py-1 bg-sky-50 border border-sky-200 text-sky-700 rounded-lg text-[10px] font-bold">+ Add FAQ Item</button>
                    </div>

                    <div id="faq_container" class="space-y-4">
                        <?php foreach ($faq as $index => $item): ?>
                            <div class="faq-row p-4 bg-slate-50 border border-slate-200/60 rounded-xl space-y-3 relative group">
                                <input type="hidden" name="faq_id[]" value="<?php echo (int) $item['id']; ?>">
                                <div class="absolute top-2 right-2 flex items-center gap-1">
                                    <button type="button" onclick="moveFaqRow(this, -1)" title="Move up" class="text-slate-400 hover:text-sky-600 font-bold text-xs px-1.5">▲</button>
                                    <button type="button" onclick="moveFaqRow(this, 1)" title="Move down" class="text-slate-400 hover:text-sky-600 font-bold text-xs px-1.5">▼</button>
                                    <button type="button" onclick="this.closest('.faq-row').remove()" class="text-rose-500 font-bold text-xs px-1.5">Remove</button>
                                </div>
                                <div>
                                    <label class="block text-[10px] font-bold text-slate-400 uppercase mb-1">Question</label>
                                    <input type="text" name="faq_q[]" value="<?php echo htmlspecialchars($item['question']); ?>" class="w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:outline-none bg-white">
                                </div>
                                <div>
                                    <label class="block text-[10px] font-bold text-slate-400 uppercase mb-1">Answer Accordion content</label>
                                    <textarea name="faq_a[]" rows="2" class="w-full rounded-xl border border-slate-200 p-2 text-xs focus:outline-none bg-white"><?php echo htmlspecialchars($item['answer']); ?></textarea>
                                </div>
                                <div class="flex items-center gap-2">
                                    <input type="hidden" name="faq_visible[]" value="<?php echo $item['is_visible'] ? '1' : '0'; ?>">
                                    <label class="inline-flex items-center gap-1.5 text-[10px] font-bold text-slate-500 uppercase cursor-pointer">
                                        <input type="checkbox" <?php echo $item['is_visible'] ? 'checked' : ''; ?> onchange="this.previousElementSibling.value = this.checked ? '1' : '0'" class="rounded text-sky-600">
                                        Visible on public site
                                    </label>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- SECTION 5: TESTIMONIALS REPEATER CMS -->
                <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
                    <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                        <h3 class="text-sm font-bold text-slate-800">✍️ Team Testimonials Editor</h3>
                        <button type="button" onclick="addNewTestimonialRow()" class="px-2 py-1 bg-sky-50 border border-sky-200 text-sky-700 rounded-lg text-[10px] font-bold">+ Add Testimonial</button>
                    </div>

                    <div id="test_container" class="space-y-4">
                        <?php foreach ($testimonials as $index => $item): ?>
                            <div class="p-4 bg-slate-50 border border-slate-200/60 rounded-xl space-y-3 relative">
                                <button type="button" onclick="this.parentNode.remove()" class="absolute top-2 right-2 text-rose-500 font-bold text-xs">Remove</button>
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                    <div>
                                        <label class="block text-[10px] font-bold text-slate-400 uppercase mb-1">Full Name</label>
                                        <input type="text" name="test_n[]" value="<?php echo htmlspecialchars($item['name']); ?>" class="w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:outline-none bg-white">
                                    </div>
                                    <div>
                                        <label class="block text-[10px] font-bold text-slate-400 uppercase mb-1">Role / Placement Title</label>
                                        <input type="text" name="test_r[]" value="<?php echo htmlspecialchars($item['role']); ?>" class="w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:outline-none bg-white">
                                    </div>
                                </div>
                                <div>
                                    <label class="block text-[10px] font-bold text-slate-400 uppercase mb-1">Review Statement</label>
                                    <textarea name="test_t[]" rows="2" class="w-full rounded-xl border border-slate-200 p-2 text-xs focus:outline-none bg-white"><?php echo htmlspecialchars($item['text']); ?></textarea>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- SAVE BUTTONS RAIL -->
                <div class="flex justify-end gap-3 pt-4">
                    <a href="dashboard.php" class="px-5 py-2.5 border border-slate-200 text-slate-700 font-semibold rounded-xl hover:bg-slate-50 transition-colors text-sm">Discard</a>
                    <button type="submit" class="px-5 py-2.5 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-xl shadow-md transition-all text-sm">Save CMS Changes</button>
                </div>

            </form>
        </main>
    </div>

    <!-- ADDERS CLONERS JAVASCRIPT -->
    <script>
        function addNewFaqRow() {
            const container = document.getElementById('faq_container');
            const item = document.createElement('div');
            item.className = "faq-row p-4 bg-slate-50 border border-slate-200/60 rounded-xl space-y-3 relative animate-fadeIn";
            item.innerHTML = `
                <input type="hidden" name="faq_id[]" value="">
                <div class="absolute top-2 right-2 flex items-center gap-1">
                    <button type="button" onclick="moveFaqRow(this, -1)" title="Move up" class="text-slate-400 hover:text-sky-600 font-bold text-xs px-1.5">▲</button>
                    <button type="button" onclick="moveFaqRow(this, 1)" title="Move down" class="text-slate-400 hover:text-sky-600 font-bold text-xs px-1.5">▼</button>
                    <button type="button" onclick="this.closest('.faq-row').remove()" class="text-rose-500 font-bold text-xs px-1.5">Remove</button>
                </div>
                <div>
                    <label class="block text-[10px] font-bold text-slate-400 uppercase mb-1">Question</label>
                    <input type="text" name="faq_q[]" value="" placeholder="e.g. Can I apply?" class="w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:outline-none bg-white">
                </div>
                <div>
                    <label class="block text-[10px] font-bold text-slate-400 uppercase mb-1">Answer Accordion content</label>
                    <textarea name="faq_a[]" rows="2" placeholder="Answer text here..." class="w-full rounded-xl border border-slate-200 p-2 text-xs focus:outline-none bg-white"></textarea>
                </div>
                <div class="flex items-center gap-2">
                    <input type="hidden" name="faq_visible[]" value="1">
                    <label class="inline-flex items-center gap-1.5 text-[10px] font-bold text-slate-500 uppercase cursor-pointer">
                        <input type="checkbox" checked onchange="this.previousElementSibling.value = this.checked ? '1' : '0'" class="rounded text-sky-600">
                        Visible on public site
                    </label>
                </div>
            `;
            container.appendChild(item);
        }

        // Reorders a FAQ card among its siblings; submitted DOM order becomes
        // the saved sort_order, so moving a card is all reordering requires.
        function moveFaqRow(btn, direction) {
            const row = btn.closest('.faq-row');
            if (!row) return;
            if (direction < 0 && row.previousElementSibling) {
                row.parentNode.insertBefore(row, row.previousElementSibling);
            } else if (direction > 0 && row.nextElementSibling) {
                row.parentNode.insertBefore(row.nextElementSibling, row);
            }
        }

        function addNewTestimonialRow() {
            const container = document.getElementById('test_container');
            const item = document.createElement('div');
            item.className = "p-4 bg-slate-50 border border-slate-200/60 rounded-xl space-y-3 relative animate-fadeIn";
            item.innerHTML = `
                <button type="button" onclick="this.parentNode.remove()" class="absolute top-2 right-2 text-rose-500 font-bold text-xs">Remove</button>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                        <label class="block text-[10px] font-bold text-slate-400 uppercase mb-1">Full Name</label>
                        <input type="text" name="test_n[]" value="" placeholder="Dr. Amel" class="w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:outline-none bg-white">
                    </div>
                    <div>
                        <label class="block text-[10px] font-bold text-slate-400 uppercase mb-1">Role / Placement Title</label>
                        <input type="text" name="test_r[]" value="" placeholder="Book Lead" class="w-full rounded-xl border border-slate-200 px-3 py-1.5 text-xs focus:outline-none bg-white">
                    </div>
                </div>
                <div>
                    <label class="block text-[10px] font-bold text-slate-400 uppercase mb-1">Review Statement</label>
                    <textarea name="test_t[]" rows="2" placeholder="My review..." class="w-full rounded-xl border border-slate-200 p-2 text-xs focus:outline-none bg-white"></textarea>
                </div>
            `;
            container.appendChild(item);
        }
    </script>
</body>
</html>
