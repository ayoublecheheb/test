<?php
/**
 * L'EXTERNE ATS - Detailed Applicant Profile View
 * Fully functional with reviewer evaluation forms, notes saving, and print layout.
 */

require_once __DIR__ . '/../functions.php';

// Check auth
require_login();

$id = intval($_GET['id'] ?? 0);
if ($id <= 0) {
    header('Location: dashboard.php');
    exit;
}

// Fetch applicant identity details
try {
    $stmt = $pdo->prepare("SELECT a.*, u.name as reviewer_name FROM applications a LEFT JOIN users u ON a.reviewer_id = u.id WHERE a.id = ? LIMIT 1");
    $stmt->execute([$id]);
    $app = $stmt->fetch();

    if (!$app) {
        echo "<p>Candidate record not found.</p>";
        exit;
    }

    // Fetch related child records
    // 1. Roles
    $roles_stmt = $pdo->prepare("SELECT role_name FROM application_roles WHERE application_id = ?");
    $roles_stmt->execute([$id]);
    $roles = $roles_stmt->fetchAll(PDO::FETCH_COLUMN);

    // 2. Modules (standard AND custom)
    $modules_stmt = $pdo->prepare("SELECT study_year, module_name, is_custom FROM application_modules WHERE application_id = ? ORDER BY study_year, is_custom, module_name");
    $modules_stmt->execute([$id]);
    $modules_raw = $modules_stmt->fetchAll();
    
    // Group modules by year
    $modules = [];
    foreach ($modules_raw as $m) {
        $modules[$m['study_year']][] = $m;
    }

    // 3. Creative Tools
    $tools_stmt = $pdo->prepare("SELECT tool_name, proficiency_level FROM application_tools WHERE application_id = ?");
    $tools_stmt->execute([$id]);
    $tools = $tools_stmt->fetchAll();

    // 4. Portfolios
    $ports_stmt = $pdo->prepare("SELECT portfolio_url FROM application_portfolios WHERE application_id = ?");
    $ports_stmt->execute([$id]);
    $portfolios = $ports_stmt->fetchAll(PDO::FETCH_COLUMN);

    // 5. Communities
    $comm_stmt = $pdo->prepare("SELECT community_name FROM application_communities WHERE application_id = ?");
    $comm_stmt->execute([$id]);
    $communities = $comm_stmt->fetchAll(PDO::FETCH_COLUMN);

    // 6. Design specialties (Book Designer)
    $spec_stmt = $pdo->prepare("SELECT specialty_name FROM application_design_specialties WHERE application_id = ?");
    $spec_stmt->execute([$id]);
    $design_specialties = $spec_stmt->fetchAll(PDO::FETCH_COLUMN);

    // 7. IT / Development focus areas
    $it_focus_stmt = $pdo->prepare("SELECT focus_name FROM application_it_focus WHERE application_id = ?");
    $it_focus_stmt->execute([$id]);
    $it_focus = $it_focus_stmt->fetchAll(PDO::FETCH_COLUMN);

    // 8. Marketing expertise & platforms
    $mkt_exp_stmt = $pdo->prepare("SELECT expertise_name FROM application_marketing_expertise WHERE application_id = ?");
    $mkt_exp_stmt->execute([$id]);
    $marketing_expertise = $mkt_exp_stmt->fetchAll(PDO::FETCH_COLUMN);

    $mkt_plat_stmt = $pdo->prepare("SELECT platform_name FROM application_marketing_platforms WHERE application_id = ?");
    $mkt_plat_stmt->execute([$id]);
    $marketing_platforms = $mkt_plat_stmt->fetchAll(PDO::FETCH_COLUMN);

    // 9. Community sub-role contributions & platforms
    $cc_stmt = $pdo->prepare("SELECT contribution_name FROM application_community_contributions WHERE application_id = ?");
    $cc_stmt->execute([$id]);
    $community_contributions = $cc_stmt->fetchAll(PDO::FETCH_COLUMN);

    $cp_stmt = $pdo->prepare("SELECT platform_name FROM application_community_platforms WHERE application_id = ?");
    $cp_stmt->execute([$id]);
    $community_platforms = $cp_stmt->fetchAll(PDO::FETCH_COLUMN);

} catch (PDOException $e) {
    echo "Database query error: " . $e->getMessage();
    exit;
}
?>
<!DOCTYPE html>
<html lang="en" class="h-full bg-slate-50">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($app['full_name']); ?> - L'EXTERNE Profile</title>
    <link rel="icon" type="image/png" href="../assets/images/logo.png">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['"Plus Jakarta Sans"', 'sans-serif'],
                        mono: ['"JetBrains Mono"', 'monospace'],
                    }
                }
            }
        }
    </script>
    <style>
        body { font-family: 'Plus Jakarta Sans', sans-serif; }
        
        /* Print Layout styling */
        @media print {
            aside, header, #action_bar, .no-print {
                display: none !important;
            }
            body, main {
                background: white !important;
                color: black !important;
                padding: 0 !important;
            }
            .print-card {
                border: none !important;
                box-shadow: none !important;
                padding: 0 !important;
                margin-bottom: 2rem !important;
            }
            .print-cols {
                display: grid !important;
                grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
                gap: 1.5rem !important;
            }
        }
    </style>
</head>
<body class="min-h-full flex flex-col">

    <!-- Top Navigation -->
    <header class="bg-white border-b border-slate-200 sticky top-0 z-30 no-print">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <div class="flex items-center gap-3">
                <a href="dashboard.php" class="text-xs font-bold text-slate-500 hover:text-sky-600 flex items-center gap-1.5 transition-colors">
                    <span>←</span> Back to Applicants
                </a>
                <span class="text-slate-300">/</span>
                <span class="text-sm font-bold text-slate-900"><?php echo htmlspecialchars($app['full_name']); ?></span>
            </div>
            <button onclick="window.print()" class="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200/80 border border-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center gap-2 transition-colors">
                <span>🖨️</span> Print Candidate Sheet
            </button>
        </div>
    </header>

    <div class="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col lg:flex-row gap-8">
        
        <!-- SIDEBAR - REVIEW CONTROL PANEL (STATIONARY) -->
        <aside id="action_bar" class="w-full lg:w-80 shrink-0 space-y-6 order-last lg:order-first no-print">
            
            <!-- Applicant Status Selector -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                <h4 class="text-xs font-bold uppercase tracking-wider text-slate-400">Review Status</h4>
                
                <div class="space-y-2">
                    <label class="block text-[10px] font-bold text-slate-500 uppercase">Set Status</label>
                    <select id="status_switcher" onchange="updateApplicantStatus(this.value)" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:outline-none focus:border-sky-500 bg-white font-bold text-slate-700">
                        <option value="Pending" <?php echo $app['status'] === 'Pending' ? 'selected' : ''; ?>>🕒 Pending Review</option>
                        <option value="Interview" <?php echo $app['status'] === 'Interview' ? 'selected' : ''; ?>>📅 Shortlist (Interview)</option>
                        <option value="Accepted" <?php echo $app['status'] === 'Accepted' ? 'selected' : ''; ?>>🎉 Accept Candidate</option>
                        <option value="Rejected" <?php echo $app['status'] === 'Rejected' ? 'selected' : ''; ?>>❌ Reject Application</option>
                        <option value="Archived" <?php echo $app['status'] === 'Archived' ? 'selected' : ''; ?>>📦 Archive File</option>
                    </select>
                </div>

                <!-- Interview Scheduling slot -->
                <div class="pt-4 border-t border-slate-100 space-y-2">
                    <label class="block text-[10px] font-bold text-slate-500 uppercase">Schedule Virtual Interview</label>
                    <input type="datetime-local" id="interview_date" value="<?php echo $app['interview_date'] ? date('Y-m-d\TH:i', strtotime($app['interview_date'])) : ''; ?>" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:outline-none focus:border-sky-500 text-slate-600 font-medium">
                    <button onclick="scheduleInterview()" class="w-full text-center py-2 bg-sky-600 hover:bg-sky-500 text-white rounded-xl text-xs font-semibold shadow-sm transition-colors mt-2">
                        Lock Interview Slot
                    </button>
                    <?php if ($app['interview_date']): ?>
                        <p class="text-[10px] text-emerald-600 font-semibold mt-1">✓ Scheduled for: <?php echo date('M d, Y - H:i', strtotime($app['interview_date'])); ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Recruiter Evaluation Notes -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                <div class="flex items-center justify-between">
                    <h4 class="text-xs font-bold uppercase tracking-wider text-slate-400">Evaluator Notes</h4>
                    <span id="note_save_badge" class="hidden text-[9px] bg-emerald-50 text-emerald-700 font-bold px-1.5 py-0.5 rounded border border-emerald-200/50">Saved</span>
                </div>
                <textarea id="reviewer_notes" rows="6" oninput="debounceNotesSave()" placeholder="Add interview feedback, evaluation parameters, portfolio notes..." class="w-full rounded-xl border border-slate-200 p-3 text-xs focus:outline-none focus:border-sky-500 leading-normal bg-slate-50/20 text-slate-700"><?php echo htmlspecialchars($app['notes'] ?? ''); ?></textarea>
                <div class="flex items-center justify-between text-[10px] text-slate-400">
                    <span>Auto-saves as you type</span>
                    <button onclick="saveReviewerNotes()" class="text-sky-600 font-bold hover:underline">Force Save</button>
                </div>
            </div>

            <!-- Candidate Tags -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
                <h4 class="text-xs font-bold uppercase tracking-wider text-slate-400">Internal Tags</h4>
                <input type="text" id="internal_tags" value="<?php echo htmlspecialchars($app['internal_tags'] ?? ''); ?>" placeholder="e.g. Elite Writer, Figma Expert, Algiers Uni" class="w-full rounded-xl border border-slate-200 px-3 py-2 text-xs focus:outline-none focus:border-sky-500 text-slate-700 font-medium">
                <button onclick="saveCandidateTags()" class="w-full py-2 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors">Save Tagset</button>
            </div>
        </aside>

        <!-- MAIN PROFILE DATA (SCROLLABLE & PRINTABLE) -->
        <main class="flex-grow space-y-8 min-w-0">
            
            <!-- CANDIDATE HERO PANEL -->
            <div class="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm print-card">
                <div class="flex flex-col sm:flex-row sm:items-start justify-between gap-6 pb-6 border-b border-slate-100">
                    <div class="space-y-2">
                        <span class="inline-flex items-center rounded-full bg-sky-50 px-2.5 py-0.5 text-xs font-bold text-sky-700 border border-sky-100">
                            Candidate ID: EXT-<?php echo str_pad($app['id'], 4, '0', STR_PAD_LEFT); ?>
                        </span>
                        <h1 class="text-2xl font-black text-slate-950 tracking-tight leading-none"><?php echo htmlspecialchars($app['full_name']); ?></h1>
                        <p class="text-xs font-medium text-slate-400">Application submitted: <?php echo date('F d, Y \a\t H:i', strtotime($app['submitted_at'])); ?></p>
                    </div>

                    <div class="flex items-center gap-3 no-print">
                        <span class="inline-flex items-center rounded-full px-3 py-1 text-xs font-bold border <?php echo get_status_badge_class($app['status']); ?>">
                            <?php echo htmlspecialchars($app['status']); ?>
                        </span>
                    </div>
                </div>

                <!-- Contact & University Rails -->
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-6 print-cols">
                    <div>
                        <span class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Faculty & Education</span>
                        <span class="block mt-1 text-sm font-bold text-slate-900 leading-normal"><?php echo htmlspecialchars($app['faculty']); ?></span>
                        <span class="block mt-0.5 text-xs text-slate-400 font-semibold uppercase"><?php echo htmlspecialchars($app['academic_year']); ?></span>
                    </div>
                    <div>
                        <span class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Digital Contacts</span>
                        <span class="block mt-1 text-xs font-bold text-slate-800">Email: <?php echo htmlspecialchars($app['email']); ?></span>
                        <span class="block mt-0.5 text-xs font-bold text-indigo-600">Telegram Username: <?php echo htmlspecialchars($app['telegram']); ?></span>
                        <span class="block mt-0.5 text-xs font-bold text-emerald-600">WhatsApp: <?php echo htmlspecialchars($app['whatsapp']); ?></span>
                    </div>
                    <div>
                        <span class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Evaluation Route</span>
                        <span class="block mt-1 text-sm font-bold text-slate-900"><?php echo htmlspecialchars($app['recruitment_path']); ?> Track</span>
                        <span class="block mt-0.5 text-[10px] font-bold text-slate-400 uppercase">L'EXTERNE 2026 Initiative</span>
                    </div>
                </div>
            </div>

            <!-- TRACK-SPECIFIC EVALUATIONS -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 print-cols">
                
                <!-- Editorial Track evaluation panel -->
                <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between print-card">
                    <div>
                        <h3 class="text-sm font-bold text-slate-800 border-b border-slate-100 pb-3 mb-4 flex items-center justify-between">
                            <span>✍️ Editorial Track Profile</span>
                            <?php if ($app['recruitment_path'] === 'Editorial' || $app['recruitment_path'] === 'Both'): ?>
                                <span class="bg-emerald-50 text-emerald-700 text-[9px] font-bold px-1.5 py-0.5 rounded">Active</span>
                            <?php else: ?>
                                <span class="bg-slate-100 text-slate-400 text-[9px] font-bold px-1.5 py-0.5 rounded">Not Selected</span>
                            <?php endif; ?>
                        </h3>

                        <?php if ($app['recruitment_path'] === 'Editorial' || $app['recruitment_path'] === 'Both'): ?>
                            <!-- Roles interest -->
                            <div class="space-y-4">
                                <div>
                                    <span class="text-[10px] font-bold text-slate-400 uppercase">Chosen Editorial Roles</span>
                                    <div class="flex flex-wrap gap-2 mt-1.5">
                                        <?php foreach ($roles as $role): ?>
                                            <span class="px-2.5 py-1 bg-slate-50 border border-slate-200 text-slate-800 rounded-lg text-xs font-semibold"><?php echo htmlspecialchars($role); ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                </div>

                                <!-- Modules & Study Years list with Custom Module labels -->
                                <div class="pt-2">
                                    <span class="text-[10px] font-bold text-slate-400 uppercase">Selected Modules (by Study Level)</span>
                                    <div class="space-y-3 mt-2">
                                        <?php if (empty($modules)): ?>
                                            <p class="text-xs text-slate-400 italic">No modules selected.</p>
                                        <?php else: ?>
                                            <?php foreach ($modules as $year => $mods): ?>
                                                <div class="bg-slate-50/50 p-2.5 rounded-xl border border-slate-100">
                                                    <h5 class="text-[10px] font-bold text-slate-500 uppercase"><?php echo htmlspecialchars($year); ?></h5>
                                                    <div class="flex flex-wrap gap-1.5 mt-1.5">
                                                        <?php foreach ($mods as $mod): ?>
                                                            <?php if ($mod['is_custom'] == 1): ?>
                                                                <span class="px-2 py-0.5 bg-sky-100 border border-sky-200 text-sky-800 rounded-full text-[10px] font-bold" title="Applicant custom entry under <?php echo htmlspecialchars($year); ?> context">
                                                                    ✨ <?php echo htmlspecialchars($mod['module_name']); ?> <strong class="text-sky-950 ml-0.5 text-[8px] uppercase tracking-wider">[Custom]</strong>
                                                                </span>
                                                            <?php else: ?>
                                                                <span class="px-2 py-0.5 bg-slate-100 border border-slate-200 text-slate-600 rounded-full text-[10px] font-medium">
                                                                    <?php echo htmlspecialchars($mod['module_name']); ?>
                                                                </span>
                                                            <?php endif; ?>
                                                        <?php endforeach; ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <?php if (!empty($design_specialties)): ?>
                                <!-- Design specialties -->
                                <div class="pt-2">
                                    <span class="text-[10px] font-bold text-slate-400 uppercase">Design Specialties</span>
                                    <div class="flex flex-wrap gap-1.5 mt-1.5">
                                        <?php foreach ($design_specialties as $spec): ?>
                                            <span class="px-2 py-0.5 bg-indigo-50 border border-indigo-200 text-indigo-800 rounded-full text-[10px] font-bold"><?php echo htmlspecialchars($spec); ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-xs text-slate-400 italic">The candidate did not apply for Editorial roles.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Community track evaluation panel -->
                <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between print-card">
                    <div>
                        <h3 class="text-sm font-bold text-slate-800 border-b border-slate-100 pb-3 mb-4 flex items-center justify-between">
                            <span>👥 Community Track Profile</span>
                            <?php if ($app['recruitment_path'] === 'Community' || $app['recruitment_path'] === 'Both'): ?>
                                <span class="bg-emerald-50 text-emerald-700 text-[9px] font-bold px-1.5 py-0.5 rounded">Active</span>
                            <?php else: ?>
                                <span class="bg-slate-100 text-slate-400 text-[9px] font-bold px-1.5 py-0.5 rounded">Not Selected</span>
                            <?php endif; ?>
                        </h3>

                        <?php if ($app['recruitment_path'] === 'Community' || $app['recruitment_path'] === 'Both'): ?>
                            <div class="space-y-4">
                                <div>
                                    <span class="text-[10px] font-bold text-slate-400 uppercase">Selected Operational communities</span>
                                    <div class="flex flex-wrap gap-2 mt-1.5">
                                        <?php foreach ($communities as $comm): ?>
                                            <span class="px-2.5 py-1 bg-slate-50 border border-slate-200 text-slate-800 rounded-lg text-xs font-semibold">📍 <?php echo htmlspecialchars($comm); ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                </div>

                                <?php if (!empty($community_contributions)): ?>
                                <div class="pt-2">
                                    <span class="text-[10px] font-bold text-slate-400 uppercase">How They'd Like to Contribute</span>
                                    <div class="flex flex-wrap gap-1.5 mt-1.5">
                                        <?php foreach ($community_contributions as $c): ?>
                                            <span class="px-2 py-0.5 bg-sky-50 border border-sky-200 text-sky-800 rounded-full text-[10px] font-bold"><?php echo htmlspecialchars($c); ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <div class="grid grid-cols-2 gap-4 pt-2">
                                    <div>
                                        <span class="text-[10px] font-bold text-slate-400 uppercase">Managed a community before?</span>
                                        <p class="mt-1 text-xs font-bold text-slate-800"><?php echo htmlspecialchars($app['community_managed_before'] ?? 'No'); ?><?php echo (!empty($app['community_managed_before']) && $app['community_managed_before'] === 'Yes' && $app['community_member_count']) ? ' — ~' . intval($app['community_member_count']) . ' members' : ''; ?></p>
                                    </div>
                                    <div>
                                        <span class="text-[10px] font-bold text-slate-400 uppercase">Hours per week available</span>
                                        <p class="mt-1 text-xs font-bold text-slate-800"><?php echo htmlspecialchars($app['community_hours_per_week'] ?? 'Not specified'); ?></p>
                                    </div>
                                </div>

                                <?php if (!empty($community_platforms)): ?>
                                <div class="pt-2">
                                    <span class="text-[10px] font-bold text-slate-400 uppercase">Platforms Previously Managed</span>
                                    <div class="flex flex-wrap gap-1.5 mt-1.5">
                                        <?php foreach ($community_platforms as $p): ?>
                                            <span class="px-2 py-0.5 bg-slate-100 border border-slate-200 text-slate-600 rounded-full text-[10px] font-medium"><?php echo htmlspecialchars($p); ?></span>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                                <?php endif; ?>

                                <?php if (!empty($app['community_why_join'])): ?>
                                <div class="pt-2">
                                    <span class="text-[10px] font-bold text-slate-400 uppercase">Why they want to help build the community</span>
                                    <p class="mt-1.5 text-xs text-slate-600 leading-relaxed bg-slate-50/40 p-3 rounded-xl border border-slate-100"><?php echo nl2br(htmlspecialchars($app['community_why_join'])); ?></p>
                                </div>
                                <?php endif; ?>

                                <?php if (!empty($app['community_unique_value'])): ?>
                                <div class="pt-2">
                                    <span class="text-[10px] font-bold text-slate-400 uppercase">Unique Value They Can Bring</span>
                                    <p class="mt-1.5 text-xs text-slate-600 leading-relaxed bg-slate-50/40 p-3 rounded-xl border border-slate-100"><?php echo nl2br(htmlspecialchars($app['community_unique_value'])); ?></p>
                                </div>
                                <?php endif; ?>

                                <?php if (!empty($app['community_problem_solving'])): ?>
                                <div class="pt-2">
                                    <span class="text-[10px] font-bold text-slate-400 uppercase">Problem-Solving / Team Support Example</span>
                                    <p class="mt-1.5 text-xs text-slate-600 leading-relaxed bg-slate-50/40 p-3 rounded-xl border border-slate-100"><?php echo nl2br(htmlspecialchars($app['community_problem_solving'])); ?></p>
                                </div>
                                <?php endif; ?>

                                <?php if (!empty($app['community_portfolio_links'])): ?>
                                <div class="pt-2">
                                    <span class="text-[10px] font-bold text-slate-400 uppercase">Links to Previous Work / Relevant Experience</span>
                                    <p class="mt-1.5 text-xs text-slate-600 leading-relaxed bg-slate-50/40 p-3 rounded-xl border border-slate-100"><?php echo nl2br(htmlspecialchars($app['community_portfolio_links'])); ?></p>
                                </div>
                                <?php endif; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-xs text-slate-400 italic">The candidate did not select Community departments.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if (!empty($it_focus) || !empty($app['it_github_url']) || !empty($app['it_significant_project']) || !empty($app['it_why_join'])): ?>
            <!-- IT / DEVELOPMENT DETAILS -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm print-card">
                <h3 class="text-sm font-bold text-slate-800 border-b border-slate-100 pb-3 mb-4">💻 IT / Development Details</h3>
                <div class="space-y-4">
                    <?php if (!empty($it_focus)): ?>
                    <div>
                        <span class="text-[10px] font-bold text-slate-400 uppercase">Contribution Focus</span>
                        <div class="flex flex-wrap gap-1.5 mt-1.5">
                            <?php foreach ($it_focus as $f): ?>
                                <span class="px-2 py-0.5 bg-indigo-50 border border-indigo-200 text-indigo-800 rounded-full text-[10px] font-bold"><?php echo htmlspecialchars($f); ?></span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <span class="text-[10px] font-bold text-slate-400 uppercase">GitHub</span>
                            <p class="mt-1 text-xs font-bold text-sky-700 truncate"><?php echo !empty($app['it_github_url']) ? '<a href="'.htmlspecialchars($app['it_github_url']).'" target="_blank" class="hover:underline">'.htmlspecialchars($app['it_github_url']).'</a>' : '<span class="text-slate-400 italic font-normal">Not provided</span>'; ?></p>
                        </div>
                        <div>
                            <span class="text-[10px] font-bold text-slate-400 uppercase">Portfolio</span>
                            <p class="mt-1 text-xs font-bold text-sky-700 truncate"><?php echo !empty($app['it_portfolio_url']) ? '<a href="'.htmlspecialchars($app['it_portfolio_url']).'" target="_blank" class="hover:underline">'.htmlspecialchars($app['it_portfolio_url']).'</a>' : '<span class="text-slate-400 italic font-normal">Not provided</span>'; ?></p>
                        </div>
                        <div>
                            <span class="text-[10px] font-bold text-slate-400 uppercase">Languages</span>
                            <p class="mt-1 text-xs font-bold text-slate-800"><?php echo htmlspecialchars($app['it_languages'] ?? '') ?: '<span class="text-slate-400 italic font-normal">Not provided</span>'; ?></p>
                        </div>
                        <div>
                            <span class="text-[10px] font-bold text-slate-400 uppercase">Frameworks & Technologies</span>
                            <p class="mt-1 text-xs font-bold text-slate-800"><?php echo htmlspecialchars($app['it_frameworks'] ?? '') ?: '<span class="text-slate-400 italic font-normal">Not provided</span>'; ?></p>
                        </div>
                        <div>
                            <span class="text-[10px] font-bold text-slate-400 uppercase">Years of Experience</span>
                            <p class="mt-1 text-xs font-bold text-slate-800"><?php echo htmlspecialchars($app['it_years_experience'] ?? 'Not specified'); ?></p>
                        </div>
                    </div>
                    <?php if (!empty($app['it_significant_project'])): ?>
                    <div class="pt-2">
                        <span class="text-[10px] font-bold text-slate-400 uppercase">Most Significant Project</span>
                        <p class="mt-1.5 text-xs text-slate-600 leading-relaxed bg-slate-50/40 p-3 rounded-xl border border-slate-100"><?php echo nl2br(htmlspecialchars($app['it_significant_project'])); ?></p>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($app['it_why_join'])): ?>
                    <div class="pt-2">
                        <span class="text-[10px] font-bold text-slate-400 uppercase">Why They Want to Join Technology</span>
                        <p class="mt-1.5 text-xs text-slate-600 leading-relaxed bg-slate-50/40 p-3 rounded-xl border border-slate-100"><?php echo nl2br(htmlspecialchars($app['it_why_join'])); ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if (!empty($marketing_expertise) || !empty($app['marketing_campaign']) || !empty($app['marketing_why_join'])): ?>
            <!-- MARKETING DETAILS -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm print-card">
                <h3 class="text-sm font-bold text-slate-800 border-b border-slate-100 pb-3 mb-4">📣 Marketing Details</h3>
                <div class="space-y-4">
                    <?php if (!empty($marketing_expertise)): ?>
                    <div>
                        <span class="text-[10px] font-bold text-slate-400 uppercase">Areas of Expertise</span>
                        <div class="flex flex-wrap gap-1.5 mt-1.5">
                            <?php foreach ($marketing_expertise as $exp): ?>
                                <span class="px-2 py-0.5 bg-rose-50 border border-rose-200 text-rose-800 rounded-full text-[10px] font-bold"><?php echo htmlspecialchars($exp); ?></span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($marketing_platforms)): ?>
                    <div>
                        <span class="text-[10px] font-bold text-slate-400 uppercase">Platforms Managed</span>
                        <div class="flex flex-wrap gap-1.5 mt-1.5">
                            <?php foreach ($marketing_platforms as $p): ?>
                                <span class="px-2 py-0.5 bg-slate-100 border border-slate-200 text-slate-600 rounded-full text-[10px] font-medium"><?php echo htmlspecialchars($p); ?></span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div>
                        <span class="text-[10px] font-bold text-slate-400 uppercase">Managed advertising budgets?</span>
                        <p class="mt-1 text-xs font-bold text-slate-800"><?php echo htmlspecialchars($app['marketing_budget_experience'] ?? 'No'); ?><?php echo !empty($app['marketing_budget_size']) ? ' — ' . htmlspecialchars($app['marketing_budget_size']) : ''; ?></p>
                        <?php if (!empty($app['marketing_budget_details'])): ?>
                            <p class="mt-1.5 text-xs text-slate-600 leading-relaxed bg-slate-50/40 p-3 rounded-xl border border-slate-100"><?php echo nl2br(htmlspecialchars($app['marketing_budget_details'])); ?></p>
                        <?php endif; ?>
                    </div>
                    <?php if (!empty($app['marketing_campaign'])): ?>
                    <div class="pt-2">
                        <span class="text-[10px] font-bold text-slate-400 uppercase">Campaign They're Proud Of</span>
                        <p class="mt-1.5 text-xs text-slate-600 leading-relaxed bg-slate-50/40 p-3 rounded-xl border border-slate-100"><?php echo nl2br(htmlspecialchars($app['marketing_campaign'])); ?></p>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($app['marketing_work_links'])): ?>
                    <div class="pt-2">
                        <span class="text-[10px] font-bold text-slate-400 uppercase">Links to Previous Work</span>
                        <p class="mt-1.5 text-xs text-slate-600 leading-relaxed bg-slate-50/40 p-3 rounded-xl border border-slate-100"><?php echo nl2br(htmlspecialchars($app['marketing_work_links'])); ?></p>
                    </div>
                    <?php endif; ?>
                    <?php if (!empty($app['marketing_why_join'])): ?>
                    <div class="pt-2">
                        <span class="text-[10px] font-bold text-slate-400 uppercase">Why They Want to Join Marketing</span>
                        <p class="mt-1.5 text-xs text-slate-600 leading-relaxed bg-slate-50/40 p-3 rounded-xl border border-slate-100"><?php echo nl2br(htmlspecialchars($app['marketing_why_join'])); ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- SOFTWARE PROFICIENCY & CREATIVE TOOLCHAIN -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm print-card">
                <h3 class="text-sm font-bold text-slate-800 border-b border-slate-100 pb-3 mb-4">🛠️ Software Skillsets & Vector Toolchains</h3>
                
                <?php if (empty($tools)): ?>
                    <p class="text-xs text-slate-400 italic">No design or media software ratings logged.</p>
                <?php else: ?>
                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
                        <?php foreach ($tools as $t): ?>
                            <div class="p-3.5 bg-slate-50 rounded-xl border border-slate-100">
                                <span class="block text-[10px] font-bold text-slate-400 uppercase"><?php echo htmlspecialchars($t['tool_name']); ?></span>
                                <span class="block mt-1 text-sm font-bold text-slate-800"><?php echo htmlspecialchars($t['proficiency_level']); ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- PORTFOLIO REFERENCES -->
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm print-card">
                <h3 class="text-sm font-bold text-slate-800 border-b border-slate-100 pb-3 mb-4">🔗 Creative Portfolio URLs & References</h3>
                
                <?php if (empty($portfolios)): ?>
                    <p class="text-xs text-slate-400 italic">No portfolios or Behance references provided.</p>
                <?php else: ?>
                    <ul class="space-y-2">
                        <?php foreach ($portfolios as $url): ?>
                            <li class="text-xs bg-slate-50 p-2.5 rounded-xl border border-slate-100 flex items-center justify-between">
                                <span class="truncate text-slate-600 max-w-[400px] font-semibold"><?php echo htmlspecialchars($url); ?></span>
                                <a href="<?php echo htmlspecialchars($url); ?>" target="_blank" class="text-sky-600 hover:underline font-bold text-[10px] no-print">Open Link</a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>

            <!-- MOTIVATION, SUGGESTIONS & PREVIOUS EXPERIENCES -->
            <div class="bg-white p-8 rounded-3xl border border-slate-200 shadow-sm space-y-6 print-card">
                <h3 class="text-sm font-bold text-slate-800 border-b border-slate-100 pb-3 mb-4">📊 Evaluation Essay Details</h3>

                <!-- Motivation -->
                <div>
                    <span class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Candidate Motivation Essay</span>
                    <p class="mt-2 text-xs text-slate-600 leading-relaxed bg-slate-50/40 p-4 rounded-xl border border-slate-100"><?php echo nl2br(htmlspecialchars($app['motivation'] ?? '')); ?></p>
                </div>

                <!-- L'EXTERNE Project & Commitment -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6 print-cols">
                    <div>
                        <span class="block text-[10px] font-bold text-slate-400 uppercase">Target Project interest</span>
                        <p class="mt-1 text-xs font-bold text-slate-800 leading-normal"><?php echo htmlspecialchars($app['project'] ?? 'None'); ?></p>
                    </div>
                    <div>
                        <span class="block text-[10px] font-bold text-slate-400 uppercase">Expected Duration Commitment</span>
                        <p class="mt-1 text-xs font-bold text-slate-800 leading-normal"><?php echo htmlspecialchars($app['long_term_commitment'] ?? 'None'); ?></p>
                    </div>
                </div>

                <!-- Previous experience log -->
                <div>
                    <span class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Has previous experience?: <strong><?php echo htmlspecialchars($app['previous_experience']); ?></strong></span>
                    <?php if ($app['previous_experience'] === 'Yes'): ?>
                        <p class="mt-2 text-xs text-slate-600 leading-relaxed bg-slate-50/40 p-4 rounded-xl border border-slate-100"><?php echo nl2br(htmlspecialchars($app['previous_experience_details'] ?? '')); ?></p>
                    <?php endif; ?>
                </div>

                <!-- Revenue-sharing response -->
                <div>
                    <span class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Comfortable with revenue-sharing model?: <strong><?php echo htmlspecialchars($app['revenue_sharing_response'] ?? 'Not answered'); ?></strong></span>
                </div>

                <!-- Ideas or Suggestions -->
                <div>
                    <span class="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Suggested Improvements / Book ideas for L'EXTERNE</span>
                    <p class="mt-2 text-xs text-slate-600 leading-relaxed bg-slate-50/40 p-4 rounded-xl border border-slate-100"><?php echo nl2br(htmlspecialchars($app['ideas'] ?? '')); ?></p>
                </div>
            </div>

            <!-- Print Footer -->
            <div class="hidden print:block text-[10px] text-slate-400 border-t border-slate-200 pt-4 flex justify-between">
                <span>Evaluator Sheet - L'EXTERNE Recruitment Committee 2026</span>
                <span>Candidate ID: EXT-<?php echo str_pad($app['id'], 4, '0', STR_PAD_LEFT); ?></span>
            </div>

        </main>
    </div>

    <!-- AJAX FOR EVALUATIONS NOTES, RATINGS & TAGS -->
    <script>
        const applicantId = <?php echo $id; ?>;
        let notesTimeout = null;

        // Debounce reviewer notes autosave (3 seconds delay)
        function debounceNotesSave() {
            document.getElementById('note_save_badge').classList.add('hidden');
            clearTimeout(notesTimeout);
            notesTimeout = setTimeout(saveReviewerNotes, 2000);
        }

        function saveReviewerNotes() {
            const val = document.getElementById('reviewer_notes').value;
            const badge = document.getElementById('note_save_badge');

            const fd = new FormData();
            fd.append('action', 'update_notes');
            fd.append('id', applicantId);
            fd.append('notes', val);

            fetch('../api.php', {
                method: 'POST',
                body: fd
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    badge.classList.remove('hidden');
                    setTimeout(() => badge.classList.add('hidden'), 3000);
                }
            });
        }

        function saveCandidateTags() {
            const tags = document.getElementById('internal_tags').value;
            
            const fd = new FormData();
            fd.append('action', 'update_tags');
            fd.append('id', applicantId);
            fd.append('tags', tags);

            fetch('../api.php', {
                method: 'POST',
                body: fd
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    alert("Applicant internal evaluation tags saved.");
                } else {
                    alert("Error saving tags: " + data.message);
                }
            });
        }

        function updateApplicantStatus(status) {
            const fd = new FormData();
            fd.append('action', 'update_status');
            fd.append('id', applicantId);
            fd.append('status', status);

            fetch('../api.php', {
                method: 'POST',
                body: fd
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    alert("Applicant review status updated to: " + status);
                    window.location.reload();
                } else {
                    alert("Error updating status: " + data.message);
                }
            });
        }

        function scheduleInterview() {
            const val = document.getElementById('interview_date').value;
            if (!val) {
                alert("Please select a date and time slot first.");
                return;
            }

            const fd = new FormData();
            fd.append('action', 'schedule_interview');
            fd.append('id', applicantId);
            fd.append('interview_date', val);

            fetch('../api.php', {
                method: 'POST',
                body: fd
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    alert("Interview scheduled successfully.");
                    window.location.reload();
                } else {
                    alert("Error scheduling interview: " + data.message);
                }
            });
        }
    </script>
</body>
</html>
