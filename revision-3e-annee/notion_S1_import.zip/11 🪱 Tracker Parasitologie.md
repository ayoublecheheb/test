# 🪱 Tracker Parasitologie

> **Examen : jeudi 18/02/2027** · **25 cours** (Général · Protozoaires · Helminthes · Entomologie · Mycologie) · **34,2 % du volume des modules** · Tombabilité : non indiquée dans les sources · Difficulté : **élevée (déclarée par toi)**

## 🎯 Objectifs

| Jalon | Objectif (cours en couche 1, cumulés) | Statut |
|---|---:|---|
| Arrêt mi-S7 (dim 15/11) | **4 / 25** | ☐ |
| Sprint post-examen (dim 13/12) | **4 / 25** | ☐ |
| Fin S13 (jeu 31/12) | **7 / 25** | ☐ |
| Fin S15 (jeu 14/01) | **13 / 25** | ☐ |
| Fin S17 (mer 27/01, veille du J-14 UEI2) | **18 / 25** | ☐ |
| Fin S18 (jeu 04/02) | **20 / 25** | ☐ |
| 11/02/2027 (examen UEI 2) | **Tous en couche 3** (C3) | ☐ |
| Veille de l'examen | **Couche 4 faite** + QCM chronométrés | ☐ |

**Objectif qualité :** chaque cours doit avoir ses flashcards, ses QCM et une ligne dans le carnet d'erreurs. Un cours « vu en amphi » ne compte pas.

## ⛔ Règle d'arrêt (UEI 1)

Arrêt **total** des modules du **lundi 16/11** au **jeudi 10/12** (examen UEI 1). Dernières séances : sam 14/11 et dim 15/11. Reprise le **sam 12/12**.

## 📏 Règles du module

- **1 nouveau cours de Para par jour maximum**, jamais le même jour qu'un P1 de Cardio.
- Séance nouvelle = **45–60 min max**, terminée par un **tableau comparatif**.
- **Micro-reprises de 15 min** 2×/semaine (mercredi et vendredi) : flashcards + reconstruire le tableau de mémoire.
- C2 à J+2 (plus serré que les autres modules) ; C3 entre le 28/01 et le 11/02, Para en premier.
- Pendant 28/01 → 11/02, la Para passe **en premier** dans le bloc modules (module le plus difficile).

## 🧩 Parcours thématique (ordre proposé)

*Les cours d'un même thème sont étudiés à quelques jours d'intervalle pour s'ancrer ensemble. Les cours des autres modules du même thème sont rappelés entre parenthèses : ils sont prévus dans la même fenêtre.*

### T03 · Hôte ↔ microbes
*Lien avec l'unité : PHY05 Choc septique · SEM03 Fièvre · Objectif : Comprendre colonisation → infection → réponse de l'hôte · À produire : Schéma « microbiote → conflit → sepsis »* · **Même thème dans un autre module : BAC03, BAC04**

- [ ] **PAR01** · Introduction à la parasitologie — *S4*

### T04 · Protozoaires intestinaux
*Lien avec l'unité : — · Objectif : Distinguer amibes / flagellés / coccidies · À produire : Tableau comparatif Para (agent · transmission · cycle · clinique · diagnostic · traitement)*

- [ ] **PAR02** · Amibes, amoebose, amibes libres — *S5*
- [ ] **PAR03** · Flagellés intestinaux et urogénitaux, ciliés — *S6*
- [ ] **PAR04** · Cryptosporidiose, isosporose, sarcocystose, cyclosporose, blastocytose — *S7 (dim 15/11)*

### T07 · Fièvre & paludisme
*Lien avec l'unité : SEM03 Fièvre · PHY06 Thermorégulation (S4) · Objectif : Cycle du Plasmodium + accès palustre · À produire : Schéma du cycle + tableau des espèces*

- [ ] **PAR07** · Plasmodiums – paludisme — *S11*

### T10 · Peau & muqueuses
*Lien avec l'unité : UEI 2 (cutané) · Objectif : Agents des infections cutanéo-muqueuses · À produire : Tableau « lésion → agents possibles → diagnostic »* · **Même thème dans un autre module : BAC15, VIR04, VIR05**

- [ ] **PAR17** · Introduction à la mycologie — *S13*
- [ ] **PAR18** · Candida – candidoses, malasseziose — *S13*
- [ ] **PAR20** · Dermatophytes – dermatophyties — *S14*
- [ ] **PAR22** · Mycétomes, sporotrichose — *S14*

### T12 · Vecteurs & protozoaires sanguins/tissulaires
*Lien avec l'unité : UEI 2 (neuro : toxo, trypano · cutané : leishmaniose) · rappel PAR07 · Objectif : Vecteur → parasite → maladie · À produire : Tableau vecteur/parasite (avec PAR07)*

- [ ] **PAR16** · Notion d'entomologie médicale — *S15*
- [ ] **PAR05** · Flagellés sanguicoles et tissulaires I : leishmanies et leishmanioses — *S15*
- [ ] **PAR06** · Flagellés sanguicoles et tissulaires II : trypanosomes – trypanosomoses — *S15*
- [ ] **PAR08** · Toxoplasme – toxoplasmose — *S15*

### T15 · Plathelminthes (cestodes & trématodes)
*Lien avec l'unité : UEI 1 thorax (kyste hydatique) · UEI 2 neuro (cysticercose) · Objectif : Cestodes adultes vs larvaires · douves vs schistosomes · À produire : Tableau comparatif des plathelminthes*

- [ ] **PAR09** · Généralités sur les helminthes, cestodes adultes — *S16*
- [ ] **PAR10** · Cestodes à l'état larvaire — *S16*
- [ ] **PAR11** · Douves – distomatoses — *S16*
- [ ] **PAR12** · Schistosomes – schistosomoses — *S17*

### T17 · Nématodes
*Lien avec l'unité : UEI 2 cutané (larva migrans, onchocercose) · Objectif : Per-os vs transcutanés vs filaires · À produire : Tableau comparatif des nématodes*

- [ ] **PAR13** · Nématodes à transmission per-os — *S17*
- [ ] **PAR14** · Nématodes à transmission transcutanée — *S18*
- [ ] **PAR15** · Filaires – filarioses — *S18*

### T19 · Mycoses profondes
*Lien avec l'unité : UEI 1 respiratoire (pneumocystose, aspergillose) · Objectif : Levures vs filamenteux, terrain, diagnostic · À produire : Tableau des mycoses profondes*

- [ ] **PAR19** · Cryptococcose, pneumocystose, microsporidioses — *⚠️ Sans créneau*
- [ ] **PAR21** · Aspergillus – aspergilloses — *⚠️ Sans créneau*
- [ ] **PAR23** · Histoplasmoses, blastomycoses, coccidioïdomycose, paracoccidioïdomycose — *⚠️ Sans créneau*
- [ ] **PAR24** · Mucormycoses, fusarioses, zygomycoses — *⚠️ Sans créneau*

### T21 · Immunodéprimé (synthèse)
*Lien avec l'unité : Rappels VIR07, PAR04, PAR08, PAR18, PAR19 · Objectif : Synthèse des infections opportunistes · À produire : Tableau « déficit → agents »*

- [ ] **PAR25** · SIDA et parasitoses, SIDA et mycoses — *⚠️ Sans créneau*

## 🔁 3 repassages complets du module

| Passage | Quand | Comment |
|---|---|---|
| **1 · Recouchage par thème** | Dès qu'un thème est fini (C1 + C2) → dans la case révision du **mercredi** ou un **vendredi** (jour léger) | QCM mixtes du thème + reconstruire le tableau comparatif de mémoire |
| **2 · C3 complète** | 28/01 → 10/02 (1 bloc/jour, par thème) | Annales + carnet d'erreurs |
| **3 · C4 complète** | Les 2 derniers jours avant l'examen | Fiches 1 page + QCM chronométrés |

**Passage 1 — dates des recouchages de thème :**

- [ ] **T03 · Hôte ↔ microbes** — **mer 23/12**
- [ ] **T04 · Protozoaires intestinaux** — **ven 25/12**
- [ ] **T07 · Fièvre & paludisme** — **mer 06/01**
- [ ] **T10 · Peau & muqueuses** — **ven 15/01**
- [ ] **T12 · Vecteurs & protozoaires sanguins/tissulaires** — **ven 22/01**
- [ ] **T15 · Plathelminthes (cestodes & trématodes)** — *fini trop tard → fondu dans le passage 2 (C3)*
- [ ] **T17 · Nématodes** — *fini trop tard → fondu dans le passage 2 (C3)*
- [ ] **T19 · Mycoses profondes** — *fini trop tard → fondu dans le passage 2 (C3)*
- [ ] **T21 · Immunodéprimé (synthèse)** — *fini trop tard → fondu dans le passage 2 (C3)*

*Les thèmes finis après le 25/01 n'ont pas de recouchage séparé : leur C2 récente + le passage 2 en tiennent lieu.*

## 📊 Suivi par couches

| Cours | Semaine | État | C1 | C2 | C3 | C4 | Flashcards | QCM % | Maîtrise |
|---|---|---|---|---|---|---|---|---|---|
| PAR01 Introduction à la parasitologie | S4 | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR02 Amibes, amoebose, amibes libres | S5 | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR03 Flagellés intestinaux et urogénitaux, ciliés | S6 | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR04 Cryptosporidiose, isosporose, sarcocystose, cyclosporose, blastocytose | S7 (dim 15/11) | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR05 Flagellés sanguicoles et tissulaires I : leishmanies et leishmanioses | S15 | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR06 Flagellés sanguicoles et tissulaires II : trypanosomes – trypanosomoses | S15 | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR07 Plasmodiums – paludisme | S11 | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR08 Toxoplasme – toxoplasmose | S15 | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR09 Généralités sur les helminthes, cestodes adultes | S16 | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR10 Cestodes à l'état larvaire | S16 | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR11 Douves – distomatoses | S16 | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR12 Schistosomes – schistosomoses | S17 | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR13 Nématodes à transmission per-os | S17 | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR14 Nématodes à transmission transcutanée | S18 | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR15 Filaires – filarioses | S18 | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR16 Notion d'entomologie médicale | S15 | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR17 Introduction à la mycologie | S13 | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR18 Candida – candidoses, malasseziose | S13 | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR19 Cryptococcose, pneumocystose, microsporidioses | ⚠️ Sans créneau | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR20 Dermatophytes – dermatophyties | S14 | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR21 Aspergillus – aspergilloses | ⚠️ Sans créneau | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR22 Mycétomes, sporotrichose | S14 | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR23 Histoplasmoses, blastomycoses, coccidioïdomycose, paracoccidioïdomycose | ⚠️ Sans créneau | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR24 Mucormycoses, fusarioses, zygomycoses | ⚠️ Sans créneau | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |
| PAR25 SIDA et parasitoses, SIDA et mycoses | ⚠️ Sans créneau | ⬜ | ☐ | ☐ | ☐ | ☐ | ☐ |  |  |

## 🏁 Fin de semestre (proposition)

| Quand | Quoi |
|---|---|
| 28/01 → 11/02 | C3 Para : prioritaire dans le bloc modules quotidien |
| Mar 16/02 (après l'examen de Pharma) | C4 : protozoaires + entomologie |
| Mer 17/02 | C4 : helminthes + mycologie + QCM |
| **Jeu 18/02** | **EXAMEN PARASITOLOGIE** |

## 🧠 Tableaux comparatifs à produire

- [ ] Protozoaires intestinaux (PAR02–04)
- [ ] Vecteurs & protozoaires sanguins/tissulaires (PAR05–08, PAR16)
- [ ] Plathelminthes : cestodes & trématodes (PAR09–12)
- [ ] Nématodes & filaires (PAR13–15)
- [ ] Levures vs filamenteux (PAR17–24)
- [ ] Immunodéprimé : déficit → agents (PAR25)
